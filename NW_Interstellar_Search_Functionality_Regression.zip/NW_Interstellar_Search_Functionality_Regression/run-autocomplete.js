/**
 * run-autocomplete.js
 * Standalone runner — Desktop + Contact Page autocomplete validation only.
 * Skips all other suites (mobile, performance, a11y, element presence, etc.)
 *
 * Usage:
 *   node run-autocomplete.js
 *   node run-autocomplete.js --url=https://www.nationwide.com/
 *   node run-autocomplete.js --headless
 *   node run-autocomplete.js --contact-only
 *   node run-autocomplete.js --desktop-only
 */

import { chromium }  from 'playwright';
import fs            from 'fs';
import path          from 'path';
import { fileURLToPath } from 'url';
import { config }    from './core/config.js';
import { waitForPageReady } from './utils/helpers.js';
import { testDesktopSearchOnDevice }          from './tests/desktop.js';
import { testContactPageAdvancedAutocomplete } from './tests/advanced.js';

const __dir      = path.dirname(fileURLToPath(import.meta.url));
const LOG_FILE   = path.join(__dir, 'autocomplete-run.log');
const JSON_FILE  = path.join(__dir, 'autocomplete-results.json');
const HTML_FILE  = path.join(__dir, 'autocomplete-results.html');

const headless    = process.argv.includes('--headless');
const contactOnly = process.argv.includes('--contact-only');
const desktopOnly = process.argv.includes('--desktop-only');

// Write to both stdout AND log file simultaneously
const logLines = [];
fs.writeFileSync(LOG_FILE, `=== run-autocomplete.js started ${new Date().toISOString()} ===\n`, 'utf8');
const log = (...args) => {
  const line = args.join(' ');
  process.stdout.write(line + '\n');
  logLines.push(line);
  try { fs.appendFileSync(LOG_FILE, line + '\n', 'utf8'); } catch (_) {}
};

function badge(s) {
  return s === 'PASSED' ? '✓ PASSED' : s === 'FAILED' ? '✗ FAILED' :
         s === 'WARN'   ? '⚠ WARN'   : `~ ${s}`;
}

function printResults(label, results) {
  log(`\n${'-'.repeat(62)}`);
  log(` ${label}`);
  log('-'.repeat(62));
  const arr = Array.isArray(results) ? results : (results?.results || []);
  for (const r of arr) {
    const name   = r.test || r.name || '?';
    const detail = r.detail || r.error || '';
    log(`  ${badge(r.status).padEnd(12)} ${name}${detail ? `  — ${detail.substring(0,80)}` : ''}`);
  }
  const p = arr.filter(r => r.status === 'PASSED').length;
  const f = arr.filter(r => r.status === 'FAILED').length;
  const w = arr.filter(r => r.status === 'WARN').length;
  log(`\n  Summary: ${p} passed | ${f} failed | ${w} warn`);
}

function buildHtml(summary, totalPassed, totalFailed, totalWarn, elapsed) {
  const e = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  const rowCls = s => s === 'FAILED' ? ' style="background:#ffe8e8"' :
                      s === 'WARN'   ? ' style="background:#fff8dc"' :
                      s === 'PASSED' ? ' style="background:#e8f8e8"' : '';
  const badgeHtml = s => s === 'PASSED' ? `<span style="color:#1a7a1a;font-weight:bold">✓ PASSED</span>` :
                         s === 'FAILED' ? `<span style="color:#c0001a;font-weight:bold">✗ FAILED</span>` :
                         s === 'WARN'   ? `<span style="color:#b86800;font-weight:bold">⚠ WARN</span>`  :
                         `<span>${e(s)}</span>`;

  let sections = '';
  for (const [section, data] of Object.entries(summary)) {
    const arr = Array.isArray(data) ? data : (data?.results || []);
    const label = section === 'desktop' ? 'Desktop Autocomplete (6 Tests)' : 'Contact Page Advanced Autocomplete (7 Tests)';
    const rows = arr.map(r =>
      `<tr${rowCls(r.status)}><td>${e(r.test||r.name||'?')}</td><td>${badgeHtml(r.status)}</td><td style="color:#555;font-size:12px">${e((r.detail||r.error||'').substring(0,120))}</td></tr>`
    ).join('');
    sections += `<h2 style="margin-top:28px;color:#003366">${label}</h2>
    <table border="1" cellpadding="6" cellspacing="0" style="border-collapse:collapse;width:100%;font-size:13px">
      <thead><tr style="background:#003366;color:#fff"><th align="left">Test</th><th>Status</th><th align="left">Detail</th></tr></thead>
      <tbody>${rows}</tbody></table>`;
  }

  const overall = totalFailed > 0 ? '#c0001a' : totalWarn > 0 ? '#b86800' : '#1a7a1a';
  return `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<title>Autocomplete Validation Results</title></head>
<body style="font-family:Segoe UI,sans-serif;margin:30px;color:#1e2235">
<h1 style="color:#003366">Autocomplete Validation Results</h1>
<p><strong>URL:</strong> ${e(config.homeUrl)} &nbsp;|&nbsp;
   <strong>Mode:</strong> ${e(contactOnly?'Contact Only':desktopOnly?'Desktop Only':'Desktop + Contact')} &nbsp;|&nbsp;
   <strong>Time:</strong> ${elapsed}s &nbsp;|&nbsp;
   <strong>Run:</strong> ${new Date().toLocaleString()}</p>
<div style="display:flex;gap:16px;margin:16px 0">
  <div style="padding:12px 24px;background:#e8f8e8;border-radius:8px;font-size:18px;font-weight:bold;color:#1a7a1a">${totalPassed} Passed</div>
  <div style="padding:12px 24px;background:#ffe8e8;border-radius:8px;font-size:18px;font-weight:bold;color:#c0001a">${totalFailed} Failed</div>
  <div style="padding:12px 24px;background:#fff8dc;border-radius:8px;font-size:18px;font-weight:bold;color:#b86800">${totalWarn} Warn</div>
  <div style="padding:12px 24px;background:${overall};border-radius:8px;font-size:18px;font-weight:bold;color:#fff">${totalFailed===0?'ALL PASSED':'FAILURES FOUND'}</div>
</div>
${sections}
<details style="margin-top:28px"><summary style="cursor:pointer;font-weight:bold">Full Console Log</summary>
<pre style="background:#111;color:#eee;padding:14px;border-radius:6px;font-size:11px;overflow:auto;max-height:500px">${e(logLines.join('\n'))}</pre></details>
</body></html>`;
}

(async () => {
  log(`\n${'='.repeat(62)}`);
  log('  AUTOCOMPLETE VALIDATION — STANDALONE RUN');
  log(`  URL     : ${config.homeUrl}`);
  log(`  Headless: ${headless}`);
  log(`  Mode    : ${contactOnly ? 'Contact Only' : desktopOnly ? 'Desktop Only' : 'Desktop + Contact'}`);
  log(`  Results : ${HTML_FILE}`);
  log('='.repeat(62));

  let browser, page;
  const overallStart = Date.now();
  const summary = {};

  try {
    browser     = await chromium.launch({ headless, slowMo: headless ? 0 : 80 });
    const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    page        = await context.newPage();
    if (!contactOnly) {
      log(`\n${'='.repeat(62)}\n  DESKTOP AUTOCOMPLETE\n${'='.repeat(62)}`);
      await page.goto(config.homeUrl, { waitUntil: 'domcontentloaded', timeout: 40000 });
      await waitForPageReady(page);
      const dr = await testDesktopSearchOnDevice(page, { name: 'Desktop Chrome', width: 1280, height: 800, isMobile: false });
      printResults('Desktop Autocomplete Results', dr.results);
      summary.desktop = dr;
    }

    if (!desktopOnly) {
      log(`\n${'='.repeat(62)}\n  CONTACT PAGE — ADVANCED AUTOCOMPLETE\n${'='.repeat(62)}`);
      const CONTACT_URL = `${config.homeUrl.replace(/\/$/,'')}/personal/contact/`;
      await page.goto(CONTACT_URL, { waitUntil: 'domcontentloaded', timeout: 40000 });
      await waitForPageReady(page);
      log(`  URL: ${page.url()}`);
      const cr = await testContactPageAdvancedAutocomplete(page);
      printResults('Contact Page Autocomplete Results', cr.results);
      summary.contact = cr;
    }

  } catch (err) {
    log(`\n  FATAL: ${err.message}\n${err.stack}`);
  } finally {
    const elapsed = ((Date.now() - overallStart) / 1000).toFixed(1);
    let totalPassed = 0, totalFailed = 0, totalWarn = 0;

    log(`\n${'='.repeat(62)}\n  OVERALL SUMMARY\n${'='.repeat(62)}`);
    for (const [section, data] of Object.entries(summary)) {
      const arr = Array.isArray(data) ? data : (data?.results || []);
      const p = arr.filter(r => r.status === 'PASSED').length;
      const f = arr.filter(r => r.status === 'FAILED').length;
      const w = arr.filter(r => r.status === 'WARN').length;
      totalPassed += p; totalFailed += f; totalWarn += w;
      log(`  ${(section==='desktop'?'Desktop Autocomplete':'Contact Advanced').padEnd(28)}: ${p} passed, ${f} failed, ${w} warn`);
    }
    log('-'.repeat(62));
    log(`  TOTAL: ${totalPassed} passed | ${totalFailed} failed | ${totalWarn} warn`);
    log(`  Time : ${elapsed}s`);
    log('='.repeat(62));

    // Write log + JSON + HTML
    fs.writeFileSync(LOG_FILE,  logLines.join('\n'), 'utf8');
    fs.writeFileSync(JSON_FILE, JSON.stringify({ summary, totalPassed, totalFailed, totalWarn, elapsed, ts: new Date().toISOString() }, null, 2), 'utf8');
    fs.writeFileSync(HTML_FILE, buildHtml(summary, totalPassed, totalFailed, totalWarn, elapsed), 'utf8');

    log(`\n  Log  : ${LOG_FILE}`);
    log(`  JSON : ${JSON_FILE}`);
    log(`  HTML : ${HTML_FILE}`);

    await browser?.close();
    process.exit(totalFailed > 0 ? 1 : 0);
  }
})();
