/**
 * reporting/json-writer.js
 * Saves test results to JSON, computes trends vs previous run.
 */

import fs from 'fs';
import path from 'path';
import { REPORTS_DIR } from '../core/config.js';

const RESULTS_FILE = path.join(REPORTS_DIR, 'test-results.json');

export function loadPreviousResults() {
  try {
    if (fs.existsSync(RESULTS_FILE)) {
      const prev = JSON.parse(fs.readFileSync(RESULTS_FILE, 'utf8'));
      console.log(`\n Previous run loaded: ${prev.summary?.successRate || '?'} (${prev.startTime?.substring(0, 10) || '?'})`);
      return prev;
    }
  } catch { /* ignore */ }
  return null;
}

export function computeTrend(current, previous) {
  if (!previous?.summary) return null;
  const prevRate    = parseFloat(previous.summary.successRate) || 0;
  const currRate    = parseFloat(current.summary?.successRate) || 0;
  const prevPassed  = previous.summary.passedTests || 0;
  const currPassed  = current.summary?.passedTests || 0;
  return {
    previousDate:  previous.startTime || null,
    previousRate:  previous.summary.successRate || '?',
    previousPassed: prevPassed,
    passedDelta:   currPassed - prevPassed,
    rateDelta:     (currRate - prevRate).toFixed(1),
  };
}

export function writeResults(results) {
  fs.mkdirSync(REPORTS_DIR, { recursive: true });
  fs.writeFileSync(RESULTS_FILE, JSON.stringify(results, null, 2), 'utf8');
  console.log(`\n Results saved: ${RESULTS_FILE}`);
}
