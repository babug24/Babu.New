/**
 * core/retry.js
 * Retry wrapper, failure screenshot capture.
 */

import path from 'path';
import { config, SCREENSHOTS_DIR, trunc } from './config.js';

/**
 * Run fn up to maxRetries times with exponential back-off.
 * On every failure logs attempt/label; rethrows the last error.
 */
export async function withRetry(fn, label, maxRetries = config.retries) {
  let lastError;
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const result = await fn();
      if (attempt > 1) console.log(`    Passed on retry #${attempt}: ${label}`);
      return result;
    } catch (err) {
      lastError = err;
      console.log(`    Attempt ${attempt}/${maxRetries} failed [${label}]: ${trunc(err.message)}`);
      if (attempt < maxRetries) await new Promise(r => setTimeout(r, 1500 * attempt));
    }
  }
  throw lastError;
}

/**
 * Capture a PNG screenshot on test failure.
 * Filename: FAIL-<safe-label>-<timestamp>.png
 * Returns the file path or null on error.
 */
export async function captureFailureScreenshot(page, label) {
  try {
    const safe = label.replace(/[^a-z0-9]+/gi, '-').toLowerCase().substring(0, 60);
    const file = path.join(SCREENSHOTS_DIR, `FAIL-${safe}-${Date.now()}.png`);
    await page.screenshot({ path: file, fullPage: false });
    console.log(`   Screenshot: ${file}`);
    return file;
  } catch { return null; }
}

/**
 * Simple high-resolution timer factory (re-exported from config for convenience).
 */
export { timer } from './config.js';
