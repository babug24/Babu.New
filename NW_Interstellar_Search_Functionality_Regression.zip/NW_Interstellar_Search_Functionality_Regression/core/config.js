/**
 * core/config.js
 * Central configuration, constants, and lightweight utilities.
 * Import this everywhere instead of re-declaring inline.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// ── Directory resolution ─────────────────────────────────────────────────────
export const ROOT_DIR        = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
export const SCREENSHOTS_DIR = path.join(ROOT_DIR, 'Screenshots');
export const REPORTS_DIR     = path.join(ROOT_DIR, 'reports');

// Ensure directories exist on first import
for (const dir of [SCREENSHOTS_DIR, REPORTS_DIR]) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

// ── Load URLs from url.csv ────────────────────────────────────────────────────
// Supports both tab-separated and comma-separated CSV.
// Columns: Environment, url, type   (type = 'angular' | 'prod' | '')
// To add a new Angular URL: add a row with type=angular — no code changes needed.
function loadUrlsFromCsv() {
  const csvPath = path.join(ROOT_DIR, 'url.csv');
  if (!fs.existsSync(csvPath)) return { map: {}, angularUrls: new Set() };
  const lines = fs.readFileSync(csvPath, 'utf-8').trim().split('\n').slice(1);
  const map = {};
  const angularUrls = new Set();
  for (const line of lines) {
    if (!line.trim()) continue;
    // Handle both tab and comma separators
    const sep   = line.includes('\t') ? '\t' : ',';
    const parts = line.split(sep).map(s => s.trim().replace(/^"|"$/g, ''));
    const [env, url, type] = parts;
    if (!env || !url) continue;
    const cleanUrl = url.replace(/\/$/, '');
    map[env.toLowerCase()] = cleanUrl;
    if (type && type.toLowerCase() === 'angular') angularUrls.add(cleanUrl);
  }
  return { map, angularUrls };
}
const { map: URL_MAP, angularUrls: ANGULAR_ENV_URLS_SET } = loadUrlsFromCsv();

// Set of known Angular base URLs (populated from url.csv type=angular rows).
// Add any new Angular environment there — no code changes needed.
export const ANGULAR_ENV_URLS = ANGULAR_ENV_URLS_SET;

// ── CLI / env URL resolution ─────────────────────────────────────────────────
// Priority: --url=<direct> > --env=<name from csv> > BASE_URL env var > Prod entry in csv > hardcoded fallback
const _cliUrl = process.argv.find(a => a.startsWith('--url='))?.split('=').slice(1).join('=');
const _cliEnv = process.argv.find(a => a.startsWith('--env='))?.split('=').slice(1).join('=');
const _envUrl = _cliEnv ? URL_MAP[_cliEnv.toLowerCase()] : undefined;
export const BASE_URL = (
  _cliUrl ||
  _envUrl ||
  process.env.BASE_URL ||
  URL_MAP['Prod'] ||
  'https://www.nationwide.com/'
).replace(/\/$/, '');

// --angular CLI flag: forces Angular selector mode regardless of URL.
// Use when pointing to an Angular env whose domain isn't in url.csv yet.
export const CLI_ANGULAR_FLAG = process.argv.includes('--angular');

console.log(` Target ENV: ${_cliEnv || process.env.BASE_URL ? 'custom' : 'Prod'} | URL: ${BASE_URL}${CLI_ANGULAR_FLAG ? ' | mode: ANGULAR (--angular flag)' : ''}`);

// ── Main configuration object ─────────────────────────────────────────────────
export const config = {
  timeout:      60000,
  shortTimeout: 10000,
  homeUrl:      BASE_URL,
  contactPath:  '/personal/contact',
  // Search Results page — base URL (empty-state, no pre-filled query).
  // Full empty-state URL: https://uat.nationwide.com/searchresults/personal/result?=&referrerPageUrl=&query=
  // Full query URL example: https://uat.nationwide.com/searchresults/personal/result?query=auto+insurance
  searchResultsPath:       '/searchresults/personal/result',
  searchResultsBaseUrl:    '/searchresults/personal/result?=&referrerPageUrl=&query=',
  searchResultsQueryParam: 'query',
  retries:      3,
  slowMo:       100,
  headless:     false,
  headers: {
    'User-Agent':      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
    'DNT':             '1',
    'Connection':      'keep-alive'
  }
};

// ── Third-party ad/analytics domains to block ─────────────────────────────────
export const IGNORED_DOMAINS = [
  'doubleclick.net', 'googleadservices.com', 'googlesyndication.com',
  'google-analytics.com', 'googletagmanager.com', 'googletagservices.com',
  'analytics.google.com', 'facebook.net', 'connect.facebook.net',
  'bat.bing.com', 'stats.g.doubleclick.net', 'bidswitch.net',
  'rubiconproject.com', 'pubmatic.com', 'openx.net', 'casalemedia.com',
  'criteo.com', 'amazon-adsystem.com', 'adnxs.com', 'taboola.com',
  'scorecardresearch.com', 'quantserve.com', 'chartbeat.com',
  'hotjar.com', 'fullstory.com', 'heap.io', 'segment.io', 'mixpanel.com',
];
export const isThirdParty = (url) => IGNORED_DOMAINS.some(d => url.includes(d));

// ── Console output helper ─────────────────────────────────────────────────────
const TRUNC_LEN = 120;
export function trunc(msg, len = TRUNC_LEN) {
  if (!msg) return '';
  const s = String(msg);
  return s.length > len ? s.substring(0, len) + ` (+${s.length - len} chars)` : s;
}

// ── High-resolution timer ─────────────────────────────────────────────────────
export function timer() {
  const start = Date.now();
  return () => Date.now() - start;
}

// ── Insurance-domain search terms (Nationwide.com) ────────────────────────────
// Single source of truth — import and use these in every test file.
// Changing terms here propagates to all suites automatically.
export const SEARCH_TERMS = {
  // ── Short prefix stems (trigger autocomplete, build char-by-char) ──────────
  stem1:       'po',          // builds → 'pol' → 'poli' (policy)
  stem1b:      'l',           // continuation char: 'po' → 'pol'
  stem1c:      'i',           // continuation char: 'pol' → 'poli'
  stem2:       'pr',          // builds → 'pre' → 'prem' (premium)
  stem2b:      'e',           // continuation char: 'pr' → 'pre'
  stem2c:      'm',           // continuation char: 'pre' → 'prem'
  stem3:       'co',          // coverage / contact / collision
  stem4:       'ins',         // insurance — reliable 10-item list prefix
  stem5:       'cl',          // claim — builds 'cl' → 'cla' → 'clai'
  stem5b:      'a',           // continuation: 'cl' → 'cla'
  stem5c:      'i',           // continuation: 'cla' → 'clai'

  // ── Full single-word / short phrase terms ─────────────────────────────────
  autoInsurance:     'auto insurance',
  homeInsurance:     'homeowners insurance',
  rentersInsurance:  'renters insurance',
  lifeInsurance:     'life insurance',
  policyDetails:     'policy details',
  policyRenewal:     'policy renewal',
  fileClaim:         'file a claim',
  claimStatus:       'check claim status',
  premiumPayment:    'premium payment',
  coverage:          'coverage options',
  roadside:          'roadside assistance',
  deductible:        'deductible',
  petInsurance:      'pet insurance',
  condoInsurance:    'condo insurance',
  carAccident:       'car accident',

  // ── Edge-case / dynamic-update pair ───────────────────────────────────────
  dynamicShort:  'po',        // first snapshot
  dynamicMid:    'pol',       // mid snapshot
  dynamicFull:   'poli',      // final snapshot

  // ── Autocomplete option-count prefix (must reliably return 10 items) ──────
  countTerm:     'ins',       // "ins" → insurance / inspect / … → 10 Yext results

  // ── No-results terms (gibberish — intentionally return 0 hits) ────────────
  noResult1:  'qzxnoresult99insurance',
  noResult2:  'zzznoresultnw2026',
  noResult3:  'asdfghjklnwinsure',

  // ── Content-validation terms (expect real results page) ───────────────────
  contentTerms: [
    { term: 'auto insurance',    expectResults: true },
    { term: 'file a claim',      expectResults: true },
    { term: 'premium payment',   expectResults: true },
  ],

  // ── Analytics tracking terms ──────────────────────────────────────────────
  analyticsSubmit:    'renters insurance',
  analyticsNoResults: 'qzxnoresult99insurance',
};
