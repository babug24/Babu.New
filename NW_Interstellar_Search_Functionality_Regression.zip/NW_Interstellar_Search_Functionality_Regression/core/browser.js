/**
 * core/browser.js
 * Launches Playwright browser + context, wires noise filters and monitors.
 * Returns { browser, context, page, monitors } where monitors holds the
 * live arrays that accumulate console errors, network warnings, API calls.
 *
 * ── Permission Handling Strategy ────────────────────────────────────────────
 * uat-ng.nationwide.com (Angular) triggers browser permission prompts for
 * local-network, notifications, and clipboard access.  We suppress them via:
 *
 *   1. context permissions: []  — pre-grants permissions at the context level
 *      (Playwright sends CDP Page.grantPermissions before any navigation).
 *
 *   2. chromium launch args  — Chrome/Edge flags that silence OS-level popups
 *      that Playwright's permissions API cannot intercept:
 *        --disable-features=PrivateNetworkAccessPermissionPrompt
 *        --allow-insecure-localhost
 *        --unsafely-treat-insecure-origin-as-secure
 *
 *   3. launchPersistentBrowser() — enterprise fallback that reuses a saved
 *      Chrome profile (./user-data-dir) so the popup never shows again once
 *      the user has accepted it manually on the first run.
 */

import { chromium }         from 'playwright';
import path                 from 'path';
import { config, isThirdParty, trunc, SCREENSHOTS_DIR, ROOT_DIR } from './config.js';
import { registerCookieAutoDismiss } from '../utils/helpers.js';
import { execSync }         from 'child_process';
import fs                   from 'fs';

// ── Shared launch args — suppress all permission prompts ─────────────────────
const CHROME_ARGS = [
  // Disable the "Allow [site] to access devices on your local network?" popup
  '--disable-features=PrivateNetworkAccessPermissionPrompt,PrivateNetworkAccessRespectPreflightResults',
  // Prevent generic permission UI popups from blocking automation
  '--disable-popup-blocking',
  '--use-fake-ui-for-media-stream',        // auto-accept camera/mic (no OS dialog)
  '--use-fake-device-for-media-stream',
  '--allow-insecure-localhost',
  // Suppress "Restore pages?" and profile-related prompts
  '--no-first-run',
  '--no-default-browser-check',
  '--disable-extensions-except=',
  '--disable-background-networking',
];

// Permissions pre-granted on the browser context before first navigation
const CONTEXT_PERMISSIONS = [
  'notifications',
  'clipboard-read',
  'clipboard-write',
];

export async function launchBrowser() {
  const browser  = await chromium.launch({
    headless: config.headless,
    slowMo:   config.slowMo,
    args:     CHROME_ARGS,
  });
  const context  = await browser.newContext({
    extraHTTPHeaders: config.headers,
    permissions:      CONTEXT_PERMISSIONS,   // ← pre-grant before any page loads
  });
  await context.tracing.start({ screenshots: true, snapshots: true });

  // Grant permissions for the specific origin so no runtime prompt appears.
  // This covers local-network access requests on uat-ng.nationwide.com.
  const origins = [
    config.homeUrl,
    // Also pre-grant prod origin — strips any Angular subdomain prefix
    config.homeUrl.replace(/\/(uat-ng|ng|angular)\./i, '/www.'),
  ].filter((v, i, a) => v && a.indexOf(v) === i); // deduplicate
  for (const origin of origins) {
    try {
      await context.grantPermissions(CONTEXT_PERMISSIONS, { origin });
    } catch { /* permission type not supported on this platform — ignored */ }
  }

  const page = await context.newPage();
  await page.setExtraHTTPHeaders(config.headers);
  registerCookieAutoDismiss(page);

  // Block third-party tracking requests at the network level
  await page.route('**/*', (route) => {
    if (isThirdParty(route.request().url())) route.abort().catch(() => {});
    else route.continue().catch(() => {});
  });

  // Live monitor arrays — populated as the run progresses
  const monitors = {
    consoleErrors:      [],
    networkWarnings:    [],
    autocompleteApiCalls: []
  };

  page.on('console', msg => {
    if (msg.type() !== 'error') return;
    const text = msg.text();
    if (text.includes('Failed to load resource') && text.includes('403')) return;
    const loc = msg.location()?.url || '';
    if (isThirdParty(loc)) return;
    monitors.consoleErrors.push({ text, location: msg.location(), time: new Date().toISOString() });
    console.log(`  [WARN]  [CONSOLE ERROR] ${trunc(text)}`);
  });

  page.on('pageerror', err => {
    if (isThirdParty(err.message)) return;
    monitors.consoleErrors.push({ text: err.message, type: 'pageerror', time: new Date().toISOString() });
    console.log(`  [ERROR] [PAGE ERROR] ${trunc(err.message)}`);
  });

  page.on('response', resp => {
    const url    = resp.url();
    const status = resp.status();
    if (url.includes('autocomplete') || url.includes('suggestall') || url.includes('entities/autocomplete')) {
      monitors.autocompleteApiCalls.push({ url: url.substring(0, 120), status, time: new Date().toISOString() });
    }
    if (status >= 400 && url.includes('nationwide.com') && !isThirdParty(url)) {
      monitors.networkWarnings.push({ url: url.substring(0, 120), status, time: new Date().toISOString() });
      console.log(`    [NETWORK ${status}] ${url.substring(0, 100)}`);
    }
  });

  return { browser, context, page, monitors };
}

// ── Persistent context browser (enterprise fallback) ────────────────────────
// Use this when the OS-level "local network access" prompt cannot be suppressed
// by flags alone (common on Windows + managed Chrome).  The saved profile in
// ./user-data-dir remembers the user's past grant, so the popup never returns.
//
// First run: start headless:false, manually click "Allow" once, then Ctrl+C.
// All subsequent runs: popup is gone — safe to use headless:true.
//
// Usage in run-e2e.js:
//   import { launchPersistentBrowser } from './core/browser.js';
//   const { context, page, monitors } = await launchPersistentBrowser();
export async function launchPersistentBrowser() {
  const userDataDir = path.join(ROOT_DIR, 'user-data-dir');
  fs.mkdirSync(userDataDir, { recursive: true });

  // launchPersistentContext does NOT have a separate browser handle —
  // context IS the top-level object (it has .newPage(), .close(), etc.)
  const context = await chromium.launchPersistentContext(userDataDir, {
    headless: config.headless,
    slowMo:   config.slowMo,
    args:     CHROME_ARGS,
    permissions: CONTEXT_PERMISSIONS,
    extraHTTPHeaders: config.headers,
  });

  for (const origin of [config.homeUrl]) {
    try { await context.grantPermissions(CONTEXT_PERMISSIONS, { origin }); } catch { /* ignored */ }
  }

  await context.tracing.start({ screenshots: true, snapshots: true });

  const page = await context.newPage();
  await page.setExtraHTTPHeaders(config.headers);
  registerCookieAutoDismiss(page);

  await page.route('**/*', (route) => {
    if (isThirdParty(route.request().url())) route.abort().catch(() => {});
    else route.continue().catch(() => {});
  });

  const monitors = { consoleErrors: [], networkWarnings: [], autocompleteApiCalls: [] };

  page.on('console', msg => {
    if (msg.type() !== 'error') return;
    const text = msg.text();
    if (text.includes('Failed to load resource') && text.includes('403')) return;
    const loc = msg.location()?.url || '';
    if (isThirdParty(loc)) return;
    monitors.consoleErrors.push({ text, location: msg.location(), time: new Date().toISOString() });
    console.log(`  [WARN]  [CONSOLE ERROR] ${trunc(text)}`);
  });

  page.on('pageerror', err => {
    if (isThirdParty(err.message)) return;
    monitors.consoleErrors.push({ text: err.message, type: 'pageerror', time: new Date().toISOString() });
    console.log(`  [ERROR] [PAGE ERROR] ${trunc(err.message)}`);
  });

  page.on('response', resp => {
    const url    = resp.url();
    const status = resp.status();
    if (url.includes('autocomplete') || url.includes('suggestall') || url.includes('entities/autocomplete')) {
      monitors.autocompleteApiCalls.push({ url: url.substring(0, 120), status, time: new Date().toISOString() });
    }
    if (status >= 400 && url.includes('nationwide.com') && !isThirdParty(url)) {
      monitors.networkWarnings.push({ url: url.substring(0, 120), status, time: new Date().toISOString() });
      console.log(`    [NETWORK ${status}] ${url.substring(0, 100)}`);
    }
  });

  // persistent context: browser === context (no separate browser object)
  return { browser: context, context, page, monitors };
}

// ── Auto-generate HTML report from saved JSON ─────────────────────────────────
export function generateHtmlReport() {
  if (!fs.existsSync('report-from-json.js')) return;
  try {
    console.log('\n Generating HTML report...');
    execSync('node report-from-json.js', { stdio: 'inherit' });
    try { execSync('start reports\\test-report.html', { shell: 'cmd.exe', stdio: 'ignore' }); } catch {}
  } catch (e) {
    console.warn('  Could not auto-generate report:', trunc(e.message));
  }
}
