/**
 * tests/perf-a11y.js
 * Performance timing test and WCAG 2.2 Level AA accessibility compliance checks.
 *
 * WCAG 2.2 Level AA Criteria Covered:
 * ─────────────────────────────────────────────────────────────────────────────
 * 1.1.1  Non-text Content (A)          – Image alt text validation
 * 1.3.1  Info and Relationships (A)    – Heading hierarchy, form labels, landmarks
 * 1.4.3  Contrast Minimum (AA)         – Text color contrast ratio ≥ 4.5:1
 * 1.4.4  Resize Text (AA)              – Text resizable up to 200%
 * 1.4.11 Non-text Contrast (AA)        – UI component contrast ≥ 3:1
 * 1.4.12 Text Spacing (AA)             – Content readable with adjusted text spacing
 * 2.1.1  Keyboard (A)                  – All interactive elements keyboard-accessible
 * 2.1.2  No Keyboard Trap (A)          – Tab focus can escape all components
 * 2.4.1  Bypass Blocks (A)             – Skip navigation link present
 * 2.4.2  Page Titled (A)               – Descriptive page title
 * 2.4.3  Focus Order (A)               – Logical tab sequence
 * 2.4.4  Link Purpose (A)              – Links have discernible text
 * 2.4.7  Focus Visible (AA)            – Keyboard focus indicator visible
 * 2.4.11 Focus Not Obscured (AA)       – Focused element not fully hidden (WCAG 2.2)
 * 2.5.8  Target Size Minimum (AA)      – Interactive targets ≥ 24×24 CSS px (WCAG 2.2)
 * 3.1.1  Language of Page (A)          – Valid lang attribute on <html>
 * 3.3.2  Labels or Instructions (A)    – Form inputs have associated labels
 * 3.3.8  Accessible Authentication (AA)– No cognitive test for auth (WCAG 2.2)
 * 4.1.2  Name, Role, Value (A)         – ARIA attributes valid on interactive elements
 */

import { config, SEARCH_TERMS } from '../core/config.js';
import { waitForPageReady, findAndActivateSearch, dismissCookieBanner } from '../utils/helpers.js';

// ═══════════════════════════════════════════════════════════════════════════════
//  PERFORMANCE TESTING
// ═══════════════════════════════════════════════════════════════════════════════

export async function testPerformance(page) {
  console.log('\n' + '='.repeat(60));
  console.log(' PERFORMANCE TESTING');
  console.log('='.repeat(60));

  const metrics = {};

  const navStart = Date.now();
  await page.goto(config.homeUrl, { waitUntil: 'load', timeout: 30000 });
  await dismissCookieBanner(page).catch(() => {});
  await page.evaluate(() => window.scrollTo(0, 0)).catch(() => {});
  await waitForPageReady(page, { networkTimeout: 1, finalBuffer: 200 });
  metrics.pageLoadTime = Date.now() - navStart;
  console.log(`  Page load: ${metrics.pageLoadTime}ms ${metrics.pageLoadTime < 4000 ? 'OK' : 'SLOW'}`);

  const searchBox = await findAndActivateSearch(page, false);
  await searchBox.scrollIntoViewIfNeeded();
  await searchBox.click({ force: true });
  await searchBox.fill(SEARCH_TERMS.autoInsurance);
  await page.waitForTimeout(500);

  const searchStart = Date.now();
  await page.keyboard.press('Enter');
  await page.waitForURL(/searchresults/, { timeout: 15000 }).catch(() => {});
  metrics.searchResponseTime = Date.now() - searchStart;
  console.log(`  Search response: ${metrics.searchResponseTime}ms ${metrics.searchResponseTime < 3000 ? 'OK' : 'SLOW'}`);

  metrics.performanceStatus =
    (metrics.pageLoadTime < 4000 && metrics.searchResponseTime < 4000) ? 'PASSED' : 'WARNING';

  return metrics;
}

// ═══════════════════════════════════════════════════════════════════════════════
//  WCAG 2.2 LEVEL AA — ACCESSIBILITY TESTING
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Runs comprehensive WCAG 2.2 Level AA accessibility checks against the page.
 * Returns an object with violations[], passed[], and a weighted score (0–100).
 */
export async function testAccessibility(page) {
  console.log('\n' + '='.repeat(60));
  console.log(' ACCESSIBILITY TESTING — WCAG 2.2 Level AA');
  console.log('='.repeat(60));

  const results = { violations: [], passed: [], warnings: [], score: 0 };

  await page.goto(config.homeUrl, { waitUntil: 'domcontentloaded' });
  await dismissCookieBanner(page).catch(() => {});
  await waitForPageReady(page);

  // ─── WCAG 3.1.1: Language of Page ──────────────────────────────────────────
  const langCheck = await page.evaluate(() => {
    const html = document.documentElement;
    const lang = html.getAttribute('lang');
    return { hasLang: !!lang, lang, valid: /^[a-z]{2,3}(-[A-Z]{2,4})?$/.test(lang || '') };
  });
  logCheck('3.1.1 Language of Page', langCheck.valid, results,
    'Page has valid lang attribute: ' + langCheck.lang,
    `Missing or invalid lang attribute on <html> (found: "${langCheck.lang || 'none'}")`);

  // ─── WCAG 2.4.2: Page Titled ──────────────────────────────────────────────
  const titleCheck = await page.evaluate(() => {
    const title = document.title?.trim();
    return { hasTitle: !!title, title, minLength: (title?.length || 0) >= 3 };
  });
  logCheck('2.4.2 Page Titled', titleCheck.hasTitle && titleCheck.minLength, results,
    `Page has descriptive title: "${titleCheck.title}"`,
    'Page is missing a descriptive <title> element');

  // ─── WCAG 1.3.1: Heading Hierarchy ────────────────────────────────────────
  const headingCheck = await page.evaluate(() => {
    const headings = [...document.querySelectorAll('h1, h2, h3, h4, h5, h6')];
    const levels = headings.map(h => parseInt(h.tagName[1]));
    const hasH1 = levels.includes(1);
    const h1Count = levels.filter(l => l === 1).length;
    let skipped = false;
    for (let i = 1; i < levels.length; i++) {
      if (levels[i] - levels[i - 1] > 1) { skipped = true; break; }
    }
    return { hasH1, h1Count, skipped, totalHeadings: headings.length };
  });
  logCheck('1.3.1 Heading Hierarchy', headingCheck.hasH1 && !headingCheck.skipped, results,
    `Heading hierarchy is valid (${headingCheck.totalHeadings} headings, starts with H1)`,
    `Heading hierarchy issue: ${!headingCheck.hasH1 ? 'No H1 found' : 'Heading levels skipped'}`);
  if (headingCheck.h1Count > 1) {
    results.warnings.push(`Multiple H1 elements found (${headingCheck.h1Count}) — consider single H1 per page`);
  }

  // ─── WCAG 1.1.1: Non-text Content (Image Alt Text) ────────────────────────
  const imageAltCheck = await page.evaluate(() => {
    const images = [...document.querySelectorAll('img')];
    const missingAlt = images.filter(img => {
      const alt = img.getAttribute('alt');
      const role = img.getAttribute('role');
      // Decorative images should have alt="" or role="presentation"
      if (role === 'presentation' || role === 'none') return false;
      return alt === null; // alt="" is valid for decorative images
    });
    return {
      total: images.length,
      missingAlt: missingAlt.length,
      missingExamples: missingAlt.slice(0, 3).map(i => i.src?.substring(0, 80))
    };
  });
  logCheck('1.1.1 Non-text Content', imageAltCheck.missingAlt === 0, results,
    `All ${imageAltCheck.total} images have alt attributes`,
    `${imageAltCheck.missingAlt}/${imageAltCheck.total} images missing alt attribute`);

  // ─── WCAG 2.4.1: Bypass Blocks (Skip Navigation) ──────────────────────────
  const skipNavCheck = await page.evaluate(() => {
    // Check for skip-to-main-content link (visible or off-screen until focused)
    const skipLinks = document.querySelectorAll(
      'a[href="#main"], a[href="#main-content"], a[href="#content"], ' +
      'a[class*="skip"], a[class*="Skip"], [class*="skip-nav"], [class*="skip-to"]'
    );
    // Also check for landmark roles as alternative bypass mechanism
    const hasMainLandmark = !!document.querySelector('main, [role="main"]');
    const hasNavLandmark = !!document.querySelector('nav, [role="navigation"]');
    return {
      hasSkipLink: skipLinks.length > 0,
      hasMainLandmark,
      hasNavLandmark,
      hasBypassMechanism: skipLinks.length > 0 || hasMainLandmark
    };
  });
  logCheck('2.4.1 Bypass Blocks', skipNavCheck.hasBypassMechanism, results,
    `Bypass mechanism present (skip link: ${skipNavCheck.hasSkipLink}, main landmark: ${skipNavCheck.hasMainLandmark})`,
    'No skip navigation link or main landmark found — users cannot bypass repeated content');

  // ─── WCAG 1.3.1: Landmark Regions ─────────────────────────────────────────
  const landmarkCheck = await page.evaluate(() => {
    const landmarks = {
      banner: !!document.querySelector('header, [role="banner"]'),
      navigation: !!document.querySelector('nav, [role="navigation"]'),
      main: !!document.querySelector('main, [role="main"]'),
      contentinfo: !!document.querySelector('footer, [role="contentinfo"]')
    };
    return landmarks;
  });
  const landmarkPassed = landmarkCheck.banner && landmarkCheck.main && landmarkCheck.navigation;
  logCheck('1.3.1 Landmark Regions', landmarkPassed, results,
    'Required landmarks present (banner, navigation, main)',
    `Missing landmarks: ${!landmarkCheck.banner ? 'banner ' : ''}${!landmarkCheck.navigation ? 'navigation ' : ''}${!landmarkCheck.main ? 'main' : ''}`);

  // ─── WCAG 2.4.4: Link Purpose ─────────────────────────────────────────────
  const linkPurposeCheck = await page.evaluate(() => {
    const links = [...document.querySelectorAll('a[href]')];
    const problematic = links.filter(a => {
      const text = (a.textContent || '').trim().toLowerCase();
      const ariaLabel = a.getAttribute('aria-label') || '';
      const title = a.getAttribute('title') || '';
      const img = a.querySelector('img[alt]');
      const hasDiscernibleText = text.length > 0 || ariaLabel.length > 0 ||
                                  title.length > 0 || (img && img.getAttribute('alt'));
      if (!hasDiscernibleText) return true;
      // Flag generic link text
      const genericTexts = ['click here', 'here', 'read more', 'more', 'link', 'learn more'];
      if (genericTexts.includes(text) && !ariaLabel) return true;
      return false;
    });
    return { total: links.length, problematic: problematic.length };
  });
  logCheck('2.4.4 Link Purpose', linkPurposeCheck.problematic === 0, results,
    `All ${linkPurposeCheck.total} links have discernible purpose`,
    `${linkPurposeCheck.problematic}/${linkPurposeCheck.total} links have generic or missing link text`);

  // ─── WCAG 3.3.2: Labels or Instructions (Form Inputs) ─────────────────────
  const formLabelCheck = await page.evaluate(() => {
    const inputs = [...document.querySelectorAll(
      'input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="reset"]), ' +
      'select, textarea'
    )];
    const unlabeled = inputs.filter(input => {
      const id = input.id;
      const ariaLabel = input.getAttribute('aria-label');
      const ariaLabelledBy = input.getAttribute('aria-labelledby');
      const title = input.getAttribute('title');
      const placeholder = input.getAttribute('placeholder');
      const hasExplicitLabel = id && document.querySelector(`label[for="${id}"]`);
      const hasImplicitLabel = input.closest('label');
      // WCAG allows aria-label, aria-labelledby, title, or visible label
      return !hasExplicitLabel && !hasImplicitLabel && !ariaLabel && !ariaLabelledBy && !title;
    });
    // Check shadow DOM inputs (bolt-autocomplete, bolt-textfield)
    let shadowUnlabeled = 0;
    for (const host of document.querySelectorAll('bolt-autocomplete, bolt-autocomplete-wc, bolt-textfield-wc')) {
      const shadowInputs = host.shadowRoot?.querySelectorAll('input') || [];
      for (const inp of shadowInputs) {
        const hasLabel = inp.getAttribute('aria-label') || inp.getAttribute('aria-labelledby') ||
                         inp.getAttribute('title') || inp.id;
        if (!hasLabel) shadowUnlabeled++;
      }
    }
    return { total: inputs.length, unlabeled: unlabeled.length, shadowUnlabeled };
  });
  const totalUnlabeled = formLabelCheck.unlabeled + formLabelCheck.shadowUnlabeled;
  logCheck('3.3.2 Labels or Instructions', totalUnlabeled === 0, results,
    `All ${formLabelCheck.total} form inputs have associated labels`,
    `${totalUnlabeled} form input(s) missing associated label/aria-label`);

  // ─── WCAG 4.1.2: Name, Role, Value (ARIA Validity) ────────────────────────
  const ariaCheck = await page.evaluate(() => {
    const issues = [];
    // Check for invalid ARIA roles
    const validRoles = new Set([
      'alert', 'alertdialog', 'application', 'article', 'banner', 'button',
      'cell', 'checkbox', 'columnheader', 'combobox', 'complementary',
      'contentinfo', 'definition', 'dialog', 'directory', 'document', 'feed',
      'figure', 'form', 'grid', 'gridcell', 'group', 'heading', 'img',
      'link', 'list', 'listbox', 'listitem', 'log', 'main', 'marquee',
      'math', 'menu', 'menubar', 'menuitem', 'menuitemcheckbox',
      'menuitemradio', 'navigation', 'none', 'note', 'option', 'presentation',
      'progressbar', 'radio', 'radiogroup', 'region', 'row', 'rowgroup',
      'rowheader', 'scrollbar', 'search', 'searchbox', 'separator', 'slider',
      'spinbutton', 'status', 'switch', 'tab', 'table', 'tablist', 'tabpanel',
      'term', 'textbox', 'timer', 'toolbar', 'tooltip', 'tree', 'treegrid', 'treeitem'
    ]);
    const elementsWithRole = document.querySelectorAll('[role]');
    let invalidRoles = 0;
    elementsWithRole.forEach(el => {
      const role = el.getAttribute('role');
      if (!validRoles.has(role)) invalidRoles++;
    });

    // Check for required ARIA properties
    const ariaRequired = document.querySelectorAll('[aria-required="true"]');
    const ariaExpanded = document.querySelectorAll('[aria-expanded]');
    const ariaHidden = document.querySelectorAll('[aria-hidden="true"]');

    // Verify aria-hidden elements don't contain focusable children
    let hiddenFocusable = 0;
    ariaHidden.forEach(el => {
      const focusable = el.querySelectorAll(
        'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
      );
      if (focusable.length > 0) hiddenFocusable++;
    });

    return { invalidRoles, hiddenFocusable, totalAriaElements: elementsWithRole.length };
  });
  logCheck('4.1.2 Name, Role, Value', ariaCheck.invalidRoles === 0 && ariaCheck.hiddenFocusable === 0, results,
    `ARIA attributes valid (${ariaCheck.totalAriaElements} elements with roles checked)`,
    `ARIA issues: ${ariaCheck.invalidRoles} invalid roles, ${ariaCheck.hiddenFocusable} aria-hidden elements with focusable children`);

  // ─── WCAG 1.4.3: Color Contrast (Minimum) ─────────────────────────────────
  const contrastCheck = await page.evaluate(() => {
    /**
     * Calculate relative luminance per WCAG 2.2 formula.
     * @see https://www.w3.org/WAI/WCAG22/Techniques/general/G17
     */
    function relativeLuminance(r, g, b) {
      const [rs, gs, bs] = [r, g, b].map(c => {
        c = c / 255;
        return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
      });
      return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
    }

    function contrastRatio(l1, l2) {
      const lighter = Math.max(l1, l2);
      const darker = Math.min(l1, l2);
      return (lighter + 0.05) / (darker + 0.05);
    }

    function parseColor(color) {
      const match = color.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
      if (!match) return null;
      return { r: parseInt(match[1]), g: parseInt(match[2]), b: parseInt(match[3]) };
    }

    // Sample text elements for contrast checking
    const textElements = document.querySelectorAll(
      'p, span, a, li, h1, h2, h3, h4, h5, h6, label, button, td, th'
    );
    let checked = 0;
    let failures = 0;
    const failureExamples = [];
    const sampleSize = Math.min(textElements.length, 50); // Sample up to 50 elements

    for (let i = 0; i < sampleSize; i++) {
      const el = textElements[Math.floor(i * textElements.length / sampleSize)];
      if (!el.textContent?.trim()) continue;

      const style = window.getComputedStyle(el);
      const fgColor = parseColor(style.color);
      const bgColor = parseColor(style.backgroundColor);

      if (!fgColor || !bgColor) continue;
      // Skip transparent backgrounds (alpha = 0)
      if (style.backgroundColor === 'rgba(0, 0, 0, 0)') continue;

      checked++;
      const fgLum = relativeLuminance(fgColor.r, fgColor.g, fgColor.b);
      const bgLum = relativeLuminance(bgColor.r, bgColor.g, bgColor.b);
      const ratio = contrastRatio(fgLum, bgLum);

      const fontSize = parseFloat(style.fontSize);
      const fontWeight = parseInt(style.fontWeight) || 400;
      // Large text: ≥18pt (24px) or ≥14pt (18.67px) bold
      const isLargeText = fontSize >= 24 || (fontSize >= 18.67 && fontWeight >= 700);
      const requiredRatio = isLargeText ? 3.0 : 4.5;

      if (ratio < requiredRatio) {
        failures++;
        if (failureExamples.length < 3) {
          failureExamples.push({
            text: el.textContent.trim().substring(0, 30),
            ratio: ratio.toFixed(2),
            required: requiredRatio
          });
        }
      }
    }
    return { checked, failures, failureExamples };
  });
  logCheck('1.4.3 Contrast Minimum', contrastCheck.failures === 0, results,
    `Color contrast sufficient (${contrastCheck.checked} elements checked)`,
    `${contrastCheck.failures}/${contrastCheck.checked} elements fail contrast ratio (need ≥4.5:1 normal, ≥3:1 large text)`);

  // ─── WCAG 2.5.8: Target Size Minimum (WCAG 2.2 — AA) ─────────────────────
  const targetSizeCheck = await page.evaluate(() => {
    const interactive = document.querySelectorAll(
      'a[href], button, input:not([type="hidden"]), select, textarea, ' +
      '[role="button"], [role="link"], [role="checkbox"], [role="radio"], [tabindex]:not([tabindex="-1"])'
    );
    let tooSmall = 0;
    let checked = 0;
    const MIN_SIZE = 24; // WCAG 2.2 AA minimum: 24×24 CSS pixels
    const tooSmallExamples = [];

    interactive.forEach(el => {
      const rect = el.getBoundingClientRect();
      // Skip hidden/off-screen elements
      if (rect.width === 0 || rect.height === 0) return;
      if (rect.top < -1000 || rect.left < -1000) return;
      checked++;
      if (rect.width < MIN_SIZE || rect.height < MIN_SIZE) {
        // Exception: inline links within text blocks (WCAG 2.5.8 exception)
        if (el.tagName === 'A' && el.closest('p, li, td, th, dd')) return;
        tooSmall++;
        if (tooSmallExamples.length < 3) {
          tooSmallExamples.push({
            tag: el.tagName,
            text: (el.textContent || el.getAttribute('aria-label') || '').trim().substring(0, 25),
            width: Math.round(rect.width),
            height: Math.round(rect.height)
          });
        }
      }
    });
    return { checked, tooSmall, tooSmallExamples };
  });
  logCheck('2.5.8 Target Size Minimum (WCAG 2.2)', targetSizeCheck.tooSmall === 0, results,
    `All ${targetSizeCheck.checked} interactive targets meet 24×24px minimum`,
    `${targetSizeCheck.tooSmall}/${targetSizeCheck.checked} interactive targets below 24×24px minimum size`);

  // ─── WCAG 2.1.1 / 2.1.2: Keyboard Access & No Keyboard Trap ───────────────
  const keyboardCheck = await testKeyboardNavigation(page);
  logCheck('2.1.1 Keyboard Accessible', keyboardCheck.searchReachable, results,
    'Search input reachable via keyboard Tab navigation',
    'Search input NOT reachable via keyboard — interactive element inaccessible');
  logCheck('2.1.2 No Keyboard Trap', keyboardCheck.noTrap, results,
    'No keyboard trap detected — focus can move freely through the page',
    'Potential keyboard trap detected — focus could not escape a component');

  // ─── WCAG 2.4.7: Focus Visible ────────────────────────────────────────────
  const focusVisibleCheck = await page.evaluate(() => {
    // Tab to first focusable element and check if focus indicator is visible
    const focusable = document.querySelector(
      'a[href], button, input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    if (!focusable) return { hasFocusStyle: false, checked: false };
    focusable.focus();
    const style = window.getComputedStyle(focusable);
    const outlineStyle = style.outlineStyle;
    const outlineWidth = parseFloat(style.outlineWidth);
    const boxShadow = style.boxShadow;
    const hasFocusIndicator = (outlineStyle !== 'none' && outlineWidth > 0) ||
                               (boxShadow && boxShadow !== 'none');
    return { hasFocusStyle: hasFocusIndicator, checked: true };
  });
  logCheck('2.4.7 Focus Visible', focusVisibleCheck.hasFocusStyle, results,
    'Focus indicator visible on interactive elements',
    'No visible focus indicator detected — keyboard users cannot see current focus position');

  // ─── WCAG 2.4.11: Focus Not Obscured (WCAG 2.2 — AA) ─────────────────────
  const focusObscuredCheck = await page.evaluate(() => {
    // Check if sticky/fixed positioned elements could obscure focused elements
    const stickyElements = document.querySelectorAll('[style*="position: fixed"], [style*="position: sticky"]');
    const computedSticky = [...document.querySelectorAll('*')].filter(el => {
      const pos = window.getComputedStyle(el).position;
      return pos === 'fixed' || pos === 'sticky';
    });

    // Get bounding rects of sticky/fixed elements
    const stickyRects = computedSticky.map(el => ({
      rect: el.getBoundingClientRect(),
      zIndex: parseInt(window.getComputedStyle(el).zIndex) || 0
    })).filter(item => item.rect.height > 0 && item.rect.width > 0);

    return {
      hasStickyElements: stickyRects.length > 0,
      stickyCount: stickyRects.length,
      // Flag if sticky elements cover large portion of viewport
      potentialObscuring: stickyRects.some(item =>
        item.rect.height > window.innerHeight * 0.3 || item.rect.width > window.innerWidth * 0.5
      )
    };
  });
  logCheck('2.4.11 Focus Not Obscured (WCAG 2.2)', !focusObscuredCheck.potentialObscuring, results,
    `Focus not obscured by overlays (${focusObscuredCheck.stickyCount} fixed/sticky elements checked)`,
    'Large fixed/sticky element may obscure focused elements — ensure focused items remain visible');

  // ─── WCAG 2.4.3: Focus Order ──────────────────────────────────────────────
  const focusOrderCheck = await page.evaluate(() => {
    const focusable = [...document.querySelectorAll(
      'a[href], button, input:not([type="hidden"]), select, textarea, [tabindex]'
    )].filter(el => {
      const tabindex = el.getAttribute('tabindex');
      return tabindex === null || parseInt(tabindex) >= 0;
    });
    // Check for positive tabindex values (anti-pattern)
    const positiveTabindex = focusable.filter(el => {
      const ti = parseInt(el.getAttribute('tabindex') || '0');
      return ti > 0;
    });
    return {
      totalFocusable: focusable.length,
      positiveTabindex: positiveTabindex.length
    };
  });
  logCheck('2.4.3 Focus Order', focusOrderCheck.positiveTabindex === 0, results,
    `Focus order follows DOM sequence (${focusOrderCheck.totalFocusable} focusable elements, no positive tabindex)`,
    `${focusOrderCheck.positiveTabindex} element(s) use positive tabindex — disrupts natural focus order`);

  // ─── WCAG 1.4.12: Text Spacing (AA) ───────────────────────────────────────
  const textSpacingCheck = await page.evaluate(() => {
    // Inject WCAG 2.2 text spacing overrides and check for content clipping
    const style = document.createElement('style');
    style.id = 'wcag-text-spacing-test';
    style.textContent = `
      * {
        line-height: 1.5em !important;
        letter-spacing: 0.12em !important;
        word-spacing: 0.16em !important;
      }
      p, li, dd, dt, span, a, td, th, label {
        margin-bottom: 2em !important;
      }
    `;
    document.head.appendChild(style);

    // Check for overflow clipping after spacing adjustment
    let clipped = 0;
    const containers = document.querySelectorAll('div, section, article, aside, main, p');
    const sampleSize = Math.min(containers.length, 30);
    for (let i = 0; i < sampleSize; i++) {
      const el = containers[Math.floor(i * containers.length / sampleSize)];
      const overflow = window.getComputedStyle(el).overflow;
      if (overflow === 'hidden') {
        const scrollH = el.scrollHeight;
        const clientH = el.clientHeight;
        if (scrollH > clientH + 5) clipped++;
      }
    }

    // Clean up injected style
    document.getElementById('wcag-text-spacing-test')?.remove();
    return { clipped, checked: sampleSize };
  });
  logCheck('1.4.12 Text Spacing', textSpacingCheck.clipped === 0, results,
    `Content readable with WCAG text spacing overrides (${textSpacingCheck.checked} containers checked)`,
    `${textSpacingCheck.clipped} container(s) clip content when text spacing is adjusted`);

  // ─── WCAG 3.3.8: Accessible Authentication (WCAG 2.2 — AA) ────────────────
  const authCheck = await page.evaluate(() => {
    // Check if any authentication forms require cognitive function tests (e.g., CAPTCHA without alternatives)
    const captchaElements = document.querySelectorAll(
      '[class*="captcha" i], [id*="captcha" i], [class*="recaptcha" i], ' +
      'iframe[src*="captcha"], iframe[src*="recaptcha"], [data-sitekey]'
    );
    const hasCaptcha = captchaElements.length > 0;

    // If CAPTCHA present, check for accessible alternatives
    let hasAlternative = false;
    if (hasCaptcha) {
      // reCAPTCHA v3 (invisible) is considered accessible
      hasAlternative = !!document.querySelector(
        '.grecaptcha-badge, [data-size="invisible"], iframe[title*="invisible"]'
      );
    }
    return { hasCaptcha, hasAlternative, compliant: !hasCaptcha || hasAlternative };
  });
  logCheck('3.3.8 Accessible Authentication (WCAG 2.2)', authCheck.compliant, results,
    authCheck.hasCaptcha
      ? 'CAPTCHA present with accessible alternative (invisible/v3)'
      : 'No cognitive function tests required for authentication',
    'CAPTCHA detected without accessible alternative — violates accessible authentication requirement');

  // ─── WCAG 1.4.11: Non-text Contrast (AA) ──────────────────────────────────
  const nonTextContrastCheck = await page.evaluate(() => {
    function relativeLuminance(r, g, b) {
      const [rs, gs, bs] = [r, g, b].map(c => {
        c = c / 255;
        return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
      });
      return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
    }
    function contrastRatio(l1, l2) {
      return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
    }
    function parseColor(color) {
      const match = color.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
      if (!match) return null;
      return { r: parseInt(match[1]), g: parseInt(match[2]), b: parseInt(match[3]) };
    }

    // Check form input borders against their background
    const formElements = document.querySelectorAll('input, select, textarea, button');
    let checked = 0;
    let failures = 0;
    formElements.forEach(el => {
      const style = window.getComputedStyle(el);
      const borderColor = parseColor(style.borderColor);
      const bgColor = parseColor(style.backgroundColor);
      if (!borderColor || !bgColor) return;
      if (style.borderWidth === '0px' || style.borderStyle === 'none') return;
      checked++;
      const borderLum = relativeLuminance(borderColor.r, borderColor.g, borderColor.b);
      const bgLum = relativeLuminance(bgColor.r, bgColor.g, bgColor.b);
      const ratio = contrastRatio(borderLum, bgLum);
      if (ratio < 3.0) failures++;
    });
    return { checked, failures };
  });
  logCheck('1.4.11 Non-text Contrast', nonTextContrastCheck.failures === 0, results,
    `UI component boundaries meet 3:1 contrast ratio (${nonTextContrastCheck.checked} elements checked)`,
    `${nonTextContrastCheck.failures}/${nonTextContrastCheck.checked} UI components have insufficient border contrast (need ≥3:1)`);

  // ─── WCAG Search Input ARIA Label (existing check, enhanced) ───────────────
  const hasAriaLabel = await page.evaluate(() => {
    // Light DOM (Yext/Prod)
    const el = document.querySelector('#yxt-SearchBar-input--search-bar-1');
    if (el && (el.getAttribute('aria-label') === 'Conduct a search' || el.getAttribute('aria-label') === 'Search')) return true;
    // Shadow DOM (Angular bolt-autocomplete)
    for (const host of document.querySelectorAll('bolt-autocomplete, bolt-autocomplete-wc')) {
      const inp = host.shadowRoot?.querySelector('input[data-test="input"], input[aria-label]');
      const label = inp?.getAttribute('aria-label');
      if (label === 'Conduct a search' || label === 'Search') return true;
    }
    return false;
  });
  logCheck('4.1.2 Search Input ARIA Label', hasAriaLabel, results,
    'Search input has correct aria-label ("Conduct a search" or "Search")',
    'Search input missing aria-label (expected "Conduct a search" or "Search")');

  // ─── Calculate weighted score ──────────────────────────────────────────────
  const totalChecks = results.passed.length + results.violations.length;
  results.score = totalChecks > 0 ? Math.round((results.passed.length / totalChecks) * 100) : 0;

  // ─── Summary output ────────────────────────────────────────────────────────
  console.log('\n' + '─'.repeat(60));
  console.log(` WCAG 2.2 AA COMPLIANCE SCORE: ${results.score}%`);
  console.log(` Passed: ${results.passed.length}  |  Violations: ${results.violations.length}  |  Warnings: ${results.warnings.length}`);
  console.log('─'.repeat(60));

  if (results.violations.length > 0) {
    console.log('\n  VIOLATIONS:');
    results.violations.forEach((v, i) => console.log(`    ${i + 1}. ${v}`));
  }
  if (results.warnings.length > 0) {
    console.log('\n  WARNINGS:');
    results.warnings.forEach((w, i) => console.log(`    ${i + 1}. ${w}`));
  }

  return results;
}

// ═══════════════════════════════════════════════════════════════════════════════
//  HELPER: Keyboard Navigation Test (WCAG 2.1.1 & 2.1.2)
// ═══════════════════════════════════════════════════════════════════════════════

async function testKeyboardNavigation(page) {
  let searchReachable = false;
  let noTrap = true;
  const maxTabs = 50; // Safety limit to detect traps
  const visitedElements = new Set();
  let lastElementKey = '';
  let consecutiveSameFocus = 0;
  const trapRepeatThreshold = 8;

  await page.keyboard.press('Tab');

  for (let i = 0; i < maxTabs; i++) {
    await page.keyboard.press('Tab');

    const focusInfo = await page.evaluate(() => {
      const active = document.activeElement;
      if (!active || active === document.body) return { tag: 'body', id: '', trapped: false };

      const id = active.id || active.getAttribute('aria-label') || active.tagName;
      const isSearch =
        active.getAttribute('aria-label') === 'Conduct a search' ||
        active.getAttribute('aria-label') === 'Search' ||
        active.id === 'yxt-SearchBar-input--search-bar-1';

      // Check Angular shadow DOM search
      let shadowSearch = false;
      if (active.tagName?.toLowerCase().startsWith('bolt-')) {
        const inp = active.shadowRoot?.querySelector('input[data-test="input"], input[aria-label="Search"]');
        if (inp) shadowSearch = true;
      }
      for (const host of document.querySelectorAll('bolt-autocomplete, bolt-autocomplete-wc')) {
        const shadowActive = host.shadowRoot?.activeElement;
        if (shadowActive?.tagName === 'INPUT') shadowSearch = true;
      }

      return { tag: active.tagName, id, isSearch: isSearch || shadowSearch, trapped: false };
    });

    if (focusInfo.isSearch) {
      searchReachable = true;
    }

    // Detect keyboard trap: same element focused repeatedly without progression
    const elementKey = `${focusInfo.tag}-${focusInfo.id}`;
    if (elementKey === lastElementKey) {
      consecutiveSameFocus++;
    } else {
      consecutiveSameFocus = 0;
      lastElementKey = elementKey;
    }

    if (consecutiveSameFocus >= trapRepeatThreshold) {
      noTrap = false;
      break;
    }
    visitedElements.add(elementKey);

    // If we've found search and confirmed no trap, we can stop early
    if (searchReachable && i > 20) break;
  }

  return { searchReachable, noTrap };
}

// ═══════════════════════════════════════════════════════════════════════════════
//  HELPER: Logging utility for check results
// ═══════════════════════════════════════════════════════════════════════════════

function logCheck(criterion, passed, results, passMessage, failMessage) {
  const status = passed ? '✓ PASS' : '✗ FAIL';
  console.log(`  [${status}] ${criterion}`);
  if (passed) {
    results.passed.push(`[${criterion}] ${passMessage}`);
  } else {
    results.violations.push(`[${criterion}] ${failMessage}`);
  }
}
