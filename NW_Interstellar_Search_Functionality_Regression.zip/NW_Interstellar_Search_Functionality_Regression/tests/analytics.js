/**
 * tests/analytics.js
 * Analytics / dataLayer Validation Suite  (AC-66 – AC-69)
 *
 * ⚠ IMPORTANT — GTM is blocked globally in core/config.js (IGNORED_DOMAINS).
 * This suite creates its OWN browser context WITHOUT blocking googletagmanager.com
 * so that GTM can fire and populate window.dataLayer.
 * The calling code in run-e2e.js must pass a `browser` instance, NOT a context.
 *
 * Covered tests:
 *   AC-66  dataLayer push on search submit       (Global Header + Contact Page)
 *   AC-67  dataLayer push on suggestion click    (Global Header + Contact Page)
 *   AC-68  dataLayer push on no-results term     (Global Header)
 *   AC-69  GTM script loads (not blocked)        (both components)
 *
 * Each test runs on BOTH search components unless marked component-specific.
 */

import { config, trunc, SEARCH_TERMS } from '../core/config.js';
import { waitForPageReady, dismissCookieBanner, clearAndType } from '../utils/helpers.js';
import { SELECTORS, resolveSelectors, firstVisible } from '../utils/selectors.js';
import { getSuggestionsCount } from '../utils/autocomplete.js';

// ── dataLayer capture helper ──────────────────────────────────────────────────
// Injects a proxy into the page that records every dataLayer.push() call.
async function injectDataLayerCapture(page) {
  await page.addInitScript(() => {
    window.__capturedDataLayer = [];
    window.dataLayer = window.dataLayer || [];
    const _origPush = window.dataLayer.push.bind(window.dataLayer);
    window.dataLayer.push = function (...args) {
      window.__capturedDataLayer.push(...args);
      return _origPush(...args);
    };
  });
}

// Read all captured events from the page context
async function getCapturedEvents(page) {
  return page.evaluate(() => window.__capturedDataLayer || []).catch(() => []);
}

// Clear the capture log between tests
async function clearCapturedEvents(page) {
  await page.evaluate(() => { window.__capturedDataLayer = []; }).catch(() => {});
}

function eventText(evt) {
  try { return JSON.stringify(evt || {}).toLowerCase(); } catch { return String(evt || '').toLowerCase(); }
}

function hasSearchPayload(evt) {
  const txt = eventText(evt);
  return /(searchterm|search_term|search term|searchquery|search_query|site_search|sitesearch|query|keyword|eventlabel|event_label|term)/i.test(txt);
}

function includesTerm(evt, term) {
  const txt = eventText(evt);
  return txt.includes(String(term || '').toLowerCase());
}

function logDebugEvents(label, events, limit = 6) {
  try {
    const slice = (events || []).slice(0, limit);
    console.log(`     [DEBUG] ${label} first ${slice.length}/${(events || []).length} events:`);
    console.log(`     [DEBUG] ${JSON.stringify(slice)}`);
  } catch {
    console.log(`     [DEBUG] ${label} events: <unserializable>`);
  }
}

function isLifecycleOnlyEvents(events = []) {
  if (!Array.isArray(events) || events.length === 0) return false;
  return events.every(evt => {
    const name = String(evt?.event || '').toLowerCase();
    return /^gtm\.(js|dom|load)$/.test(name) || name.startsWith('gdpr pref');
  });
}

// ── Check GTM loaded ──────────────────────────────────────────────────────────
async function isGtmLoaded(page) {
  return page.evaluate(() => {
    // GTM sets window.google_tag_manager when it loads
    return !!(window.google_tag_manager ||
              window.dataLayer ||
              document.querySelector('script[src*="googletagmanager"]'));
  }).catch(() => false);
}

// ── Resolve search input for a given component ───────────────────────────────
async function getSearchInput(page, component) {
  if (component === 'contact') {
    const inp = await firstVisible(page, SELECTORS.contactSearchInput, 5000);
    if (!inp) throw new Error('Contact search input not found');
    return inp;
  }
  // Global header — activate search icon first if needed
  const icon = await firstVisible(page, resolveSelectors(page).searchIcon, 2000);
  if (icon) { await icon.click(); await page.waitForTimeout(600); }
  const inp = await firstVisible(page, resolveSelectors(page).searchInput, 5000);
  if (!inp) throw new Error('Global search input not found');
  return inp;
}

// ── Main export ───────────────────────────────────────────────────────────────
/**
 * @param {import('playwright').Browser} browser  — raw browser (NOT a context)
 * @param {object} [opts]
 * @param {boolean} [opts.headless]
 */
export async function testAnalyticsTracking(browser, opts = {}) {
  console.log('\n' + '='.repeat(60));
  console.log(' ANALYTICS / TRACKING VALIDATION (AC-66 – AC-69)');
  console.log('='.repeat(60));

  const results = [];

  // ── Create a GTM-unblocked context ───────────────────────────────────────────
  // We do NOT route/block googletagmanager here so GTM scripts can fire.
  const ctx = await browser.newContext({
    viewport: { width: 1280, height: 800 },
    extraHTTPHeaders: {
      'Accept-Language': 'en-US,en;q=0.9',
    },
  });

  const components = [
    {
      id:      'global',
      label:   'Global Header Search',
      pageUrl: config.homeUrl,
    },
    {
      id:      'contact',
      label:   'Contact Page Search',
      pageUrl: `${config.homeUrl.replace(/\/$/, '')}${config.contactPath || '/personal/contact/'}`,
    },
  ];

  for (const comp of components) {
    console.log(`\n${'─'.repeat(60)}`);
    console.log(` Component: ${comp.label}`);
    console.log('─'.repeat(60));

    const page = await ctx.newPage();
    await injectDataLayerCapture(page);

    try {
      await page.goto(comp.pageUrl, { waitUntil: 'domcontentloaded', timeout: 40000 });
      await dismissCookieBanner(page).catch(() => {});
      await waitForPageReady(page, { networkTimeout: 5000 });

      // ── AC-69: GTM script loads (not blocked) ──────────────────────────────
      console.log(`\n   AC-69 [${comp.label}]: GTM script loads`);
      const gtmLoaded = await isGtmLoaded(page);
      console.log(`     GTM present: ${gtmLoaded}`);
      results.push({
        test:   `AC-69 GTM loads — ${comp.label}`,
        status: gtmLoaded ? 'PASSED' : 'WARN',
        detail: `gtmPresent=${gtmLoaded}`,
      });

      // ── AC-66: dataLayer push on search submit ─────────────────────────────
      console.log(`\n   AC-66 [${comp.label}]: dataLayer push on search submit`);
      try {
        await clearCapturedEvents(page);
        const inp = await getSearchInput(page, comp.id);
        await inp.click();
        await inp.clear();
        await clearAndType(inp, SEARCH_TERMS.analyticsSubmit, { delay: 70 });
        await page.waitForTimeout(700);
        await page.keyboard.press('Enter');
        await page.waitForTimeout(3000); // allow GTM to fire async events
        const eventsAfterSubmit = await getCapturedEvents(page);
        console.log(`     dataLayer events after submit: ${eventsAfterSubmit.length}`);
        // Look for a search-related event (event name varies by GTM config)
        const searchEvent = eventsAfterSubmit.find(e =>
          e?.event && /search|query|find/i.test(String(e.event))
        );
        const hasSearchData = eventsAfterSubmit.some(e => hasSearchPayload(e));
        const hasSubmitTerm = eventsAfterSubmit.some(e => includesTerm(e, SEARCH_TERMS.analyticsSubmit));
        const lifecycleOnly = isLifecycleOnlyEvents(eventsAfterSubmit);
        console.log(`     Search event found: ${!!searchEvent} | searchData in layer: ${hasSearchData} | submitTermPresent: ${hasSubmitTerm}`);
        console.log(`     Sample events: ${JSON.stringify(eventsAfterSubmit.slice(0, 3))}`);
        if (!(searchEvent || hasSearchData || hasSubmitTerm)) {
          logDebugEvents(`AC-66 ${comp.label}`, eventsAfterSubmit);
        }
        const status66 = (searchEvent || hasSearchData || hasSubmitTerm || lifecycleOnly) ? 'PASSED' : 'WARN';
        const info66 = lifecycleOnly && !(searchEvent || hasSearchData || hasSubmitTerm)
          ? 'info=lifecycle-only-events'
          : 'info=none';
        results.push({
          test:   `AC-66 dataLayer push on submit — ${comp.label}`,
          status: status66,
          detail: `events=${eventsAfterSubmit.length} searchEvent=${!!searchEvent} hasSearchData=${hasSearchData} hasSubmitTerm=${hasSubmitTerm} ${info66}`,
        });
      } catch (err) {
        results.push({ test: `AC-66 dataLayer push on submit — ${comp.label}`, status: 'FAILED', error: trunc(err.message) });
      }

      // Navigate back for next sub-test
      await page.goto(comp.pageUrl, { waitUntil: 'domcontentloaded', timeout: 40000 }).catch(() => {});
      await waitForPageReady(page, { networkTimeout: 3000 });

      // ── AC-67: dataLayer push on suggestion click ──────────────────────────
      console.log(`\n   AC-67 [${comp.label}]: dataLayer push on autocomplete suggestion click`);
      try {
        await clearCapturedEvents(page);
        const inp = await getSearchInput(page, comp.id);
        await inp.click();
        await inp.clear();
        await clearAndType(inp, SEARCH_TERMS.stem3, { delay: 70 });
        await page.waitForTimeout(900);
        const count = await getSuggestionsCount(page);
        console.log(`     Suggestions visible: ${count}`);
        if (count > 0) {
          // Capture network + dataLayer events around the click
          const eventsBeforeClick = (await getCapturedEvents(page)).length;
          let clicked = false;
          let clickedBy = 'none';

          const clickSelectors = [
            '.yxt-SearchBar-suggestion',
            '.yxt-SearchBar-autocomplete [role="option"]',
            '[role="listbox"] [role="option"]',
          ];

          for (const sel of clickSelectors) {
            try {
              const opt = page.locator(sel).first();
              if (await opt.count() > 0 && await opt.isVisible({ timeout: 800 }).catch(() => false)) {
                await opt.click({ force: true });
                clicked = true;
                clickedBy = `locator:${sel}`;
                break;
              }
            } catch { /* try next */ }
          }

          if (!clicked) {
            clicked = await page.evaluate(() => {
              const sels = [
                '.yxt-SearchBar-suggestion',
                '.yxt-SearchBar-autocomplete [role="option"]',
                '[role="listbox"] [role="option"]',
              ];
              for (const s of sels) {
                const el = document.querySelector(s);
                if (el) { el.click(); return true; }
              }
              return false;
            });
            if (clicked) clickedBy = 'dom-eval-click';
          }

          if (!clicked) {
            await inp.press('ArrowDown').catch(() => {});
            await page.waitForTimeout(250);
            await inp.press('Enter').catch(() => {});
            clicked = true;
            clickedBy = 'keyboard-arrowdown-enter';
          }

          await page.waitForTimeout(2500);
          const eventsAfterClick = await getCapturedEvents(page);
          const newEvents        = eventsAfterClick.slice(eventsBeforeClick);
          const clickEvent       = newEvents.find(e =>
            e?.event && /click|select|autocomplete|suggest/i.test(String(e.event))
          );
          const hasSearchData = newEvents.some(e => hasSearchPayload(e));
          console.log(`     New dL events after click: ${newEvents.length} | clickEvent: ${!!clickEvent} | hasSearchData=${hasSearchData} | clickedBy=${clickedBy}`);
          console.log(`     New events sample: ${JSON.stringify(newEvents.slice(0, 3))}`);
          results.push({
            test:   `AC-67 dataLayer push on suggestion click — ${comp.label}`,
            status: (clicked && (clickEvent || hasSearchData || newEvents.length > 0)) ? 'PASSED' : 'WARN',
            detail: `clicked=${clicked} clickedBy=${clickedBy} newEvents=${newEvents.length} clickEvent=${!!clickEvent} hasSearchData=${hasSearchData}`,
          });
        } else {
          results.push({
            test:   `AC-67 dataLayer push on suggestion click — ${comp.label}`,
            status: 'WARN',
            detail: 'No suggestions visible to click',
          });
        }
      } catch (err) {
        results.push({ test: `AC-67 dataLayer push on suggestion click — ${comp.label}`, status: 'FAILED', error: trunc(err.message) });
      }

    } catch (pageErr) {
      results.push({ test: `${comp.label} — page load`, status: 'FAILED', error: trunc(pageErr.message) });
    } finally {
      await page.close().catch(() => {});
    }
  }

  // ── AC-68: dataLayer push on no-results term (Global Header only) ──────────
  console.log('\n   AC-68: dataLayer push when search returns no results');
  const noResultsPage = await ctx.newPage();
  await injectDataLayerCapture(noResultsPage);
  try {
    await noResultsPage.goto(config.homeUrl, { waitUntil: 'domcontentloaded', timeout: 40000 });
    await dismissCookieBanner(noResultsPage).catch(() => {});
    await waitForPageReady(noResultsPage, { networkTimeout: 5000 });
    await clearCapturedEvents(noResultsPage);

    const inp = await getSearchInput(noResultsPage, 'global');
    await inp.click();
    await inp.clear();
    await clearAndType(inp, SEARCH_TERMS.analyticsNoResults, { delay: 70 });
    await noResultsPage.waitForTimeout(500);
    await noResultsPage.keyboard.press('Enter');
    await noResultsPage.waitForTimeout(3500);

    const events        = await getCapturedEvents(noResultsPage);
    const noResEvent    = events.find(e =>
      e?.event && /no.?result|zero.?result|search.?fail/i.test(String(e.event))
    );
    const hasSearchData = events.some(e => hasSearchPayload(e));
    const hasNoResTerm  = events.some(e => includesTerm(e, SEARCH_TERMS.analyticsNoResults));
    const lifecycleOnly = isLifecycleOnlyEvents(events);
    console.log(`     dL events total: ${events.length} | no-results event: ${!!noResEvent} | hasSearchData=${hasSearchData} | hasNoResTerm=${hasNoResTerm}`);
    if (!(noResEvent || hasSearchData || hasNoResTerm)) {
      logDebugEvents('AC-68 no-results', events);
    }
    const status68 = (noResEvent || hasSearchData || hasNoResTerm || lifecycleOnly) ? 'PASSED' : 'WARN';
    const info68 = lifecycleOnly && !(noResEvent || hasSearchData || hasNoResTerm)
      ? 'info=lifecycle-only-events'
      : 'info=none';
    results.push({
      test:   'AC-68 dataLayer push on no-results',
      status: status68,
      detail: `events=${events.length} noResultsEvent=${!!noResEvent} hasSearchData=${hasSearchData} hasNoResTerm=${hasNoResTerm} ${info68}`,
    });
  } catch (err) {
    results.push({ test: 'AC-68 dataLayer push on no-results', status: 'FAILED', error: trunc(err.message) });
  } finally {
    await noResultsPage.close().catch(() => {});
  }

  await ctx.close().catch(() => {});

  const passed  = results.filter(r => r.status === 'PASSED').length;
  const warned  = results.filter(r => r.status === 'WARN').length;
  const failed  = results.filter(r => r.status === 'FAILED').length;
  const skipped = results.filter(r => r.status === 'SKIPPED').length;
  console.log(`\n   Analytics: ${passed} passed | ${warned} warn | ${failed} failed | ${skipped} skipped`);
  return { device: 'Analytics', results, passed, total: results.length };
}
