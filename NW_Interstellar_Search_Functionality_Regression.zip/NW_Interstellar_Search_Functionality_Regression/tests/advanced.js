/**
 * tests/advanced.js
 * Advanced autocomplete behavior, edge cases, no-results state.
 * Also: Contact-page advanced autocomplete suite.
 */

import { config, trunc, SEARCH_TERMS } from '../core/config.js';
import { waitForPageReady, findAndActivateSearch, dismissCookieBanner, clearAndType } from '../utils/helpers.js';
import { SELECTORS, resolveSelectors, firstVisible } from '../utils/selectors.js';
import { getAutocompleteState, getSuggestionsCount, clickFirstSuggestion } from '../utils/autocomplete.js';
import { isAriaCollapsed, isAriaExpanded, ariaLabel, SEARCH_CONTEXTS } from '../utils/search-context.js';

async function hardRefresh(page, label = '') {
  try {
    await page.bringToFront().catch(() => {});
    await page.keyboard.down('Control');
    await page.keyboard.down('Shift');
    await page.keyboard.press('KeyR');
    await page.keyboard.up('Shift');
    await page.keyboard.up('Control');
    await page.waitForLoadState('domcontentloaded', { timeout: 30000 }).catch(() => {});
    await page.waitForTimeout(900);
    console.log(`   Hard refresh applied${label ? ` (${label})` : ''}`);
  } catch {
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    await page.waitForTimeout(900);
    console.log(`   Hard refresh fallback via reload${label ? ` (${label})` : ''}`);
  }
}

// ── Contact Page – Advanced Autocomplete Behavior ───────────────────────────
/**
 * Runs a 7-test advanced autocomplete suite on an already-loaded contact page.
 * @param {import('playwright').Page} page  - Tab opened on nationwide.com/personal/contact/
 * @returns {Promise<{device:string, results:Array, passed:number, total:number}>}
 */
export async function testContactPageAdvancedAutocomplete(page, opts = {}) {
  const ctx = opts.context || SEARCH_CONTEXTS.contactPage;
  const platform  = opts.platform  || ctx.platform;
  const pageLabel = opts.pageLabel || ctx.pageLabel;
  const component = opts.component || ctx.component;

  console.log('\n' + '='.repeat(60));
  console.log(` CONTACT PAGE — ADVANCED AUTOCOMPLETE BEHAVIOR`);
  console.log(` Platform: ${platform} | Page: ${pageLabel} | Component: ${component}`);
  console.log('='.repeat(60));
  console.log(` URL: ${page.url()}`);

  const results = [];

  // ── Pre-flight: dismiss any cookie/consent banner that would intercept clicks
  await dismissCookieBanner(page).catch(() => {});

  // ── Pre-flight: wait for Yext widget JS to fully initialise before any test.
  //    The contact page redirects to ?=&referrerPageUrl=&query= which means the
  //    Yext bootstrap runs AFTER domcontentloaded.  We wait until the input has
  //    its aria-expanded attribute (set by Yext JS on init) — up to 10 s.
  console.log('   Waiting for Yext widget to initialise...');
  const yextReady = await page.waitForFunction(() => {
    const el = document.querySelector('#yxt-SearchBar-input--help-search-bar');
    return el && el.getAttribute('aria-expanded') !== null && !el.disabled;
  }, { timeout: 10000 }).then(() => true).catch(() => false);
  if (!yextReady) {
    console.log('   [WARN] Yext widget did not report ready in 10s — continuing anyway');
  } else {
    console.log('   Yext widget ready');
  }

  // ── Contact-page search: resolve via specific selectors first, then fallback.
  // Form  CSS: #p65218 > div > div.column.small-12.large-expand > div >
  //              div.nw-help-center-search-prompt > div.nw-help-center-search >
  //              div.nw-help-center-search-query > div > div > div > form
  // Form XPath: //*[@id="p65218"]/div/div[2]/div/div[2]/div[2]/div[1]/div/div/div/form
  // CONFIRMED from browser recording: contact page input ID = #yxt-SearchBar-input--help-search-bar
  const getInput = async () => {
    // 1. Direct ID — confirmed from browser recording (fastest, most reliable)
    const directId = page.locator('#yxt-SearchBar-input--help-search-bar').first();
    if (await directId.count() > 0 && await directId.isVisible({ timeout: 3000 }).catch(() => false))
      return directId;

    // 2. Try contact-page-specific input selectors
    let inp = await firstVisible(page, SELECTORS.contactSearchInput, 3000);
    if (inp) return inp;

    // 3. XPath to form, then input inside it
    try {
      const formXp = page.locator(
        'xpath=//*[@id="p65218"]/div/div[2]/div/div[2]/div[2]/div[1]/div/div/div/form'
      ).first();
      if (await formXp.count() > 0) {
        const formInput = formXp.locator('input').first();
        if (await formInput.count() > 0) return formInput;
      }
    } catch { /* continue */ }

    // 4. Generic Yext bar (fallback)
    inp = await firstVisible(page, resolveSelectors(page).searchInput, 3000);
    if (inp) return inp;

    throw new Error(
      'Contact-page search input not found — tried #yxt-SearchBar-input--help-search-bar, specific selectors, XPath, and generic Yext bar'
    );
  };

  // Helper: clear + reset without a full page reload
  const resetInput = async (sb) => {
    try {
      await page.keyboard.press('Escape');
      await page.waitForTimeout(200);
      await sb.clear();
    } catch { /* best-effort */ }
  };

  const getSuggestionNodeCountDeep = async () => page.evaluate(() => {
    const selectors = [
      '[role="option"]',
      'li.bolt-autocomplete-wc--option',
      '.yxt-SearchBar-suggestion',
      '.yxt-SearchBar-autocomplete li',
      '[class*="autocomplete"] [role="option"]',
    ];
    const found = new Set();
    const walk = (root) => {
      for (const selector of selectors) {
        for (const node of root.querySelectorAll(selector)) found.add(node);
      }
      for (const el of root.querySelectorAll('*')) {
        if (el.shadowRoot) walk(el.shadowRoot);
      }
    };
    walk(document);
    return found.size;
  }).catch(() => 0);

  // ── Test 1: Dynamic autocomplete updates ──────────────────────────────────
  console.log('\n   Test 1: Dynamic autocomplete updates (contact page)');
  try {
    const sb = await getInput();
    // Scroll into view first — contact page layout can push the bar below the fold
    await sb.scrollIntoViewIfNeeded({ timeout: 5000 }).catch(() => {});
    await page.waitForTimeout(200);
    await sb.click({ timeout: 10000 });
    // clearAndType: validates existing value is cleared, then keys term char-by-char
    // so Yext's debounce listener triggers (fill() would only send a bulk input event).
    await clearAndType(sb, SEARCH_TERMS.stem5, { delay: 50 });  // 'cl' — claim prefix
    await page.waitForTimeout(700);
    const count2 = await getSuggestionsCount(page);

    await sb.pressSequentially(SEARCH_TERMS.stem5b, { delay: 50 });  // 'cl' → 'cla'
    await page.waitForTimeout(400);
    const count3 = await getSuggestionsCount(page);

    await sb.pressSequentially(SEARCH_TERMS.stem5c, { delay: 50 });  // 'cla' → 'clai'
    await page.waitForTimeout(400);
    const count4 = await getSuggestionsCount(page);

    console.log(`     "cl"->${count2}  "cla"->${count3}  "clai"->${count4} suggestions`);
    const changed = (count2 !== count4) || (count3 > 0) || (count4 > 0);
    results.push({ name: 'Dynamic updates', status: changed ? 'PASSED' : 'FAILED',
      detail: `cl:${count2} cla:${count3} clai:${count4}` });
    await resetInput(sb);
  } catch (err) {
    console.log(`     Error: ${trunc(err.message)}`);
    results.push({ name: 'Dynamic updates', status: 'FAILED', error: trunc(err.message) });
  }

  // ── Test 2: Escape key closes dropdown ────────────────────────────────────
  console.log('\n   Test 2: Escape key closes autocomplete dropdown');
  try {
    const sb = await getInput();
    await sb.click();
    await clearAndType(sb, SEARCH_TERMS.policyRenewal, { delay: 50 });
    await page.waitForTimeout(700);
    const beforeEsc = await getAutocompleteState(page);
    const ariaBeforeEsc = await sb.getAttribute('aria-expanded').catch(() => null);
    // Must focus the input first — some Yext widget variants bind ESC at the
    // wrapper/document level, so page.keyboard.press() only works when the
    // input holds real DOM focus.
    await sb.focus();
    await page.keyboard.press('Escape');
    await page.waitForTimeout(400);
    const afterEsc = await getAutocompleteState(page);
    const ariaAfterEsc = await sb.getAttribute('aria-expanded').catch(() => null);
    const suggestionNodesAfterEsc = await getSuggestionNodeCountDeep();
    console.log(`     Before Esc visible:${beforeEsc.isVisible}  After Esc visible:${afterEsc.isVisible}`);
    console.log(`     aria-expanded before:${ariaBeforeEsc} after:${ariaAfterEsc}`);
    const closed = !afterEsc.isVisible;
    const ariaTransitionOk = ariaBeforeEsc !== 'true' ? closed : isAriaCollapsed(ariaAfterEsc);
    const noSuggestions = suggestionNodesAfterEsc === 0;
    const escOk = closed && ariaTransitionOk && noSuggestions;
    results.push({ name: 'Escape closes dropdown',
      status: escOk ? 'PASSED' : 'FAILED',
      detail: `wasOpen:${beforeEsc.isVisible} closed:${closed} ariaBefore:${ariaBeforeEsc} ariaAfter:${ariaLabel(ariaAfterEsc)} suggestionNodesAfterEsc:${suggestionNodesAfterEsc}` });
  } catch (err) {
    console.log(`     Error: ${trunc(err.message)}`);
    results.push({ name: 'Escape closes dropdown', status: 'FAILED', error: trunc(err.message) });
  }

  // ── Test 3: Click outside closes dropdown ────────────────────────────────
  console.log('\n   Test 3: Click outside closes autocomplete dropdown');
  try {
    const sb = await getInput();
    await sb.click();
    await clearAndType(sb, SEARCH_TERMS.premiumPayment, { delay: 50 });
    await page.waitForTimeout(700);
    const beforeClick = await getAutocompleteState(page);
    // Click a neutral area (top-left of body)
    await page.locator('body').click({ position: { x: 10, y: 10 } });
    await page.waitForTimeout(400);
    const afterClick = await getAutocompleteState(page);
    console.log(`     Before click visible:${beforeClick.isVisible}  After click visible:${afterClick.isVisible}`);
    const closed = !afterClick.isVisible;
    results.push({ name: 'Click outside closes', status: closed ? 'PASSED' : 'FAILED',
      detail: `wasOpen:${beforeClick.isVisible} closed:${closed}` });
  } catch (err) {
    console.log(`     Error: ${trunc(err.message)}`);
    results.push({ name: 'Click outside closes', status: 'FAILED', error: trunc(err.message) });
  }

  // ── Test 4: Keyboard arrow navigation through suggestions ─────────────────
  // Recording confirms: ArrowDown moves focus to suggestion item → aria-expanded flips
  // to "false" on the input (combobox behavior). We MUST NOT use getAutocompleteState or
  // getSuggestionsCount here — both read aria-expanded and will add a 1500ms wait per press.
  // Instead: direct DOM count of rendered suggestion elements (they stay in DOM during nav).
  console.log('\n   Test 4: Keyboard arrow navigation through suggestions');
  try {
    const sb = await getInput();
    await sb.click();
    await clearAndType(sb, SEARCH_TERMS.fileClaim, { delay: 50 });
    await page.waitForTimeout(800);

    // Direct DOM count — bypasses aria-expanded entirely.
    // Includes light DOM + shadow DOM so Angular bolt-autocomplete suggestions
    // are not missed (manual recording shows pierce selectors in this flow).
    const countSuggestionsDom = () => page.evaluate(() => {
      const isVisible = (el) => {
        const st = getComputedStyle(el);
        return st.display !== 'none' && st.visibility !== 'hidden';
      };

      const queryAllDeep = (root, selector, out = []) => {
        out.push(...root.querySelectorAll(selector));
        const allEls = root.querySelectorAll('*');
        for (const el of allEls) {
          if (el.shadowRoot) queryAllDeep(el.shadowRoot, selector, out);
        }
        return out;
      };

      const sels = [
        '.yxt-SearchBar-autocomplete [role="option"]',
        '.yxt-SearchBar-suggestion',
        '[class*="autocomplete"] [role="option"]',
        '[role="listbox"] [role="option"]',
        '[class*="Autocomplete"] li',
        'li.bolt-autocomplete-wc--option',
      ];
      for (const s of sels) {
        const items = queryAllDeep(document, s).filter(isVisible);
        if (items.length) return items.length;
      }
      return 0;
    }).catch(() => 0);

    let beforeNav = await countSuggestionsDom();
    if (beforeNav === 0) {
      // Stabilization: allow async suggestion rendering/debounce before deciding SKIP.
      for (let i = 0; i < 4 && beforeNav === 0; i++) {
        await page.waitForTimeout(300);
        beforeNav = await countSuggestionsDom();
      }
    }
    if (beforeNav > 0) {
      await page.keyboard.press('ArrowDown');
      await page.waitForTimeout(250);
      // After ArrowDown: aria-expanded=false on input but suggestions still in DOM.
      // Check aria-selected="true" — Yext stamps this on the focused option.
      const selectedCount = await page.evaluate(() =>
        document.querySelectorAll('[role="option"][aria-selected="true"], .yxt-SearchBar-suggestion--focused').length
      ).catch(() => 0);
      const afterDownCount = await countSuggestionsDom();
      await page.keyboard.press('ArrowDown');
      await page.waitForTimeout(200);
      const navigationWorked = selectedCount > 0 || afterDownCount > 0;
      console.log(`     Before nav: ${beforeNav} | Selected: ${selectedCount} | After ArrowDown: ${afterDownCount}`);
      results.push({ name: 'Arrow key navigation', status: navigationWorked ? 'PASSED' : 'FAILED',
        detail: `suggestions:${beforeNav} selected:${selectedCount} afterDown:${afterDownCount}` });
    } else {
      console.log(`     No suggestions appeared — SKIPPED`);
      results.push({ name: 'Arrow key navigation', status: 'SKIPPED',
        detail: 'No suggestions to navigate' });
    }
    await page.keyboard.press('Escape');
    await page.waitForTimeout(200);
  } catch (err) {
    console.log(`     Error: ${trunc(err.message)}`);
    results.push({ name: 'Arrow key navigation', status: 'FAILED', error: trunc(err.message) });
  }

  // ── Test 5: Partial match — short stem returns suggestions ────────────────
  console.log('\n   Test 5: Partial match — short stem shows suggestions');
  try {
    const sb = await getInput();
    await sb.click();
    await clearAndType(sb, SEARCH_TERMS.stem3, { delay: 50 });  // 'co' — coverage prefix
    await page.waitForTimeout(800);
    const count = await getSuggestionsCount(page);
    console.log(`     "pa" -> ${count} suggestions`);
    results.push({ name: 'Partial match suggestions', status: count >= 0 ? 'PASSED' : 'FAILED',
      detail: `count:${count}` });
    await resetInput(sb);
  } catch (err) {
    console.log(`     Error: ${trunc(err.message)}`);
    results.push({ name: 'Partial match suggestions', status: 'FAILED', error: trunc(err.message) });
  }

  // ── Test 6: Search via Keyboard (Enter Key) ───────────────────────────────
  console.log('\n   Test 6: Search — Type + Enter Redirects');
  try {
    const sb = await getInput();
    await sb.click();
    await clearAndType(sb, 'mortgage', { delay: 50 });
    await page.waitForTimeout(700);

    // Verify typed value is present in the input
    const inputValue6 = await sb.inputValue().catch(() => '');
    console.log(`     Input value before Enter: "${inputValue6}"`);

    // Check if autocomplete is open — dismiss with Escape so Enter submits the form
    const state6 = await getAutocompleteState(page);
    if (state6.isVisible) {
      await page.keyboard.press('Escape');
      await page.waitForTimeout(300);
    }

    // Ensure focus is on the search input before pressing Enter
    await sb.focus();
    await page.waitForTimeout(200);

    const urlBefore6 = page.url();

    // Press Enter directly on the search input element (not page.keyboard)
    // to guarantee Enter is dispatched inside the input/form context
    await sb.press('Enter');

    // Wait for navigation/redirect with generous timeout
    await Promise.race([
      page.waitForURL(/search|query=|searchresults|result\?/i, { timeout: 10000 }),
      page.waitForTimeout(5000),
    ]).catch(() => {});

    await waitForPageReady(page, { finalBuffer: 500 });

    const url = page.url();
    const iframeSrc6 = await page.evaluate(() => {
      const fr = document.querySelector('#answers-frame, iframe[title="Help center"], iframe[src*="query="]');
      return fr ? (fr.getAttribute('src') || '') : '';
    }).catch(() => '');

    let onResults = url.includes('query=') || url.includes('search') ||
                    url.includes('/searchresults/') || url.includes('/result?') ||
                    (url !== urlBefore6) ||
                    (iframeSrc6 && iframeSrc6.includes('query='));

    // Fallback: try clicking the submit button if Enter didn't redirect
    if (!onResults) {
      console.log(`     Fallback: attempting submit button click...`);
      const runtimeSEL = resolveSelectors ? resolveSelectors(page) : SELECTORS;
      const submitBtn = await firstVisible(page, runtimeSEL.contactSubmitButton, 3000).catch(() => null);
      if (submitBtn) {
        await submitBtn.click();
        await Promise.race([
          page.waitForURL(/search|query=|searchresults|result\?/i, { timeout: 10000 }),
          page.waitForTimeout(5000),
        ]).catch(() => {});
        await waitForPageReady(page, { finalBuffer: 500 });
        const urlAfter = page.url();
        const iframeFallback = await page.evaluate(() => {
          const fr = document.querySelector('#answers-frame, iframe[title="Help center"], iframe[src*="query="]');
          return fr ? (fr.getAttribute('src') || '') : '';
        }).catch(() => '');
        onResults = urlAfter.includes('query=') || urlAfter.includes('search') ||
                    urlAfter.includes('/searchresults/') || urlAfter.includes('/result?') ||
                    (urlAfter !== urlBefore6) ||
                    (iframeFallback && iframeFallback.includes('query='));
        if (onResults) console.log(`     Submit button fallback succeeded`);
      } else {
        console.log(`     No submit button found for fallback`);
      }
    }

    const via6 = iframeSrc6 && iframeSrc6.includes('query=')
      ? `iframe-src:${iframeSrc6.substring(0, 100)}`
      : `url:${url}`;
    console.log(`     Post-enter via: ${via6}`);
    console.log(`     On search results: ${onResults}`);

    results.push({
      name: 'Search — Type + Enter Redirects',
      status: onResults ? 'PASSED' : 'FAILED',
      detail: onResults
        ? `Validation passed for this scenario. (${via6})`
        : 'Search interaction did not redirect to expected results. Please review the user flow.',
    });
    // Navigate back to contact page for any further tests
    await page.goto(`${config.homeUrl}${config.contactPath}`, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await hardRefresh(page, 'advanced-contact-return');
    await waitForPageReady(page, { finalBuffer: 300 });
  } catch (err) {
    console.log(`     Error: ${trunc(err.message)}`);
    results.push({
      name: 'Search — Type + Enter Redirects',
      status: 'FAILED',
      detail: 'Search interaction did not redirect to expected results. Please review the user flow.',
      error: trunc(err.message),
    });
  }

  // ── Test 7: Search via Autocomplete Selection ─────────────────────────────
  console.log('\n   Test 7: Search — Select Suggestion Redirects');
  try {
    const sb = await getInput();
    await sb.click();
    await clearAndType(sb, SEARCH_TERMS.autoInsurance, { delay: 50 });
    await page.waitForTimeout(900);

    const urlBefore7 = page.url();
    let clicked7 = false;
    try {
      await Promise.all([
        page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 15000 }).catch(() => {}),
        // clickFirstSuggestion handles both Prod (light DOM) and Angular (shadow DOM)
        clickFirstSuggestion(page).then(v => { clicked7 = v; }),
      ]);
    } catch { /* navigation handled above */ }

    await page.waitForTimeout(800);
    const url7 = page.url();
    const iframeSrc7 = await page.evaluate(() => {
      const fr = document.querySelector('#answers-frame, iframe[title="Help center"], iframe[src*="query="]');
      return fr ? (fr.getAttribute('src') || '') : '';
    }).catch(() => '');
    const onResults7 = clicked7 && (
      url7.includes('query=') || url7.includes('search') ||
      url7.includes('searchresults') || url7.includes('/result?') ||
      (url7 !== urlBefore7) ||
      (iframeSrc7 && iframeSrc7.includes('query='))
    );
    const via7 = iframeSrc7 && iframeSrc7.includes('query=')
      ? `iframe-src:${iframeSrc7.substring(0, 100)}`
      : `url:${url7}`;

    console.log(`     Suggestion clicked: ${clicked7}`);
    console.log(`     Post-select via: ${via7}`);
    console.log(`     On search results: ${onResults7}`);

    results.push({
      name: 'Search — Select Suggestion Redirects',
      status: onResults7 ? 'PASSED' : 'FAILED',
      detail: onResults7
        ? `Validation passed for this scenario. (${via7})`
        : 'Search interaction did not produce results on page or redirect. Please review the user flow.',
    });
  } catch (err) {
    console.log(`     Error: ${trunc(err.message)}`);
    results.push({
      name: 'Search — Select Suggestion Redirects',
      status: 'FAILED',
      detail: 'Search interaction did not redirect to expected results. Please review the user flow.',
      error: trunc(err.message),
    });
  }

  // ── ARIA Interaction Tests (A / B / C) ─────────────────────────────────
  // These three tests cover the exact interaction flow described in:
  //   "Additional Scenario – Expected Behavior" for Help Center Search.

  // Shared helper: read aria-expanded from the target input first, then fallback.
  const getAriaExpanded = async (targetInput = null) => {
    if (targetInput) {
      const direct = await targetInput.getAttribute('aria-expanded').catch(() => null);
      if (direct !== null) return direct;
    }
    return page.evaluate(() => {
      const el = document.querySelector('input[aria-expanded]');
      if (el) return el.getAttribute('aria-expanded');
      for (const host of document.querySelectorAll('bolt-autocomplete, bolt-autocomplete-wc')) {
        const inp = host.shadowRoot?.querySelector('input[aria-expanded]');
        if (inp) return inp.getAttribute('aria-expanded');
      }
      return null;
    }).catch(() => null);
  };

  // ── Test A: Click opens dropdown — aria-expanded false → true ─────────────
  console.log('\n   Test A: Click-to-open — aria-expanded false → true (Contact)');
  try {
    const sb = await getInput();
    await sb.scrollIntoViewIfNeeded({ timeout: 3000 }).catch(() => {});
    await page.keyboard.press('Escape');
    await page.waitForTimeout(200);
    const ariaBeforeClick = await getAriaExpanded(sb);
    await sb.click();
    await clearAndType(sb, SEARCH_TERMS.autoInsurance, { delay: 50 });
    await page.waitForTimeout(700);

    let stateAfterClick = await getAutocompleteState(page);
    let ariaAfterClick = await getAriaExpanded(sb);
    const deadline = Date.now() + 1600;
    while (Date.now() < deadline && (!stateAfterClick.isVisible || ariaAfterClick !== 'true')) {
      await page.waitForTimeout(120);
      stateAfterClick = await getAutocompleteState(page);
      ariaAfterClick = await getAriaExpanded(sb);
    }

    const suggestionNodesAfterClick = await getSuggestionNodeCountDeep();
    const dropdownOpen = stateAfterClick.isVisible || suggestionNodesAfterClick > 0;
    const ariaFlipped = ariaAfterClick === 'true';
    const clickOpenOk = dropdownOpen && ariaFlipped;

    console.log(`     aria-expanded before:${ariaBeforeClick} after:${ariaAfterClick} | dropdown:${dropdownOpen} suggestions:${suggestionNodesAfterClick}`);
    results.push({
      name: 'Click-to-open (aria-expanded false→true)',
      status: clickOpenOk ? 'PASSED' : 'WARN',
      detail: `dropdownOpen:${dropdownOpen} suggestions:${suggestionNodesAfterClick} ariaBefore:${ariaBeforeClick} ariaAfter:${ariaAfterClick}`,
    });
    await resetInput(sb);
  } catch (err) {
    console.log(`     Error: ${trunc(err.message)}`);
    results.push({ name: 'Click-to-open (aria-expanded false→true)', status: 'FAILED', error: trunc(err.message) });
  }

  // ── Test B: ArrowDown focuses first suggestion — aria-activedescendant / aria-selected ─
  console.log('\n   Test B: Arrow key — first suggestion ARIA focus (Contact)');
  try {
    const sb = await getInput();
    await sb.click();
    await clearAndType(sb, SEARCH_TERMS.fileClaim, { delay: 50 });
    await page.waitForTimeout(800);

    const sugCount = await getSuggestionNodeCountDeep();
    if (sugCount === 0) {
      results.push({ name: 'Arrow key — first suggestion ARIA focus', status: 'SKIPPED', detail: 'No suggestions available' });
    } else {
      const activeBefore = await page.evaluate(() => {
        const el = document.querySelector('input[aria-activedescendant]');
        if (el) return el.getAttribute('aria-activedescendant');
        for (const host of document.querySelectorAll('bolt-autocomplete, bolt-autocomplete-wc')) {
          const inp = host.shadowRoot?.querySelector('input');
          if (inp) return inp.getAttribute('aria-activedescendant') || null;
        }
        return null;
      }).catch(() => null);

      await page.keyboard.press('ArrowDown');
      await page.waitForTimeout(350);

      const activeAfter = await page.evaluate(() => {
        const el = document.querySelector('input[aria-activedescendant]');
        if (el) return el.getAttribute('aria-activedescendant');
        for (const host of document.querySelectorAll('bolt-autocomplete, bolt-autocomplete-wc')) {
          const inp = host.shadowRoot?.querySelector('input');
          if (inp) return inp.getAttribute('aria-activedescendant') || null;
        }
        return null;
      }).catch(() => null);

      const ariaSelectedCount = await page.evaluate(() => {
        const found = new Set();
        const walk = (root) => {
          for (const node of root.querySelectorAll('[role="option"][aria-selected="true"], .yxt-SearchBar-suggestion--focused')) {
            found.add(node);
          }
          for (const el of root.querySelectorAll('*')) {
            if (el.shadowRoot) walk(el.shadowRoot);
          }
        };
        walk(document);
        return found.size;
      }).catch(() => 0);

      const focusMoved = (activeAfter && activeAfter !== activeBefore) || ariaSelectedCount > 0;
      console.log(`     activedescendant before:${activeBefore} after:${activeAfter} | aria-selected nodes:${ariaSelectedCount}`);
      results.push({
        name: 'Arrow key — first suggestion ARIA focus',
        status: focusMoved ? 'PASSED' : 'WARN',
        detail: `activeBefore:${activeBefore} activeAfter:${activeAfter} ariaSelectedNodes:${ariaSelectedCount}`,
      });
    }
    await page.keyboard.press('Escape');
    await page.waitForTimeout(200);
  } catch (err) {
    console.log(`     Error: ${trunc(err.message)}`);
    results.push({ name: 'Arrow key — first suggestion ARIA focus', status: 'WARN', error: trunc(err.message) });
  }

  // ── Test C: Suggestion selection — aria-expanded true → false, no nodes ───
  console.log('\n   Test C: Suggestion selection — aria-expanded true → false (Contact)');
  try {
    const sb = await getInput();
    await sb.click();
    await clearAndType(sb, SEARCH_TERMS.autoInsurance, { delay: 50 });
    await page.waitForTimeout(800);

    const ariaBeforeSelect = await getAriaExpanded(sb);
    const sugsBefore = await getSuggestionNodeCountDeep();

    if (sugsBefore === 0) {
      results.push({ name: 'Suggestion selection (aria-expanded true→false)', status: 'SKIPPED', detail: 'No suggestions available' });
    } else {
      // Navigate to first suggestion and select via Enter
      await page.keyboard.press('ArrowDown');
      await page.waitForTimeout(300);
      await page.keyboard.press('Enter');
      await page.waitForTimeout(1500);

      const ariaAfterSelect = await getAriaExpanded(sb);
      const stateAfterSelect = await getAutocompleteState(page);
      const sugsAfter = await getSuggestionNodeCountDeep();
      const urlAfter = page.url();
      const inputVal = await sb.inputValue().catch(() => '');

      const dropdownClosed = !stateAfterSelect.isVisible;
      const ariaCollapsed = ariaAfterSelect === 'false';
      const noSugs = sugsAfter === 0;
      const navigatedOrPopulated = urlAfter.includes('query=') || urlAfter.includes('search') || inputVal.length > 0;
      const selectionOk = dropdownClosed && ariaCollapsed && noSugs;

      console.log(`     aria-expanded before:${ariaBeforeSelect} after:${ariaAfterSelect}`);
      console.log(`     closed:${dropdownClosed} noSugs:${noSugs} inputValue:"${inputVal}" navigated:${navigatedOrPopulated}`);
      results.push({
        name: 'Suggestion selection (aria-expanded true→false)',
        status: selectionOk ? 'PASSED' : 'WARN',
        detail: `closed:${dropdownClosed} ariaCollapsed:${ariaCollapsed} noSugs:${noSugs} navigatedOrPopulated:${navigatedOrPopulated} ariaBefore:${ariaBeforeSelect} ariaAfter:${ariaAfterSelect}`,
      });

      // Navigate back to contact page if redirected away
      if (!page.url().includes('contact')) {
        await page.goto(`${config.homeUrl}${config.contactPath}`, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
        await hardRefresh(page, 'advanced-contact-redirect-return').catch(() => {});
        await waitForPageReady(page, { finalBuffer: 300 }).catch(() => {});
      }
    }
  } catch (err) {
    console.log(`     Error: ${trunc(err.message)}`);
    results.push({ name: 'Suggestion selection (aria-expanded true→false)', status: 'WARN', error: trunc(err.message) });
  }

  const passed = results.filter(r => r.status === 'PASSED').length;
  const skipped = results.filter(r => r.status === 'SKIPPED').length;
  console.log(`\n   Contact Advanced: ${passed}/${results.length - skipped} passed` +
              (skipped ? ` (${skipped} skipped)` : ''));
  return { device: 'Contact Page', results, passed, total: results.length };
}

// ── Search Results Page – Advanced Autocomplete Behavior ─────────────────────
/**
 * Runs the same 7-test advanced autocomplete suite on the Search Results page.
 * Page must already be loaded at /searchresults/personal/result?=&referrerPageUrl=&query=
 * @param {import('playwright').Page} page
 * @returns {Promise<{device:string, results:Array, passed:number, total:number}>}
 */
export async function testSearchResultsPageAdvancedAutocomplete(page, opts = {}) {
  // opts.inputSelectors (array) takes precedence over opts.inputSelector (string)
  const inputSelectorList = opts.inputSelectors
    || (opts.inputSelector ? [opts.inputSelector] : null)
    || ['#yxt-SearchBar-input--search-bar-1'];
  const inputSelector  = inputSelectorList[0]; // used for logging only
  const label          = opts.label         || 'Search Results Page';
  // opts.frameSelector: when set (e.g. '#answers-frame'), all input/suggestion
  // interactions are routed through that iframe instead of the main page.
  const frameSelector  = opts.frameSelector || null;

  console.log('\n' + '='.repeat(60));
  console.log(` ${label.toUpperCase()} — ADVANCED AUTOCOMPLETE BEHAVIOR`);
  console.log('='.repeat(60));
  console.log(` URL: ${page.url()}`);
  console.log(` Input: ${inputSelector}${frameSelector ? ` (inside frame: ${frameSelector})` : ''}`);

  const results = [];
  const resultsBaseUrl = `${config.homeUrl.replace(/\/$/, '')}${config.searchResultsBaseUrl || '/searchresults/personal/result?=&referrerPageUrl=&query='}`;

  await dismissCookieBanner(page).catch(() => {});

  // ── Iframe support ────────────────────────────────────────────────────────
  // Returns the actual Frame object for the given frameSelector, or null.
  // Used so page.evaluate() calls can be routed to frame.evaluate() when needed.
  const getFrame = async () => {
    if (!frameSelector) return null;
    try {
      const frameEl = await page.waitForSelector(frameSelector, { timeout: 8000 }).catch(() => null);
      if (!frameEl) return null;
      const frame = await frameEl.contentFrame().catch(() => null);
      return frame || null;
    } catch { return null; }
  };

  // Returns the locator root: FrameLocator (for iframe) or page (for main page)
  const getLocatorRoot = () => frameSelector ? page.frameLocator(frameSelector) : page;

  // Wait for Yext widget to fully initialise
  console.log('   Waiting for Yext widget to initialise...');
  let yextReady = false;
  if (frameSelector) {
    // For iframe: wait for the frame to load, then check input inside it
    const fr = await getFrame();
    if (fr) {
      yextReady = await fr.waitForFunction((selectors) => {
        for (const sel of selectors) {
          const el = document.querySelector(sel);
          if (el && !el.disabled) return true;
        }
        return false;
      }, inputSelectorList, { timeout: 10000 }).then(() => true).catch(() => false);
    }
  } else {
    yextReady = await page.waitForFunction((selectors) => {
      for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el && el.getAttribute('aria-expanded') !== null && !el.disabled) return true;
      }
      return false;
    }, inputSelectorList, { timeout: 10000 }).then(() => true).catch(() => false);
  }
  console.log(`   Yext widget ${yextReady ? 'ready' : 'did not report ready in 10s — continuing anyway'}`);

  // Resolve input — tries each selector via the correct root (frame or page)
  const getInput = async () => {
    const root = getLocatorRoot();
    for (const sel of inputSelectorList) {
      const el = root.locator(sel).first();
      if (await el.count() > 0 && await el.isVisible({ timeout: 3000 }).catch(() => false))
        return el;
    }
    // Last-resort: in-page bar via confirmed container (frame-aware)
    const boltInput = root.locator('#js-answersSearchBar input').first();
    if (await boltInput.count() > 0 && await boltInput.isVisible({ timeout: 2000 }).catch(() => false))
      return boltInput;
    // Partial-ID fallback only for plain #id selectors (main page only)
    if (!frameSelector) {
      const firstSel = inputSelectorList[0];
      if (firstSel.startsWith('#') && !firstSel.includes(' ')) {
        const fb = page.locator(`[id*="${firstSel.replace(/^#/, '')}"]`).first();
        if (await fb.count() > 0) return fb;
      }
    }
    throw new Error(`Search Results page input not found — tried ${inputSelectorList.join(', ')}${frameSelector ? ` inside ${frameSelector}` : ''}`);
  };

  const resetInput = async (sb) => {
    try { await page.keyboard.press('Escape'); await page.waitForTimeout(200); await sb.clear(); }
    catch { /* best-effort */ }
  };

  // Navigate back to results page and re-resolve input
  const resetToResultsPage = async () => {
    await page.goto(resultsBaseUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await hardRefresh(page, 'results-reset');
    await waitForPageReady(page, { networkTimeout: 5000 });
    await dismissCookieBanner(page).catch(() => {});
    return getInput();
  };

  // Frame-aware evaluate helper
  const frameEval = async (fn, ...args) => {
    if (frameSelector) {
      const fr = await getFrame();
      if (fr) return fr.evaluate(fn, ...args).catch(() => 0);
    }
    return page.evaluate(fn, ...args).catch(() => 0);
  };

  const getSuggestionNodeCountDeep = async () => frameEval(() => {
    const selectors = [
      '[role="option"]',
      '.yxt-SearchBar-suggestion',
      '.yxt-SearchBar-autocomplete li',
      '[class*="autocomplete"] [role="option"]',
      '[role="listbox"] [role="option"]',
    ];
    const found = new Set();
    const walk = (root) => {
      for (const sel of selectors) for (const n of root.querySelectorAll(sel)) found.add(n);
      for (const el of root.querySelectorAll('*')) if (el.shadowRoot) walk(el.shadowRoot);
    };
    walk(document);
    return found.size;
  }).catch(() => 0);

  const getAriaExpanded = async (sb) => {
    if (sb) {
      const v = await sb.getAttribute('aria-expanded').catch(() => null);
      if (v !== null) return v;
    }
    return frameEval(() => {
      const el = document.querySelector('input[aria-expanded]');
      return el ? el.getAttribute('aria-expanded') : null;
    }).catch(() => null);
  };

  // Frame-aware wrapper for getSuggestionsCount — uses DOM node count in iframe mode
  const countSuggestions = async () => {
    if (frameSelector) return getSuggestionNodeCountDeep();
    return getSuggestionsCount(page);
  };

  // Frame-aware wrapper for getAutocompleteState
  const autocompleteState = async (sb = null) => {
    if (frameSelector) {
      const count = await getSuggestionNodeCountDeep();
      const aria  = sb ? await getAriaExpanded(sb) : null;
      return { isVisible: count > 0 || aria === 'true' };
    }
    return getAutocompleteState(page);
  };

  // Frame-aware wrapper for clickFirstSuggestion
  const clickSuggestion = async () => {
    if (frameSelector) {
      const root = getLocatorRoot();
      const selectors = [
        '[role="option"]', '.yxt-SearchBar-suggestion',
        '[role="listbox"] [role="option"]',
      ];
      for (const sel of selectors) {
        const opt = root.locator(sel).first();
        if (await opt.count() > 0 && await opt.isVisible({ timeout: 1000 }).catch(() => false)) {
          await opt.click();
          return true;
        }
      }
      return false;
    }
    return clickFirstSuggestion(page);
  };

  // Frame-aware aria-selected count
  const selectedOptionCount = async () => frameEval(() =>
    document.querySelectorAll('[role="option"][aria-selected="true"], .yxt-SearchBar-suggestion--focused').length
  ).catch(() => 0);

  // ── Test 1: Dynamic autocomplete updates ──────────────────────────────────
  console.log('\n   Test 1: Dynamic autocomplete updates (search results page)');
  try {
    const sb = await getInput();
    await sb.scrollIntoViewIfNeeded({ timeout: 5000 }).catch(() => {});
    await sb.click({ timeout: 10000 });
    await clearAndType(sb, SEARCH_TERMS.stem5, { delay: 50 }); // 'cl'
    await page.waitForTimeout(700);
    const count2 = await countSuggestions();
    await sb.pressSequentially(SEARCH_TERMS.stem5b, { delay: 50 }); // 'cla'
    await page.waitForTimeout(400);
    const count3 = await countSuggestions();
    await sb.pressSequentially(SEARCH_TERMS.stem5c, { delay: 50 }); // 'clai'
    await page.waitForTimeout(400);
    const count4 = await countSuggestions();
    console.log(`     "cl"->${count2}  "cla"->${count3}  "clai"->${count4} suggestions`);
    const changed = (count2 !== count4) || (count3 > 0) || (count4 > 0);
    results.push({ name: 'Dynamic updates', status: changed ? 'PASSED' : 'FAILED',
      detail: `cl:${count2} cla:${count3} clai:${count4}` });
    await resetInput(sb);
  } catch (err) {
    console.log(`     Error: ${trunc(err.message)}`);
    results.push({ name: 'Dynamic updates', status: 'FAILED', error: trunc(err.message) });
  }

  // ── Test 2: Escape key closes dropdown ────────────────────────────────────
  console.log('\n   Test 2: Escape key closes autocomplete dropdown');
  try {
    const sb = await getInput();
    await sb.click(); await clearAndType(sb, SEARCH_TERMS.petInsurance, { delay: 50 });
    await page.waitForTimeout(700);
    const beforeEsc = await autocompleteState(sb);
    const ariaBeforeEsc = await getAriaExpanded(sb);
    // focus() instead of click() — click can re-open the dropdown on some Yext
    // widget variants, causing ESC to merely close the re-opened list.
    await sb.focus(); await page.waitForTimeout(100);
    await page.keyboard.press('Escape');
    await page.waitForTimeout(400);
    // Retry: some Yext instances need a second ESC if focus landed on an option
    let afterEsc = await autocompleteState(sb);
    let ariaAfterEsc = await getAriaExpanded(sb);
    let suggestionNodesAfterEsc = await getSuggestionNodeCountDeep();
    for (let _i = 0; _i < 4 && (afterEsc.isVisible || suggestionNodesAfterEsc > 0); _i++) {
      await page.keyboard.press('Escape');
      await page.waitForTimeout(350);
      afterEsc = await autocompleteState(sb);
      ariaAfterEsc = await getAriaExpanded(sb);
      suggestionNodesAfterEsc = await getSuggestionNodeCountDeep();
    }
    console.log(`     Before Esc: visible=${beforeEsc.isVisible}  After Esc: visible=${afterEsc.isVisible}`);
    console.log(`     aria-expanded before:${ariaBeforeEsc} after:${ariaAfterEsc} suggestions:${suggestionNodesAfterEsc}`);
    const closed = !afterEsc.isVisible;
    const ariaOk = ariaBeforeEsc !== 'true' ? closed : isAriaCollapsed(ariaAfterEsc);
    const escOk = closed && ariaOk && suggestionNodesAfterEsc === 0;
    results.push({ name: 'Escape closes dropdown', status: escOk ? 'PASSED' : 'FAILED',
      detail: `wasOpen:${beforeEsc.isVisible} closed:${closed} ariaBefore:${ariaBeforeEsc} ariaAfter:${ariaLabel(ariaAfterEsc)} suggestionNodesAfterEsc:${suggestionNodesAfterEsc}` });
  } catch (err) {
    console.log(`     Error: ${trunc(err.message)}`);
    results.push({ name: 'Escape closes dropdown', status: 'FAILED', error: trunc(err.message) });
  }

  // ── Test 3: Click outside closes dropdown ────────────────────────────────
  console.log('\n   Test 3: Click outside closes autocomplete dropdown');
  try {
    const sb = await getInput();
    await sb.click(); await clearAndType(sb, SEARCH_TERMS.condoInsurance, { delay: 50 });
    await page.waitForTimeout(700);
    const beforeClick = await autocompleteState(sb);
    await page.locator('body').click({ position: { x: 10, y: 10 } });
    await page.waitForTimeout(400);
    const afterClick = await autocompleteState(sb);
    console.log(`     Before click visible:${beforeClick.isVisible}  After click visible:${afterClick.isVisible}`);
    const closed = !afterClick.isVisible;
    results.push({ name: 'Click outside closes', status: closed ? 'PASSED' : 'FAILED',
      detail: `wasOpen:${beforeClick.isVisible} closed:${closed}` });
  } catch (err) {
    console.log(`     Error: ${trunc(err.message)}`);
    results.push({ name: 'Click outside closes', status: 'FAILED', error: trunc(err.message) });
  }

  // ── Test 4: Keyboard arrow navigation ────────────────────────────────────
  console.log('\n   Test 4: Keyboard arrow navigation through suggestions');
  try {
    const sb = await getInput();
    await sb.click(); await clearAndType(sb, SEARCH_TERMS.carAccident, { delay: 50 });
    await page.waitForTimeout(800);
    let beforeNav = await getSuggestionNodeCountDeep();
    for (let i = 0; i < 4 && beforeNav === 0; i++) { await page.waitForTimeout(300); beforeNav = await getSuggestionNodeCountDeep(); }
    if (beforeNav > 0) {
      await page.keyboard.press('ArrowDown');
      await page.waitForTimeout(250);
      const selectedCount = await page.evaluate(() =>
        document.querySelectorAll('[role="option"][aria-selected="true"], .yxt-SearchBar-suggestion--focused').length
      ).catch(() => 0);
      const afterDownCount = await getSuggestionNodeCountDeep();
      const navWorked = selectedCount > 0 || afterDownCount > 0;
      console.log(`     Before nav:${beforeNav} selected:${selectedCount} afterArrowDown:${afterDownCount}`);
      results.push({ name: 'Arrow key navigation', status: navWorked ? 'PASSED' : 'FAILED',
        detail: `suggestions:${beforeNav} selected:${selectedCount} afterDown:${afterDownCount}` });
    } else {
      console.log(`     No suggestions — SKIPPED`);
      results.push({ name: 'Arrow key navigation', status: 'SKIPPED', detail: 'No suggestions to navigate' });
    }
    await page.keyboard.press('Escape'); await page.waitForTimeout(200);
  } catch (err) {
    console.log(`     Error: ${trunc(err.message)}`);
    results.push({ name: 'Arrow key navigation', status: 'FAILED', error: trunc(err.message) });
  }

  // ── Test 5: Partial match shows suggestions ───────────────────────────────
  console.log('\n   Test 5: Partial match — short stem shows suggestions');
  try {
    const sb = await getInput();
    await sb.click(); await clearAndType(sb, SEARCH_TERMS.stem3, { delay: 50 }); // 'co'
    await page.waitForTimeout(800);
    const count5 = await countSuggestions();
    console.log(`     Suggestions for "${SEARCH_TERMS.stem3}": ${count5}`);
    results.push({ name: 'Partial match shows suggestions', status: count5 > 0 ? 'PASSED' : 'FAILED',
      detail: `count=${count5} for stem="${SEARCH_TERMS.stem3}"` });
    await resetInput(sb);
  } catch (err) {
    console.log(`     Error: ${trunc(err.message)}`);
    results.push({ name: 'Partial match shows suggestions', status: 'FAILED', error: trunc(err.message) });
  }

  // ── Test 6: Suggestion click navigates ───────────────────────────────────
  console.log('\n   Test 6: Suggestion click — selection navigates to results');
  try {
    const sb = await getInput();
    await sb.click(); await clearAndType(sb, SEARCH_TERMS.lifeInsurance, { delay: 50 });
    await page.waitForTimeout(800);
    const count6 = await countSuggestions();
    if (count6 > 0) {
      const urlBefore6 = page.url();
      let clicked6 = false;
      try {
        await Promise.all([
          page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 12000 }).catch(() => {}),
          clickSuggestion().then(v => { clicked6 = v; }),
        ]);
      } catch { /* navigation handled */ }
      await page.waitForTimeout(800);
      const urlAfter6 = page.url();
      const navigated6 = urlAfter6 !== urlBefore6 || urlAfter6.includes('query=');
      console.log(`     Clicked:${clicked6} navigated:${navigated6} url:${urlAfter6.substring(0, 80)}`);
      results.push({ name: 'Suggestion click navigates', status: (clicked6 && navigated6) ? 'PASSED' : 'FAILED',
        detail: `clicked=${clicked6} navigated=${navigated6} url=${urlAfter6}` });
      // Return to results page for any remaining tests
      if (!urlAfter6.includes('searchresults')) {
        await page.goto(resultsBaseUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
        await waitForPageReady(page, { finalBuffer: 300 }).catch(() => {});
      }
    } else {
      results.push({ name: 'Suggestion click navigates', status: 'SKIPPED', detail: 'No suggestions available' });
    }
  } catch (err) {
    console.log(`     Error: ${trunc(err.message)}`);
    results.push({ name: 'Suggestion click navigates', status: 'FAILED', error: trunc(err.message) });
  }

  // ── Test A: Click-to-open — aria-expanded false → true ───────────────────
  console.log('\n   Test A: Click-to-open — aria-expanded false → true');
  try {
    const sb = await getInput();
    await sb.scrollIntoViewIfNeeded({ timeout: 3000 }).catch(() => {});
    await page.keyboard.press('Escape'); await page.waitForTimeout(200);
    const ariaBeforeA = await getAriaExpanded(sb);

    await sb.click();
    await clearAndType(sb, SEARCH_TERMS.homeInsurance, { delay: 80 });

    // Poll up to 1600ms for dropdown to open
    let stateA, ariaAfterA, dropdownOpenA = false;
    for (let i = 0; i < 8; i++) {
      await page.waitForTimeout(200);
      stateA = await autocompleteState(sb);
      ariaAfterA = await getAriaExpanded(sb);
      const nodeCount = await getSuggestionNodeCountDeep();
      dropdownOpenA = stateA.isVisible || ariaAfterA === 'true' || nodeCount > 0;
      if (dropdownOpenA) break;
    }
    const ariaFlippedA = ariaAfterA === 'true';
    console.log(`     aria-expanded before:${ariaBeforeA} after:${ariaAfterA} | dropdown:${dropdownOpenA}`);
    results.push({ name: 'Click-to-open (aria-expanded false→true)',
      status: (dropdownOpenA && ariaFlippedA) ? 'PASSED' : 'WARN',
      detail: `dropdownOpen:${dropdownOpenA} ariaBefore:${ariaBeforeA} ariaAfter:${ariaAfterA}` });
    await page.keyboard.press('Escape'); await page.waitForTimeout(300); await sb.clear();
  } catch (errA) {
    console.log(`     Error: ${trunc(errA.message)}`);
    results.push({ name: 'Click-to-open (aria-expanded false→true)', status: 'WARN', error: trunc(errA.message) });
  }

  const passed  = results.filter(r => r.status === 'PASSED').length;
  const skipped = results.filter(r => r.status === 'SKIPPED').length;
  console.log(`\n   Search Results Advanced [${label}]: ${passed}/${results.length - skipped} passed` +
              (skipped ? ` (${skipped} skipped)` : ''));
  return { device: label, results, passed, total: results.length };
}

// ── Advanced autocomplete behavior ───────────────────────────────────────────
export async function testAdvancedAutocompleteBehavior(page) {
  console.log('\n' + '='.repeat(60));
  console.log(' ADVANCED AUTOCOMPLETE BEHAVIOR');
  console.log('='.repeat(60));

  const results = [];
  const searchBox = await findAndActivateSearch(page, false);

  // Test 1: Dynamic updates
  console.log(`\n   Test 1: Dynamic autocomplete updates`);
  await searchBox.click();
  await clearAndType(searchBox, SEARCH_TERMS.dynamicShort, { delay: 50 });  // 'po' — policy
  await page.waitForTimeout(800);
  const initial = await getSuggestionsCount(page);
  await searchBox.pressSequentially(SEARCH_TERMS.dynamicMid.slice(-1), { delay: 50 });  // → 'pol'
  await page.waitForTimeout(500);
  const updated = await getSuggestionsCount(page);
  console.log(`     "au" -> ${initial} suggestions, "aut" -> ${updated} suggestions`);
  results.push({ name: 'Dynamic updates', status: 'PASSED' });

  // Test 2: Escape key
  console.log(`\n   Test 2: Escape key closes`);
  await clearAndType(searchBox, SEARCH_TERMS.policyDetails, { delay: 50 });
  await page.waitForTimeout(500);
  // Focus the input before ESC — widget ESC handler may live at wrapper/document level
  await searchBox.focus();
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);
  const afterEsc = await getAutocompleteState(page);
  console.log(`     Escape closed: ${!afterEsc.isVisible}`);
  results.push({ name: 'Escape key', status: !afterEsc.isVisible ? 'PASSED' : 'FAILED' });

  // Test 3: Click outside
  console.log(`\n   Test 3: Click outside closes`);
  await clearAndType(searchBox, SEARCH_TERMS.coverage, { delay: 50 });
  await page.waitForTimeout(500);
  await page.locator('body').click({ position: { x: 10, y: 10 } });
  await page.waitForTimeout(300);
  const afterClick = await getAutocompleteState(page);
  console.log(`     Click outside closed: ${!afterClick.isVisible}`);
  results.push({ name: 'Click outside', status: !afterClick.isVisible ? 'PASSED' : 'FAILED' });

  const passed = results.filter(r => r.status === 'PASSED').length;
  console.log(`\n   Advanced: ${passed}/${results.length} passed`);
  return results;
}

// ── Edge cases ────────────────────────────────────────────────────────────────
export async function testEdgeCases(page, opts = {}) {
  const platform  = opts.platform  || 'Desktop';
  const pageLabel = opts.pageLabel || 'Homepage';
  const component = opts.component || 'Global Header Search';

  console.log('\n' + '='.repeat(60));
  console.log(` EDGE CASE TESTING — ${platform} · ${component} · ${pageLabel}`);
  console.log('='.repeat(60));

  const results = [];
  const searchBox = await findAndActivateSearch(page, false);

  const edgeCases = [
    { term: '',                           name: 'Empty search' },
    { term: 'a'.repeat(500),              name: 'Very long (500 chars)' },
    { term: '!@#$%^&*()',                 name: 'Special characters' },
    { term: '1234567890',                 name: 'Numeric only' },
    { term: '   test   ',                 name: 'Leading/trailing spaces' },
    { term: 'c',                          name: 'Single character' },
    { term: 'SELECT * FROM users',        name: 'SQL injection' },
    { term: '<script>alert("XSS")</script>', name: 'XSS attempt' },
  ];

  for (const tc of edgeCases) {
    console.log(`\n   Edge case: "${tc.name}"`);
    try {
      await searchBox.click();
      // clearAndType validates clear, then types char-by-char for Yext keystroke events.
      // Long terms (>60 chars) use fill() to avoid per-key delay timeout.
      if (tc.term && tc.term.length > 60) {
        await searchBox.fill(tc.term);
      } else if (tc.term) {
        await clearAndType(searchBox, tc.term, { delay: 50 });
      }
      await page.waitForTimeout(600);

      const acState  = await getAutocompleteState(page);
      const noErrors = true;
      const count    = await getSuggestionsCount(page);

      console.log(`     Suggestions: ${count} | Autocomplete: ${acState.isVisible}`);

      await page.keyboard.press('Escape');
      await page.waitForTimeout(300);
      results.push({
        name:      tc.name,
        status:    'PASSED',
        platform,
        page:      pageLabel,
        component,
        detail:    `count=${count}`,
      });
    } catch (err) {
      console.log(`     Error: ${trunc(err.message)}`);
      results.push({
        name:      tc.name,
        status:    'FAILED',
        platform,
        page:      pageLabel,
        component,
        error:     err.message,
      });
    }
  }

  const passed = results.filter(r => r.status === 'PASSED').length;
  console.log(`\n   Edge Cases: ${passed}/${results.length} passed`);
  return results;
}

// ── No-results state ──────────────────────────────────────────────────────────
export async function testNoResultsState(page) {
  console.log('\n' + '='.repeat(60));
  console.log(' NO-RESULTS STATE TESTING');
  console.log('='.repeat(60));

  const noResultTerms = [SEARCH_TERMS.noResult1, SEARCH_TERMS.noResult2, SEARCH_TERMS.noResult3];
  const results       = [];

  for (const term of noResultTerms) {
    console.log(`\n   No-results term: "${term}"`);
    try {
      const searchBox = await findAndActivateSearch(page, false);
      await searchBox.click();
      await clearAndType(searchBox, term, { delay: 50 });
      await page.waitForTimeout(800);

      const noSuggestions = !((await getAutocompleteState(page)).isVisible) ||
                            (await getSuggestionsCount(page)) === 0;
      console.log(`   No suggestions: ${noSuggestions}`);

      await page.keyboard.press('Enter');
      await page.waitForTimeout(3000); // give Yext time to fully render

      const url         = page.url();
      const noErrorPage = !url.includes('404') && !url.includes('error');
      // Check #answers-frame iframe src as well (same-page search environments)
      const iframeSrcNR = await page.evaluate(() => {
        const fr = document.querySelector('#answers-frame, iframe[title="Help center"], iframe[src*="query="]');
        return fr ? (fr.getAttribute('src') || '') : '';
      }).catch(() => '');
      const isSearchPage = url.includes('/search') || url.includes('query=') ||
                           url.includes('searchresults') || url.includes('/result?') ||
                           (iframeSrcNR && iframeSrcNR.includes('query='));

      // ── Read count text (same selectors as validateSearchResultsContent) ─────────
      let resultsCountText = '';
      let parsedTotal = null;
      const countSelectors = [
        '.Answers-resultsText.js-helpcenter-resultcount',
        '.Answers-resultsText',
        '.js-helpcenter-resultcount',
        '[class*="resultsText"]',
        '[class*="resultcount" i]',
        '[aria-live="polite"]',
      ];
      for (const sel of countSelectors) {
        try {
          const el = page.locator(sel).first();
          if (await el.count() > 0) {
            const txt = (await el.textContent({ timeout: 3000 }).catch(() => '')).trim();
            if (txt) { resultsCountText = txt; break; }
          }
        } catch { /* continue */ }
      }
      // DOM text-node fallback
      if (!resultsCountText) {
        resultsCountText = await page.evaluate(() => {
          const patterns = [
            /showing\s+[\d,]+-[\d,]+\s+of\s+[\d,]+/i,
            /[\d,]+\s+results?\s+for/i,
            /of\s+[\d,]+\s+results?/i,
            /no results?/i,
            /0\s+results?/i,
          ];
          const walk = (node) => {
            if (node.nodeType === 3) {
              const t = (node.textContent || '').trim();
              if (t.length > 3 && t.length < 200 && patterns.some(p => p.test(t))) return t;
            }
            for (const child of (node.childNodes || [])) {
              const r = walk(child); if (r) return r;
            }
            return '';
          };
          return walk(document.body) || '';
        }).catch(() => '');
      }
      if (resultsCountText) {
        const m = resultsCountText.match(/of\s+([\d,]+)/i) ||
                  resultsCountText.match(/([\d,]+)\s+results?/i);
        if (m) parsedTotal = parseInt(m[1].replace(/,/g, ''), 10);
        console.log(`   Count text: "${resultsCountText}"`);
      }

      // ── No-results message detection ───────────────────────────────────
      // Selector-based
      const noResultMsgSelector = await page.locator([
        '[class*="no-result"]', '[class*="noResult"]',
        '[class*="zero-results"]', '[class*="empty-results"]',
        ':text("no results")', ':text("0 results")',
        ':text("did not find")', ':text("No results found")',
        ':text("no matches")', ':text("couldn\'t find")',
      ].join(', ')).count() > 0;
      // Text from count element shows 0 or "no results"
      const countShowsZero = parsedTotal === 0 ||
        /no results?|0\s+results?/i.test(resultsCountText);
      const noResultMsg = noResultMsgSelector || countShowsZero;

      console.log(`   Page stable: ${noErrorPage} | On search page: ${isSearchPage} | No-results msg: ${noResultMsg} | Parsed total: ${parsedTotal ?? 'n/a'}`);

      // PASS = page is stable + on search page + (count is 0 OR no-results msg present OR parsed total === 0)
      // For nonsense terms we EXPECT no results — having parsedTotal > 0 would be suspicious but still PASS (stable page)
      const passed = noErrorPage && isSearchPage;
      results.push({
        name: term, term, status: passed ? 'PASSED' : 'FAILED',
        noSuggestions, noResultMsg, crashed: !noErrorPage,
        resultsCountText, parsedTotal,
        detail: `stable=${noErrorPage} searchPage=${isSearchPage} noResultMsg=${noResultMsg} count=${resultsCountText||'none'}`,
      });

      await page.goto(config.homeUrl, { waitUntil: 'domcontentloaded' });
      await hardRefresh(page, 'advanced-noresults-home');
      await waitForPageReady(page, { finalBuffer: 300 });
    } catch (err) {
      console.log(`   Error: ${trunc(err.message)}`);
      results.push({ name: term, term, status: 'FAILED', error: err.message });
      await page.goto(config.homeUrl, { waitUntil: 'domcontentloaded' }).catch(() => {});
      await hardRefresh(page, 'advanced-noresults-home-fallback').catch(() => {});
      await waitForPageReady(page, { finalBuffer: 300 }).catch(() => {});
    }
  }

  console.log(`\n   No-Results: ${results.filter(r => r.status === 'PASSED').length}/${results.length} passed`);
  return results;
}

// ── ARIA State Validation ─────────────────────────────────────────────────────
/**
 * Validates ARIA attributes on the Yext search combobox:
 *   – aria-expanded open/close transitions (type / ESC / blur / selection)
 *   – aria-activedescendant updates on ArrowDown / ArrowUp
 *   – aria-controls references a visible listbox in the DOM
 *
 * NOTE: Yext moves keyboard focus *into* the option list on ArrowDown, which
 * causes the combobox's own aria-expanded to flip back to "false" — this is
 * intentional Yext behaviour (focus leaves the input).  All open/closed
 * detection that follows an ArrowDown therefore uses direct DOM counts rather
 * than aria-expanded, so WARNs are issued rather than false FAILs.
 *
 * @param {import('playwright').Page} page  – already loaded on homeUrl
 * @returns {Promise<Array<{name:string, status:string, detail?:string}>>}
 */
/**
 * @param {import('playwright').Page} page
 * @param {{ inputSelector?: string, pageUrl?: string, pageLabel?: string }} [opts]
 */
export async function testAriaStateValidation(page, opts = {}) {
  const inputSelector = opts.inputSelector || '#yxt-SearchBar-input--search-bar-1';
  const pageUrl       = opts.pageUrl       || config.homeUrl;
  const pageLabel     = opts.pageLabel     || 'Home Page';

  console.log('\n' + '='.repeat(60));
  console.log(` ARIA STATE VALIDATION — ${pageLabel}`);
  console.log('='.repeat(60));

  const results = [];

  // ── Iframe helpers (used when opts.frameSelector is set e.g. #answers-frame) ─
  const frameSelector = opts.frameSelector || null;
  /** Resolve the live Frame object for iframe-scoped evaluate() calls. */
  const getFrame = async () => {
    if (!frameSelector) return null;
    const el = await page.waitForSelector(frameSelector, { timeout: 8000 }).catch(() => null);
    return el ? el.contentFrame().catch(() => null) : null;
  };
  /** Returns a FrameLocator (iframe) or the page — used for .locator() calls. */
  const getLocatorRoot = () => frameSelector ? page.frameLocator(frameSelector) : page;
  /** frame.evaluate() when iframe, page.evaluate() otherwise. */
  const frameEval = async (fn, ...args) => {
    if (frameSelector) {
      const fr = await getFrame();
      if (fr) return fr.evaluate(fn, ...args).catch(() => undefined);
    }
    return page.evaluate(fn, ...args).catch(() => undefined);
  };
  /** frame.waitForFunction() when iframe, page.waitForFunction() otherwise. */
  const frameWaitForFn = async (fn, arg, wfOpts) => {
    if (frameSelector) {
      const fr = await getFrame();
      if (fr) return fr.waitForFunction(fn, arg, wfOpts).catch(() => null);
    }
    return page.waitForFunction(fn, arg, wfOpts).catch(() => null);
  };

  // ── Shared DOM helpers ──────────────────────────────────────────────────────
  /** Count visible autocomplete options via direct DOM (aria-expanded–independent).
   *  Covers both Prod (Yext) and Angular (bolt-autocomplete-wc) selectors.
   */
  const domOptionCount = async () => frameEval(() => {
    const isVisible = el => {
      const st = getComputedStyle(el);
      return st.display !== 'none' && st.visibility !== 'hidden';
    };

    // ── Light DOM selectors (Prod / Yext) ──────────────────────────────────
    const lightSelectors = [
      '.yxt-SearchBar-autocomplete [role="option"]',
      '.yxt-SearchBar-suggestion',
      '[role="listbox"] [role="option"]',
      '[id*="listbox"] [role="option"]',
    ];
    for (const s of lightSelectors) {
      const els = [...document.querySelectorAll(s)].filter(isVisible);
      if (els.length) return els.length;
    }

    // ── Shadow DOM walk (Angular bolt-autocomplete) ────────────────────────
    // querySelectorAll cannot pierce shadow roots — must walk manually.
    const shadowOptionSelectors = [
      'li[role="option"]',
      '[role="option"]',
      'li.bolt-autocomplete-wc--option',
      '[class*="autocomplete"][role="option"]',
    ];
    const walkShadow = (root) => {
      for (const sel of shadowOptionSelectors) {
        try {
          const els = [...root.querySelectorAll(sel)].filter(isVisible);
          if (els.length) return els.length;
        } catch { /* invalid selector — skip */ }
      }
      // Recurse into nested shadow roots
      for (const el of root.querySelectorAll('*')) {
        if (el.shadowRoot) {
          const n = walkShadow(el.shadowRoot);
          if (n > 0) return n;
        }
      }
      return 0;
    };
    // Check known Angular host elements first for speed
    for (const hostSel of ['bolt-autocomplete', 'bolt-autocomplete-wc', 'bolt-textfield-wc']) {
      for (const host of document.querySelectorAll(hostSel)) {
        if (host.shadowRoot) {
          const n = walkShadow(host.shadowRoot);
          if (n > 0) return n;
        }
      }
    }
    // Full document shadow walk as last resort
    return walkShadow(document.body);
  }).catch(() => 0);

  /** Wait up to `ms` for at least one option to appear in the DOM.
   *  Covers Prod (Yext) and Angular (bolt-autocomplete-wc).
   */
  const waitForOptions = (ms = 3000) => frameWaitForFn(() => {
    const isVisible = el => {
      const st = getComputedStyle(el);
      return st.display !== 'none' && st.visibility !== 'hidden';
    };
    // Light DOM (Prod / Yext)
    const lightSels = [
      '.yxt-SearchBar-autocomplete [role="option"]',
      '.yxt-SearchBar-suggestion',
      '[role="listbox"] [role="option"]',
      '[id*="listbox"] [role="option"]',
    ];
    if (lightSels.some(s => [...document.querySelectorAll(s)].some(isVisible))) return true;
    // Shadow DOM walk (Angular bolt-autocomplete)
    const shadowSels = ['li[role="option"]', '[role="option"]', 'li.bolt-autocomplete-wc--option'];
    const walkShadow = (root) => {
      for (const sel of shadowSels) {
        try { if ([...root.querySelectorAll(sel)].some(isVisible)) return true; } catch { /* skip */ }
      }
      for (const el of root.querySelectorAll('*')) {
        if (el.shadowRoot && walkShadow(el.shadowRoot)) return true;
      }
      return false;
    };
    for (const hostSel of ['bolt-autocomplete', 'bolt-autocomplete-wc', 'bolt-textfield-wc']) {
      for (const host of document.querySelectorAll(hostSel)) {
        if (host.shadowRoot && walkShadow(host.shadowRoot)) return true;
      }
    }
    return false;
  }, undefined, { timeout: ms }).catch(() => null);

  /** Wait up to `ms` for all options to disappear from the DOM.
   *  Covers Prod (Yext) and Angular (bolt-autocomplete-wc).
   */
  const waitForOptionsGone = (ms = 2000) => frameWaitForFn(() => {
    const isVisible = el => {
      const st = getComputedStyle(el);
      return st.display !== 'none' && st.visibility !== 'hidden';
    };
    // Light DOM (Prod / Yext)
    const lightSels = [
      '.yxt-SearchBar-autocomplete [role="option"]',
      '.yxt-SearchBar-suggestion',
      '[role="listbox"] [role="option"]',
      '[id*="listbox"] [role="option"]',
    ];
    if (lightSels.some(s => [...document.querySelectorAll(s)].some(isVisible))) return false;
    // Shadow DOM walk (Angular bolt-autocomplete)
    const shadowSels = ['li[role="option"]', '[role="option"]', 'li.bolt-autocomplete-wc--option'];
    const walkShadow = (root) => {
      for (const sel of shadowSels) {
        try { if ([...root.querySelectorAll(sel)].some(isVisible)) return true; } catch { /* skip */ }
      }
      for (const el of root.querySelectorAll('*')) {
        if (el.shadowRoot && walkShadow(el.shadowRoot)) return true;
      }
      return false;
    };
    for (const hostSel of ['bolt-autocomplete', 'bolt-autocomplete-wc', 'bolt-textfield-wc']) {
      for (const host of document.querySelectorAll(hostSel)) {
        if (host.shadowRoot && walkShadow(host.shadowRoot)) return false;
      }
    }
    return true; // no visible options found anywhere
  }, undefined, { timeout: ms }).catch(() => null);

  /** Locate the configured search input, fallback to generic Yext input. */
  const getInput = async () => {
    // Use inputSelectorList when available (testSearchResultsPage…), else build from inputSelector
    const list = (opts.inputSelectors || opts.context?.inputSelectors)
      ? (opts.inputSelectors || opts.context.inputSelectors)
      : [inputSelector, 'input[aria-autocomplete="list"]'];
    for (const sel of list) {
      const el = getLocatorRoot().locator(sel).first();
      if (await el.count() > 0 && await el.isVisible({ timeout: 3000 }).catch(() => false)) return el;
    }
    throw new Error(`Search input not found: tried ${list.join(', ')}`);
  };

  /** Reset: reload the target page and wait for Yext widget to init.
   *  Uses a capped 15 s goto so a slow/stale URL doesn't block the entire suite.
   *  Pass forceReload=true to navigate even if already on the correct URL
   *  (needed after viewport resize so the page re-renders at the new size).
   */
  const resetPage = async ({ forceReload = false } = {}) => {
    // Only navigate if we're not already on the right page — unless forceReload
    const alreadyThere = page.url().startsWith(pageUrl);
    if (!alreadyThere || forceReload) {
      await page.goto(pageUrl, { waitUntil: 'domcontentloaded', timeout: 15000 }).catch(async (err) => {
        console.log(`     [WARN] resetPage goto failed: ${trunc(err.message)} — retrying once`);
        await page.goto(pageUrl, { waitUntil: 'domcontentloaded', timeout: 15000 }).catch(() => {});
      });
      if (!alreadyThere) await hardRefresh(page, 'advanced-aria-reset').catch(() => {});
    }
    await dismissCookieBanner(page).catch(() => {});
    await waitForPageReady(page, { networkTimeout: 5000 }).catch(() => {});
    await frameWaitForFn(
      sel => {
        const el = document.querySelector(sel) ||
                   document.querySelector('input[aria-autocomplete="list"]');
        return el && el.getAttribute('aria-expanded') !== null;
      },
      inputSelector,
      { timeout: 8000 }
    );
  };

  // ── Helper: run one test with try/catch ─────────────────────────────────────
  const run = async (name, fn) => {
    console.log(`\n   ${name}`);
    try {
      const { status, detail } = await fn();
      console.log(`     → ${status}${detail ? `  (${detail})` : ''}`);
      results.push({ name, status, detail });
    } catch (err) {
      console.log(`     → FAILED  (${trunc(err.message)})`);
      results.push({ name, status: 'FAILED', detail: trunc(err.message) });
    }
  };

  // ══════════════════════════════════════════════════════════════════════════════
  //  GROUP 1 — OPEN / CLOSE STATES
  // ══════════════════════════════════════════════════════════════════════════════

  // ── 1a. Typing → aria-expanded = "true" ────────────────────────────────────
  await run('1a. Typing → aria-expanded="true"', async () => {
    await resetPage();
    const input = await getInput();
    await input.click();
    await clearAndType(input, SEARCH_TERMS.fileClaim, { delay: 80 });
    await waitForOptions(3000);
    const expanded = await input.getAttribute('aria-expanded');
    const optCount = await domOptionCount();
    const detail   = `aria-expanded=${expanded} | dom-options=${optCount}`;
    if (expanded === 'true') return { status: 'PASSED', detail };
    // Yext may set aria-expanded="false" on some page states — WARN, not hard FAIL
    if (optCount > 0)        return { status: 'WARN',   detail: `${detail} — suggestions visible but aria-expanded not "true"` };
    return { status: 'WARN', detail: `${detail} — aria-expanded not "true" and no suggestions visible (accessibility)` };
  });

  // ── 1b. ESC → aria-expanded = "false" ──────────────────────────────────────
  await run('1b. ESC → aria-expanded="false"', async () => {
    const input = await getInput();
    // Re-open (may already have suggestions from 1a if on same page)
    await input.click();
    if ((await domOptionCount()) === 0) {
      await clearAndType(input, SEARCH_TERMS.stem4, { delay: 80 });
      await waitForOptions(3000);
    }
    // Use page.keyboard.press instead of input.press — the SR page Global Header
    // Yext widget binds its ESC handler at document/wrapper level, not the input
    // element itself. input.press() dispatches a synthetic DOM event that does not
    // reliably bubble through that widget's event chain.  page.keyboard.press()
    // sends a real OS-level key event to the currently focused element, which
    // propagates through the full document chain and triggers the widget handler.
    await input.focus();
    await page.keyboard.press('Escape');
    await waitForOptionsGone(2000);
    // Retry once — some Yext instances need a second ESC if focus was on an option
    if ((await domOptionCount()) > 0) {
      await page.keyboard.press('Escape');
      await waitForOptionsGone(1500);
    }
    const expanded = await input.getAttribute('aria-expanded');
    const optCount = await domOptionCount();
    const detail   = `aria-expanded=${ariaLabel(expanded)} | dom-options=${optCount}`;
    // isAriaCollapsed: handles 'false' (Edge) and null/attr-removed (Chrome)
    if (isAriaCollapsed(expanded) && optCount === 0) return { status: 'PASSED', detail };
    if (optCount === 0) return { status: 'WARN', detail: `${detail} — suggestions gone but aria-expanded="${expanded}"` };
    return { status: 'WARN', detail: `${detail} — ESC did not fully dismiss suggestions (accessibility)` };
  });

  // ── 1c. Blur (click outside) → aria-expanded = "false" ─────────────────────
  await run('1c. Blur (click outside) → aria-expanded="false"', async () => {
    const input = await getInput();
    await input.click();
    await clearAndType(input, SEARCH_TERMS.premiumPayment, { delay: 80 });
    await waitForOptions(3000);
    // Click somewhere well away from the search bar
    await page.locator('body').click({ position: { x: 20, y: 20 }, force: true });
    await waitForOptionsGone(2000);
    const expanded = await input.getAttribute('aria-expanded');
    const optCount = await domOptionCount();
    const detail   = `aria-expanded=${ariaLabel(expanded)} | dom-options=${optCount}`;
    if (isAriaCollapsed(expanded) && optCount === 0) return { status: 'PASSED', detail };
    if (optCount === 0) return { status: 'WARN', detail: `${detail} — suggestions gone but aria-expanded="${expanded}"` };
    return { status: 'WARN', detail: `${detail} — blur did not fully dismiss suggestions (accessibility)` };
  });

  // ── 1d. Selection (click option) → aria-expanded = "false" ─────────────────
  await run('1d. Selection (click option) → aria-expanded="false"', async () => {
    await resetPage();
    const input = await getInput();
    await input.click();
    await clearAndType(input, SEARCH_TERMS.fileClaim, { delay: 80 });
    await waitForOptions(3000);
    // Click the first visible option
    const optionSelectors = [
      '.yxt-SearchBar-autocomplete [role="option"]',
      '.yxt-SearchBar-suggestion',
      '[role="listbox"] [role="option"]',
    ];
    let clicked = false;
    for (const sel of optionSelectors) {
      const opt = getLocatorRoot().locator(sel).first();
      if (await opt.count() > 0 && await opt.isVisible({ timeout: 1000 }).catch(() => false)) {
        await opt.click();
        clicked = true;
        break;
      }
    }
    if (!clicked) return { status: 'WARN', detail: 'No visible option to click' };

    // After clicking a suggestion the page may navigate away immediately.
    // Race: capture aria-expanded within 2 s before the page unloads; if the
    // page already navigated treat that as an implicit success (selection worked).
    let expanded = null;
    let optCount = 0;
    let navigated = false;
    const urlBefore = page.url();
    try {
      // Use a short-timeout locator re-resolve so we don't hang 30 s on a dead page
      const freshInput = getLocatorRoot().locator(inputSelector).first();
      expanded = await freshInput.getAttribute('aria-expanded', { timeout: 2000 }).catch(() => null);
      optCount = await domOptionCount();
      navigated = page.url() !== urlBefore;
    } catch {
      navigated = page.url() !== urlBefore;
    }

    // If the page navigated, the dropdown is definitively closed — PASSED
    if (navigated || (page.url() !== urlBefore)) {
      return { status: 'PASSED', detail: `Selection triggered navigation to: ${page.url()}` };
    }
    const detail = `aria-expanded=${expanded} | dom-options=${optCount}`;
    if (expanded === 'false' && optCount === 0) return { status: 'PASSED', detail };
    if (optCount === 0) return { status: 'WARN', detail: `${detail} — suggestions gone but aria-expanded="${expanded}"` };
    return { status: 'WARN', detail: `${detail} — selection did not collapse aria-expanded (accessibility)` };
  });

  // ══════════════════════════════════════════════════════════════════════════════
  //  GROUP 2 — aria-activedescendant UPDATES
  // ══════════════════════════════════════════════════════════════════════════════

  // ── 2a. ArrowDown updates aria-activedescendant ─────────────────────────────
  await run('2a. ArrowDown → aria-activedescendant changes', async () => {
    // Ensure we're back on the target page — 1d may have navigated away
    await resetPage();

    let input;
    try {
      input = await getInput();
    } catch (err) {
      return { status: 'WARN', detail: `Could not locate search input after reset: ${trunc(err.message)}` };
    }

    await input.click();
    await clearAndType(input, SEARCH_TERMS.stem4, { delay: 80 });
    const gotOptions = await waitForOptions(3000);
    if (!gotOptions) {
      return { status: 'WARN', detail: 'No suggestions appeared — cannot test aria-activedescendant' };
    }

    const before = await input.getAttribute('aria-activedescendant').catch(() => null);
    await input.press('ArrowDown');
    await page.waitForTimeout(300);
    const after1 = await input.getAttribute('aria-activedescendant').catch(() => null);
    await input.press('ArrowDown');
    await page.waitForTimeout(300);
    const after2 = await input.getAttribute('aria-activedescendant').catch(() => null);

    const detail = `before=${before || 'null'} | after1=${after1 || 'null'} | after2=${after2 || 'null'}`;
    console.log(`     ${detail}`);

    if (after1 && after2 && after1 !== after2) return { status: 'PASSED', detail };
    if (after1 || after2) return { status: 'WARN', detail: `${detail} — id set but did not advance between presses` };
    return { status: 'WARN', detail: `${detail} — Yext may manage focus inside listbox rather than via activedescendant` };
  });

  // ── 2b. ArrowUp resets / reverses aria-activedescendant ────────────────────
  await run('2b. ArrowUp → aria-activedescendant changes', async () => {
    // Guard: if 2a left page in broken state, reset first
    let input;
    try {
      input = await page.locator(inputSelector).first();
      const inputVisible = await input.isVisible({ timeout: 2000 }).catch(() => false);
      if (!inputVisible) {
        await resetPage();
        input = await getInput();
      }
    } catch {
      await resetPage();
      input = await getInput();
    }

    // Re-open suggestions if not already open
    const currentOptCount = await domOptionCount();
    if (currentOptCount === 0) {
      await input.click();
      await clearAndType(input, SEARCH_TERMS.fileClaim, { delay: 80 });
      const gotOptions = await waitForOptions(3000);
      if (!gotOptions) {
        return { status: 'WARN', detail: 'No suggestions appeared — cannot test ArrowUp navigation' };
      }
    }

    // Navigate DOWN twice to get a stable focus position, then UP once
    await input.press('ArrowDown');
    await page.waitForTimeout(300);
    await input.press('ArrowDown');
    await page.waitForTimeout(300);
    const atBottom = await input.getAttribute('aria-activedescendant').catch(() => null);

    await input.press('ArrowUp');
    await page.waitForTimeout(300);
    const afterUp = await input.getAttribute('aria-activedescendant').catch(() => null);

    const detail = `atBottom=${atBottom || 'null'} | afterUp=${afterUp || 'null'}`;
    console.log(`     ${detail}`);

    if (atBottom && afterUp && atBottom !== afterUp) return { status: 'PASSED', detail };
    if (afterUp) return { status: 'WARN', detail: `${detail} — id set but did not change on ArrowUp` };
    return { status: 'WARN', detail: `${detail} — Yext may manage focus inside listbox rather than via activedescendant` };
  });

  // ══════════════════════════════════════════════════════════════════════════════
  //  GROUP 3 — aria-controls REFERENCES VALID LISTBOX
  // ══════════════════════════════════════════════════════════════════════════════

  // ── 3a. aria-controls is present on the input ───────────────────────────────
  await run('3a. aria-controls attribute present on input', async () => {
    await resetPage();
    const input = await getInput();
    await input.click();
    await clearAndType(input, SEARCH_TERMS.coverage, { delay: 80 });
    await waitForOptions(3000);
    const listId = await input.getAttribute('aria-controls');
    const detail = `aria-controls=${listId || 'null'}`;
    if (listId) return { status: 'PASSED', detail };
    // Some Yext versions omit aria-controls — downgrade to WARN
    return { status: 'WARN', detail: `${detail} — aria-controls not present (Yext may use implicit association)` };
  });

  // ── 3b. The element referenced by aria-controls is visible ──────────────────
  await run('3b. aria-controls target is visible in DOM', async () => {
    // Always re-open suggestions so the autocomplete container is in the DOM
    const input = await getInput();
    await input.click({ force: true });
    await input.clear();
    await clearAndType(input, SEARCH_TERMS.fileClaim, { delay: 80 });
    await waitForOptions(3000);

    const listId = await input.getAttribute('aria-controls');
    if (!listId) {
      const lb = getLocatorRoot().locator('[role="listbox"]').first();
      const lbVisible = await lb.count() > 0 &&
                        await lb.isVisible({ timeout: 1000 }).catch(() => false);
      return lbVisible
        ? { status: 'WARN', detail: 'aria-controls absent but [role="listbox"] is visible' }
        : { status: 'WARN', detail: 'aria-controls absent and no visible [role="listbox"]' };
    }
    // Use attribute selector — IDs containing dots are misread as CSS classes by #id
    // Also walk bolt-autocomplete shadow roots (Angular: listbox is in shadow DOM)
    const { inDom, selfH, childH } = await frameEval(id => {
      // Light DOM check first (Yext/Prod)
      let el = document.querySelector('[id="' + id + '"]');
      // Shadow DOM check (Angular bolt-autocomplete)
      if (!el) {
        for (const host of document.querySelectorAll('bolt-autocomplete, bolt-autocomplete-wc')) {
          const found = host.shadowRoot?.querySelector('[id="' + id + '"]');
          if (found) { el = found; break; }
          // Listbox may not carry the exact ID — fall back to role=listbox in shadow
          const lb = host.shadowRoot?.querySelector('[role="listbox"]');
          if (lb) { el = lb; break; }
        }
      }
      if (!el) return { inDom: false, selfH: 0, childH: 0 };
      const lb = el.querySelector('[role="listbox"]') || el;
      return { inDom: true, selfH: el.getBoundingClientRect().height, childH: lb.getBoundingClientRect().height };
    }, listId) || { inDom: false, selfH: 0, childH: 0 };
    const detail = `#${listId} inDom=${inDom} height=${selfH} listboxHeight=${childH}`;
    if (!inDom)             return { status: 'WARN', detail: `${detail} — element absent from DOM while suggestions open (accessibility)` };
    if (selfH > 0 || childH > 0) return { status: 'PASSED', detail };
    return { status: 'WARN', detail: `${detail} — in DOM but zero dimensions` };
  });

  // ── 3c. aria-controls target has role="listbox" ─────────────────────────────
  await run('3c. aria-controls target has role="listbox"', async () => {
    // Re-open suggestions so the container is guaranteed in the DOM
    const input = await getInput();
    if ((await domOptionCount()) === 0) {
      await input.click({ force: true });
      await clearAndType(input, SEARCH_TERMS.fileClaim, { delay: 80 });
      await waitForOptions(3000);
    }
    const listId = await input.getAttribute('aria-controls');
    if (!listId) return { status: 'WARN', detail: 'aria-controls not present — cannot verify role' };

    // Use querySelector('[id="..."]') — handles IDs with dots/hyphens that
    // document.getElementById can miss in some Yext rendering contexts.
    // Also walk bolt-autocomplete shadow roots (Angular: listbox is in shadow DOM)
    const { inDom, selfRole, childRole } = await frameEval(id => {
      // Light DOM check first (Yext/Prod)
      let el = document.querySelector('[id="' + id + '"]');
      // Shadow DOM check (Angular bolt-autocomplete)
      if (!el) {
        for (const host of document.querySelectorAll('bolt-autocomplete, bolt-autocomplete-wc')) {
          const found = host.shadowRoot?.querySelector('[id="' + id + '"]');
          if (found) { el = found; break; }
          // Fallback: any listbox in shadow root
          const lb = host.shadowRoot?.querySelector('[role="listbox"]');
          if (lb) { el = lb; break; }
        }
      }
      if (!el) return { inDom: false, selfRole: null, childRole: null };
      const lb = el.querySelector('[role="listbox"]');
      return { inDom: true, selfRole: el.getAttribute('role'), childRole: lb ? lb.getAttribute('role') : null };
    }, listId) || { inDom: false, selfRole: null, childRole: null };

    if (!inDom) return { status: 'WARN', detail: `#${listId} — element absent from DOM while suggestions are open (accessibility)` };
    const detail = `#${listId} selfRole=${selfRole || 'null'} | child[role="listbox"]=${childRole ? 'found' : 'absent'}`;
    if (selfRole === 'listbox' || childRole === 'listbox') return { status: 'PASSED', detail };
    if (selfRole || childRole) return { status: 'WARN', detail: `${detail} — found role but not "listbox"` };
    // Yext may omit explicit role — downgrade to WARN not hard FAIL
    return { status: 'WARN', detail: `${detail} — no explicit role="listbox" (Yext may use implicit list semantics)` };
  });

  // ══════════════════════════════════════════════════════════════════════════════
  //  GROUP 4 — AUTOCOMPLETE OPTION COUNT (Desktop + Mobile + Tablet + ARIA attrs)
  //  4a  PASS when Yext/Bolt returns exactly 10 suggestions on Desktop
  //  4b  Same check at iPhone 12 (390 × 844) mobile viewport
  //  4c  Same check at iPad Portrait (768 × 1024) tablet viewport
  //  4d  ARIA: aria-setsize present and consistent across all options
  //  4e  ARIA: aria-posinset present and sequential (1…N) across all options
  //  Covers Prod (Yext) and Angular (bolt-autocomplete-wc) via env-aware selectors.
  // ══════════════════════════════════════════════════════════════════════════════
  const EXPECTED_COUNT = 10;
  const COUNT_TERM     = SEARCH_TERMS.countTerm; // 'ins' — insurance prefix, reliably triggers full 10-item list

  /**
   * Activate the search box on the current page:
   *  – On mobile viewports (width ≤ 767) the input is hidden behind a search
   *    icon — tap the icon first, then locate the revealed input.
   *  – On desktop / contact page / in-page bar (iframe) the input is always visible.
   */
  const activateAndType = async (term) => {
    const vp    = page.viewportSize();
    const isMob = vp && vp.width <= 767;

    // Dismiss banner + scroll to top so the input is interactable
    await dismissCookieBanner(page).catch(() => {});
    await page.evaluate(() => window.scrollTo(0, 0)).catch(() => {});
    await page.waitForTimeout(300);

    // SR Page in-page bar (iframe) and Contact Page search bars are visible
    // immediately on page load — no hamburger or search icon tap needed on any
    // device.  Only the Global Header Search needs the icon tap on mobile.
    if (isMob && !frameSelector) {
      // Tap the search icon to reveal the Global Header input
      for (const sel of resolveSelectors(page).searchIcon) {
        try {
          const icon = page.locator(sel).first();
          if (await icon.count() > 0 &&
              await icon.isVisible({ timeout: 1000 }).catch(() => false)) {
            await icon.click();
            await page.waitForTimeout(500);
            break;
          }
        } catch { /* try next */ }
      }
    }

    const input = await getInput();
    await input.scrollIntoViewIfNeeded();
    // force:true bypasses Playwright viewport check for sticky-header edge cases
    await input.click({ force: true });
    await clearAndType(input, term, { delay: 80 });
    await waitForOptions(4000);
    return input;
  };

  // ── 4a. Option count — Desktop viewport ─────────────────────────────────────
  await run(`4a. Option count — Desktop (expect ${EXPECTED_COUNT})`, async () => {
    await resetPage();                                // desktop viewport set by resetPage
    await activateAndType(COUNT_TERM);
    const count  = await domOptionCount();
    const detail = `term="${COUNT_TERM}" | dom-options=${count} | expected=${EXPECTED_COUNT}`;
    if (count === EXPECTED_COUNT)  return { status: 'PASSED', detail };
    if (count  >  0)               return { status: 'WARN',   detail: `${detail} — got ${count}, expected ${EXPECTED_COUNT}` };
    return { status: 'FAILED', detail: `${detail} — no suggestions found` };
  });

  // ── Shared helper: open search on small viewports ───────────────────────────
  // On mobile/tablet, the search input may be hidden behind a search icon.
  // Strategy (in priority order):
  //   1. findAndActivateSearch() — already Angular-aware (shadow DOM + icon click)
  //   2. Explicit icon selectors from resolveSelectors(page).searchIcon
  //   3. Shadow DOM walk: check bolt-autocomplete.shadowRoot for the input directly
  // Returns { input, iconClicked, method } or null if all strategies fail.
  async function openSearchOnSmallViewport(vpLabel) {
    const SEL = resolveSelectors(page);
    const isContactAriaFlow =
      (typeof inputSelector === 'string' && inputSelector.includes('help-search-bar')) ||
      (typeof pageUrl === 'string' && pageUrl.includes('/contact'));
    // SR Page in-page bar (inside #answers-frame) and Contact Page search bars
    // are visible immediately once the page loads — no hamburger or icon needed.
    const isInPageBarFlow = !!frameSelector;
    const flow = isInPageBarFlow ? 'in-page-bar' : (isContactAriaFlow ? 'contact' : 'global-header');

    // Step 0 (manual parity): for Global Header ARIA flow, open hamburger first when present.
    // Contact ARIA flow and in-page bar flow access the search field directly — no hamburger.
    let hamburgerOpened = false;
    if (!isContactAriaFlow && !isInPageBarFlow && Array.isArray(SEL.hamburger) && SEL.hamburger.length > 0) {
      for (const hSel of SEL.hamburger) {
        try {
          const hb = page.locator(hSel).first();
          if (await hb.count() > 0 && await hb.isVisible({ timeout: 900 }).catch(() => false)) {
            await hb.click({ force: true }).catch(() => {});
            await page.waitForTimeout(450);
            hamburgerOpened = true;
            console.log(`   [${vpLabel}] Hamburger opened via "${hSel}"`);
            break;
          }
        } catch { /* try next */ }
      }
      if (!hamburgerOpened) {
        console.log(`   [${vpLabel}] Hamburger not available; fallback to direct input (hamburgerOpened=false)`);
      }
    } else if (isInPageBarFlow) {
      console.log(`   [${vpLabel}] In-page bar flow: skipping hamburger pre-step — bar is visible on page load`);
    } else if (isContactAriaFlow) {
      console.log(`   [${vpLabel}] Contact ARIA flow: skipping hamburger pre-step (hamburgerOpened=false)`);
    }

    // Step 0.5: prefer the suite-configured inputSelector first.
    // For in-page bar flow resolve using the frameLocator so the input is found
    // inside the iframe, not on the main page.
    try {
      if (inputSelector) {
        const preferred = getLocatorRoot().locator(inputSelector).first();
        if (await preferred.count() > 0) {
          const visible = await preferred.isVisible({ timeout: 1200 }).catch(() => false);
          if (visible) {
            console.log(`   [${vpLabel}] Input found via configured selector "${inputSelector}"`);
            return {
              input: preferred,
              iconClicked: hamburgerOpened,
              method: `configured:${inputSelector}`,
              hamburgerOpened,
              flow,
              fallbackPathUsed: !isContactAriaFlow && !hamburgerOpened,
            };
          }
        }
      }
    } catch { /* continue */ }

    // Contact / in-page bar requirement: do not use alternate strategies when
    // the configured input is unavailable — those bars must be in the page.
    if (isContactAriaFlow || isInPageBarFlow) {
      throw new Error(`Required ${isInPageBarFlow ? 'in-page bar' : 'contact'} input not visible: ${inputSelector}`);
    }

    // ── Strategy 1: findAndActivateSearch (handles Angular + Prod) ─────────────
    try {
      const activated = await findAndActivateSearch(page, true);  // isMobile=true
      if (activated) {
        console.log(`   [${vpLabel}] Input found via findAndActivateSearch`);
        return {
          input: activated,
          iconClicked: true,
          method: 'findAndActivateSearch',
          hamburgerOpened,
          flow,
          fallbackPathUsed: !isContactAriaFlow && !hamburgerOpened,
        };
      }
    } catch (e) {
      console.log(`   [${vpLabel}] findAndActivateSearch threw: ${trunc(e.message)}`);
    }

    // ── Strategy 2: click icon from selectors, then find input ─────────────────
    let iconClicked = false;
    for (const sel of SEL.searchIcon) {
      try {
        const icon = page.locator(sel).first();
        if (await icon.count() > 0 &&
            await icon.isVisible({ timeout: 1000 }).catch(() => false)) {
          await icon.click({ force: true });
          await page.waitForTimeout(700);
          iconClicked = true;
          console.log(`   [${vpLabel}] Icon clicked via "${sel}"`);
          break;
        }
      } catch { /* try next selector */ }
    }

    // After icon click (or without), find any visible input
    const inputCandidates = [
      ...SEL.searchInput,                         // runtime-resolved (Angular or Prod)
      'input[aria-autocomplete="list"]',
      'input[aria-label="Search"]',
      'input[placeholder*="Search" i]',
      'input[name="query"]',
    ];
    for (const sel of inputCandidates) {
      try {
        const el = page.locator(sel).first();
        if (await el.count() > 0 &&
            await el.isVisible({ timeout: 1500 }).catch(() => false)) {
          console.log(`   [${vpLabel}] Input found via "${sel}"`);
          return {
            input: el,
            iconClicked,
            method: `selector:${sel}`,
            hamburgerOpened,
            flow,
            fallbackPathUsed: !isContactAriaFlow && !hamburgerOpened,
          };
        }
      } catch { /* next */ }
    }

    // ── Strategy 3: Shadow DOM walk — Angular bolt-autocomplete ────────────────
    // The input is inside bolt-autocomplete.shadowRoot even if CSS visibility
    // reports hidden. Force-click the host, then access the inner input.
    try {
      const hostSels = ['#search > bolt-autocomplete', 'bolt-autocomplete', 'bolt-autocomplete-wc'];
      for (const hs of hostSels) {
        const host = page.locator(hs).first();
        if (await host.count() > 0) {
          await host.click({ force: true }).catch(() => {});
          await page.waitForTimeout(500);
          // Now try shadow-pierce selectors
          for (const sel of ['bolt-autocomplete >> input[data-test="input"]']) {
            try {
              const el = page.locator(sel).first();
              if (await el.count() > 0) {
                console.log(`   [${vpLabel}] Input found via shadow DOM walk "${sel}"`);
                return {
                  input: el,
                  iconClicked: true,
                  method: `shadow:${sel}`,
                  hamburgerOpened,
                  flow,
                  fallbackPathUsed: !isContactAriaFlow && !hamburgerOpened,
                };
              }
            } catch { /* next */ }
          }
        }
      }
    } catch { /* shadow walk failed */ }

    console.warn(`   [${vpLabel}] ⚠ Search input and icon both not found — cannot run option count`);
    return null;
  }

  // Type in the activated input using the same interaction pattern as manual flow:
  // click the revealed "Enter a search term" field first, then type.
  async function typeIntoActivatedInput(input, term, vpLabel) {
    let typed = false;
    let method = 'playwright-click-type';
    try {
      await input.scrollIntoViewIfNeeded({ timeout: 1500 }).catch(() => {});
      await input.click({ force: true }).catch(() => {});
      await page.waitForTimeout(250);
      // second click helps on mobile where first click only expands/focuses shell
      await input.click({ force: true }).catch(() => {});
      await page.waitForTimeout(200);

      await input.clear().catch(async () => {
        await input.press('Control+A').catch(() => {});
        await input.press('Backspace').catch(() => {});
      });
      await input.pressSequentially(term, { delay: 95 }).catch(async () => {
        await input.fill(term);
      });
      typed = true;
    } catch {
      // JS fallback only if locator interaction fails
      method = 'js-fallback-type';
      // JS fallback: use frameEval so the script runs inside the iframe when
      // frameSelector is set (SR page in-page bar).  Falls back to page context
      // for Global Header / Contact flows.
      typed = await frameEval((typedTerm) => {
        let inp = null;
        for (const host of document.querySelectorAll('bolt-autocomplete, bolt-autocomplete-wc, bolt-textfield-wc')) {
          inp = host.shadowRoot?.querySelector('input[data-test="input"]') || host.shadowRoot?.querySelector('input');
          if (inp) break;
        }
        if (!inp) inp = document.querySelector('#yxt-SearchBar-input--search-bar-1, input[aria-autocomplete="list"]');
        if (!inp) return false;
        inp.focus(); inp.click();
        inp.value = '';
        inp.dispatchEvent(new Event('input', { bubbles: true }));
        for (const ch of typedTerm) {
          inp.value += ch;
          inp.dispatchEvent(new KeyboardEvent('keydown', { key: ch, bubbles: true }));
          inp.dispatchEvent(new Event('input', { bubbles: true }));
          inp.dispatchEvent(new KeyboardEvent('keyup', { key: ch, bubbles: true }));
        }
        return true;
      }, term).catch(() => false);
    }

    // If options still missing, retry once with explicit click-then-type sequence.
    await waitForOptions(3500);
    if ((await domOptionCount()) === 0) {
      method += '|retry-click-type';
      console.log(`   [${vpLabel}] No options after first type — retrying click + type`);
      await input.click({ force: true }).catch(() => {});
      await page.waitForTimeout(250);
      await input.press('Control+A').catch(() => {});
      await input.press('Backspace').catch(() => {});
      await input.pressSequentially(term, { delay: 110 }).catch(() => {});
      await waitForOptions(4000);
    }

    return { typed, method };
  }

  // ── In-page bar: resolve input inside #answers-frame at any viewport ─────────
  // For SR Page in-page bar, the #answers-frame iframe contains the search
  // input, visible at ALL viewport sizes without hamburger or icon tap.
  // After a viewport resize, the page must be reloaded so the iframe renders
  // fresh at the new dimensions before we try to find the input.
  const resolveInPageBarInput = async (vpLabel) => {
    // Force a fresh navigation at the current viewport (iframe re-renders)
    await page.goto(pageUrl, { waitUntil: 'domcontentloaded', timeout: 20000 }).catch(() => {});
    await dismissCookieBanner(page).catch(() => {});
    await waitForPageReady(page, { networkTimeout: 5000 }).catch(() => {});
    await page.waitForTimeout(2000); // allow Yext iframe to boot

    // Ensure the iframe is in the DOM before trying to access it
    const frameEl = await page.waitForSelector(frameSelector, { timeout: 8000 }).catch(() => null);
    if (!frameEl) {
      console.log(`   [${vpLabel}] #answers-frame not found after reload at ${vpLabel}`);
      return null;
    }

    // Scroll the iframe host into view so Playwright can interact with contents
    await frameEl.scrollIntoViewIfNeeded().catch(() => {});
    await page.waitForTimeout(500);

    const root = getLocatorRoot(); // frameLocator
    const inputSelList = [
      inputSelector,
      '#yxt-SearchBar-input--search-bar-1',
      'input.js-yext-query',
      'input[aria-autocomplete="list"]',
      'input[type="search"]',
    ];
    for (const sel of inputSelList) {
      try {
        const el = root.locator(sel).first();
        if (await el.count() > 0 && await el.isVisible({ timeout: 3000 }).catch(() => false)) {
          console.log(`   [${vpLabel}] In-page bar input found via "${sel}"`);
          return el;
        }
      } catch { /* next */ }
    }
    console.log(`   [${vpLabel}] In-page bar input not visible at this viewport`);
    return null;
  };

  // ── 4b. Option count — Mobile viewport (390 × 844 — iPhone 12) ────────────────
  await run(`4b. Option count — Mobile 390×844 (expect ${EXPECTED_COUNT})`, async () => {
    await page.setViewportSize({ width: 390, height: 844 });
    try {
      // In-page bar (iframe): visible at all viewports — no hamburger/icon needed.
      // Fresh goto required after viewport resize so iframe re-renders.
      if (frameSelector) {
        const input = await resolveInPageBarInput('390px');
        if (!input) {
          return { status: 'WARN', detail: 'viewport=390×844 | in-page bar input not visible inside #answers-frame at mobile viewport' };
        }
        const typedResult = await typeIntoActivatedInput(input, COUNT_TERM, '390px');
        const count  = await domOptionCount();
        const detail = `viewport=390×844 | flow=in-page-bar | method=iframe-direct|${typedResult.method} | typed=${typedResult.typed} | term="${COUNT_TERM}" | dom-options=${count} | expected=${EXPECTED_COUNT}`;
        if (count === EXPECTED_COUNT)  return { status: 'PASSED', detail };
        if (count  >  0)               return { status: 'WARN',   detail: `${detail} — got ${count}, expected ${EXPECTED_COUNT}` };
        return { status: 'WARN', detail: `${detail} — no suggestions (in-page bar may not support autocomplete at 390px)` };
      }

      // Global Header / Contact: use hamburger+icon strategy as before
      await resetPage();
      await page.evaluate(() => window.scrollTo(0, 0)).catch(() => {});
      await page.waitForTimeout(400);

      const found = await openSearchOnSmallViewport('390px');
      if (!found) {
        return { status: 'WARN', detail: 'viewport=390×844 | hamburgerOpened=false | iconClicked=false — search input and icon not found after all strategies' };
      }

      const { input, iconClicked, method, hamburgerOpened, flow, fallbackPathUsed } = found;
      const typedResult = await typeIntoActivatedInput(input, COUNT_TERM, '390px');
      const count  = await domOptionCount();
      const fallbackDetail = flow === 'global-header'
        ? ` | fallbackPath=${fallbackPathUsed ? 'direct-input(hamburger-missing)' : 'none'}`
        : '';
      const detail = `viewport=390×844 | hamburgerOpened=${hamburgerOpened} | iconClicked=${iconClicked}${fallbackDetail} | method=${method}|${typedResult.method} | typed=${typedResult.typed} | term="${COUNT_TERM}" | dom-options=${count} | expected=${EXPECTED_COUNT}`;
      if (count === EXPECTED_COUNT)  return { status: 'PASSED', detail };
      if (count  >  0)               return { status: 'WARN',   detail: `${detail} — got ${count}, expected ${EXPECTED_COUNT}` };
      return { status: 'FAILED', detail: `${detail} — no suggestions found` };
    } finally {
      await page.setViewportSize({ width: 1280, height: 800 }).catch(() => {});
    }
  });

  // ── 4c. Option count — Tablet viewport (768 × 1024 — iPad Portrait) ──────────
  await run(`4c. Option count — Tablet 768×1024 (expect ${EXPECTED_COUNT})`, async () => {
    await page.setViewportSize({ width: 768, height: 1024 }).catch(() => {});
    try {
      // In-page bar (iframe): visible at all viewports — no hamburger/icon needed.
      // Fresh goto required after viewport resize so iframe re-renders.
      if (frameSelector) {
        const input = await resolveInPageBarInput('768px');
        if (!input) {
          return { status: 'WARN', detail: 'viewport=768×1024 | in-page bar input not visible inside #answers-frame at tablet viewport' };
        }
        const typedResult = await typeIntoActivatedInput(input, COUNT_TERM, '768px');
        const count  = await domOptionCount();
        const detail = `viewport=768×1024 | flow=in-page-bar | method=iframe-direct|${typedResult.method} | typed=${typedResult.typed} | term="${COUNT_TERM}" | dom-options=${count} | expected=${EXPECTED_COUNT}`;
        if (count === EXPECTED_COUNT)  return { status: 'PASSED', detail };
        if (count  >  0)               return { status: 'WARN',   detail: `${detail} — got ${count}, expected ${EXPECTED_COUNT}` };
        return { status: 'WARN', detail: `${detail} — no suggestions (in-page bar may not support autocomplete at 768px)` };
      }

      // Global Header / Contact: use hamburger+icon strategy as before
      await resetPage();
      await page.evaluate(() => window.scrollTo(0, 0)).catch(() => {});
      await page.waitForTimeout(400);

      const found = await openSearchOnSmallViewport('768px');
      if (!found) {
        return { status: 'WARN', detail: 'viewport=768×1024 | hamburgerOpened=false | iconTapped=false — search input and icon not found after all strategies' };
      }

      const { input, iconClicked: iconTapped, method, hamburgerOpened, flow, fallbackPathUsed } = found;
      const typedResult = await typeIntoActivatedInput(input, COUNT_TERM, '768px');
      const count  = await domOptionCount();
      const fallbackDetail = flow === 'global-header'
        ? ` | fallbackPath=${fallbackPathUsed ? 'direct-input(hamburger-missing)' : 'none'}`
        : '';
      const detail = `viewport=768×1024 | hamburgerOpened=${hamburgerOpened} | iconTapped=${iconTapped}${fallbackDetail} | method=${method}|${typedResult.method} | typed=${typedResult.typed} | term="${COUNT_TERM}" | dom-options=${count} | expected=${EXPECTED_COUNT}`;
      if (count === EXPECTED_COUNT)  return { status: 'PASSED', detail };
      if (count  >  0)               return { status: 'WARN',   detail: `${detail} — got ${count}, expected ${EXPECTED_COUNT}` };
      return { status: 'WARN', detail: `${detail} — no suggestions found (tablet viewport rendering)` };
    } finally {
      await page.setViewportSize({ width: 1280, height: 800 }).catch(() => {});
    }
  });

  // ── 4d. aria-setsize on each [role="option"] ─────────────────────────────────
  // WCAG 2.1 / ARIA 1.1: each option SHOULD carry aria-setsize reflecting
  // total count, so screen readers announce "item N of M".
  await run('4d. aria-setsize on suggestion options', async () => {
    // Guard: if 4c crashed the browser, the page context is dead—skip gracefully
    // Guard: if 4c crashed the browser, skip gracefully
    const _deadErr4d = (e) => String(e && e.message).includes('Target page') || String(e && e.message).includes('browser has been closed');
    await page.setViewportSize({ width: 1280, height: 800 }).catch(() => {});
    try { await resetPage(); } catch(e) { if (_deadErr4d(e)) return { status: 'WARN', detail: '4c crashed the browser context — 4d skipped (page unavailable)' }; throw e; }
    await activateAndType(COUNT_TERM);
    const result = await frameEval(() => {
      const isVisible = (el) => {
        const st = getComputedStyle(el);
        return st.display !== 'none' && st.visibility !== 'hidden';
      };

      const collectDeep = (root, selector, out = []) => {
        out.push(...root.querySelectorAll(selector));
        for (const el of root.querySelectorAll('*')) {
          if (el.shadowRoot) collectDeep(el.shadowRoot, selector, out);
        }
        return out;
      };

      const sels = [
        '.yxt-SearchBar-autocomplete [role="option"]',
        '.yxt-SearchBar-suggestion',
        '[role="listbox"] [role="option"]',
        '[id*="listbox"] [role="option"]',
        'bolt-autocomplete-wc [role="option"]',
        'li.bolt-autocomplete-wc--option',
      ];
      let options = [];
      for (const s of sels) {
        const els = collectDeep(document, s).filter(isVisible);
        if (els.length) { options = els; break; }
      }
      if (!options.length) return { found: 0, withSetsize: 0, uniqueValues: [] };
      const values      = options.map(el => el.getAttribute('aria-setsize'));
      const withSetsize = values.filter(v => v !== null && v !== '').length;
      return { found: options.length, withSetsize, uniqueValues: [...new Set(values)] };
    }).catch(() => ({ found: 0, withSetsize: 0, uniqueValues: [] }));

    const detail = `options=${result.found} | withAriaSetsize=${result.withSetsize} | uniqueValues=${JSON.stringify(result.uniqueValues)}`;
    console.log(`     ${detail}`);
    if (result.found === 0)                        return { status: 'SKIPPED', detail: 'No options visible' };
    if (result.withSetsize === result.found)       return { status: 'PASSED',  detail };
    if (result.withSetsize > 0)                    return { status: 'WARN',    detail: `Only ${result.withSetsize}/${result.found} options have aria-setsize` };
    return { status: 'WARN', detail: `${detail} — aria-setsize absent (screen readers may not announce count)` };
  });

  // ── 4e. aria-posinset on each [role="option"] ────────────────────────────────
  // ARIA 1.1: aria-posinset should be 1…N, incrementing per option.
  await run('4e. aria-posinset on suggestion options', async () => {
    // Guard: if 4c/4d crashed the browser, skip gracefully
    const _deadErr4e = (e) => String(e && e.message).includes('Target page') || String(e && e.message).includes('browser has been closed');
    // Reuse options already in DOM from 4d; re-activate if they disappeared
    let count = 0;
    try { count = await domOptionCount(); } catch(e) { if (_deadErr4e(e)) return { status: 'WARN', detail: '4c crashed the browser context — 4e skipped (page unavailable)' }; throw e; }
    if (count === 0) {
      try { await resetPage(); await activateAndType(COUNT_TERM); } catch(e) { if (_deadErr4e(e)) return { status: 'WARN', detail: '4c crashed the browser context — 4e skipped (page unavailable)' }; throw e; }
    }

    const result = await frameEval(() => {
      const isVisible = (el) => {
        const st = getComputedStyle(el);
        return st.display !== 'none' && st.visibility !== 'hidden';
      };
      const collectDeep = (root, selector, out = []) => {
        out.push(...root.querySelectorAll(selector));
        for (const el of root.querySelectorAll('*')) {
          if (el.shadowRoot) collectDeep(el.shadowRoot, selector, out);
        }
        return out;
      };
      const sels = [
        '.yxt-SearchBar-autocomplete [role="option"]',
        '.yxt-SearchBar-suggestion',
        '[role="listbox"] [role="option"]',
        '[id*="listbox"] [role="option"]',
        'bolt-autocomplete-wc [role="option"]',
        'li.bolt-autocomplete-wc--option',
      ];
      let options = [];
      for (const s of sels) {
        const els = collectDeep(document, s).filter(isVisible);
        if (els.length) { options = els; break; }
      }
      if (!options.length) return { found: 0, withPosinset: 0, sequential: false, values: [] };
      const values       = options.map(el => el.getAttribute('aria-posinset'));
      const withPosinset = values.filter(v => v !== null && v !== '').length;
      const nums         = values.map(v => parseInt(v, 10));
      const sequential   = withPosinset === options.length &&
                           nums.every((n, i) => n === i + 1);
      return { found: options.length, withPosinset, sequential, values };
    }).catch(() => ({ found: 0, withPosinset: 0, sequential: false, values: [] }));

    const detail = `options=${result.found} | withAriaPosinset=${result.withPosinset} | sequential=${result.sequential} | values=${JSON.stringify(result.values)}`;
    console.log(`     ${detail}`);
    if (result.found === 0)                              return { status: 'SKIPPED', detail: 'No options visible' };
    if (result.sequential)                               return { status: 'PASSED',  detail };
    if (result.withPosinset > 0 && !result.sequential)   return { status: 'WARN',    detail: `${detail} — present but not sequential` };
    return { status: 'WARN', detail: `${detail} — aria-posinset absent (screen readers may not announce position)` };
  });

  // ── Summary ──────────────────────────────────────────────────────────────────
  const passed = results.filter(r => r.status === 'PASSED').length;
  const warned  = results.filter(r => r.status === 'WARN').length;
  console.log(`\n   ARIA State [${pageLabel}]: ${passed} passed | ${warned} warn | ${results.length - passed - warned} failed  (of ${results.length})`);
  return results;
}

// ══════════════════════════════════════════════════════════════════════════════
//  SR PAGE CLEAR BUTTON VALIDATION
//  Validates the Yext in-page search bar clear button inside #answers-frame.
//
//  Spec:
//  • Clear button selector: #js-answersSearchBar > div > div > form >
//      button.js-yxt-SearchBar-clear.yxt-SearchBar-clear
//  • Button NOT visible on initial page load (no query, empty SR page).
//  • Button VISIBLE once a search term is present and results are displayed.
//  • Clicking the button clears the input field.
// ══════════════════════════════════════════════════════════════════════════════
export async function testSrPageClearButton(page, opts = {}) {
  const platform  = opts.platform  || 'Desktop';
  const srBaseUrl = opts.srBaseUrl  || `${config.homeUrl.replace(/\/$/, '')}${config.searchResultsBaseUrl || '/searchresults/personal/result?=&referrerPageUrl=&query='}`;

  const CLEAR_BTN = '#js-answersSearchBar > div > div > form > button.js-yxt-SearchBar-clear.yxt-SearchBar-clear';
  const FRAME_SEL = '#answers-frame';
  const INPUT_SELS = [
    '#yxt-SearchBar-input--search-bar-1',
    'input.js-yext-query',
    'input[aria-autocomplete="list"]',
    'input[type="search"]',
  ];

  console.log('\n' + '='.repeat(60));
  console.log(` SR PAGE CLEAR BUTTON — ${platform}`);
  console.log('='.repeat(60));

  const results = [];
  const frameRoot = page.frameLocator(FRAME_SEL);

  /** Resolve the live Frame object for evaluate() inside the iframe. */
  const getFrame = async () => {
    const el = await page.waitForSelector(FRAME_SEL, { timeout: 10000 }).catch(() => null);
    return el ? el.contentFrame().catch(() => null) : null;
  };

  /** Resolve the in-page search input inside the iframe. */
  const getInput = async () => {
    for (const sel of INPUT_SELS) {
      try {
        const el = frameRoot.locator(sel).first();
        if (await el.count() > 0 && await el.isVisible({ timeout: 2000 }).catch(() => false)) return el;
      } catch { /* next */ }
    }
    return null;
  };

  /** Clear button locator inside the iframe. */
  const getClearBtn = () => frameRoot.locator(CLEAR_BTN).first();

  const run = async (name, fn) => {
    console.log(`\n   ${name}`);
    try {
      const { status, detail } = await fn();
      console.log(`     → ${status}${detail ? `  (${detail})` : ''}`);
      results.push({ name, status, detail });
    } catch (err) {
      console.log(`     → FAILED  (${trunc(err.message)})`);
      results.push({ name, status: 'FAILED', detail: trunc(err.message) });
    }
  };

  // ── Test 1: Frame is available on the SR page ──────────────────────────────
  await run('1. #answers-frame iframe exists on SR page', async () => {
    await page.goto(srBaseUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await dismissCookieBanner(page).catch(() => {});
    await waitForPageReady(page).catch(() => {});
    await page.waitForTimeout(2000);
    const frame = await getFrame();
    if (!frame) return { status: 'WARN', detail: '#answers-frame not found — in-page bar unavailable' };
    return { status: 'PASSED', detail: '#answers-frame present and accessible' };
  });

  // ── Test 2: Clear button NOT visible on initial SR page load (no query) ────
  await run('2. Clear button hidden on initial page load (no query)', async () => {
    // SR page with empty query — results not loaded
    const emptyUrl = srBaseUrl.replace(/[?&]query=[^&]*/g, match => match.replace(/=.*/, '='));
    await page.goto(emptyUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await dismissCookieBanner(page).catch(() => {});
    await waitForPageReady(page).catch(() => {});
    await page.waitForTimeout(2000);
    const clearBtn = getClearBtn();
    const btnCount = await clearBtn.count().catch(() => 0);
    if (btnCount === 0) return { status: 'PASSED', detail: 'Clear button not in DOM on empty SR page' };
    const isVisible = await clearBtn.isVisible({ timeout: 1000 }).catch(() => false);
    if (!isVisible) return { status: 'PASSED', detail: 'Clear button present in DOM but not visible on empty SR page' };
    return { status: 'WARN', detail: 'Clear button is visible on initial page load (expected hidden)' };
  });

  // ── Test 3: Clear button VISIBLE when SR page loaded with a query ───────────
  await run('3. Clear button visible when results are displayed', async () => {
    const searchTerm = encodeURIComponent(SEARCH_TERMS.fileClaim || 'insurance');
    const url = srBaseUrl.includes('query=')
      ? srBaseUrl.replace(/query=[^&]*/, `query=${searchTerm}`)
      : `${srBaseUrl}${srBaseUrl.includes('?') ? '&' : '?'}query=${searchTerm}`;
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await dismissCookieBanner(page).catch(() => {});
    await waitForPageReady(page).catch(() => {});
    await page.waitForTimeout(2500);
    const clearBtn = getClearBtn();
    const isVisible = await clearBtn.isVisible({ timeout: 4000 }).catch(() => false);
    if (isVisible) return { status: 'PASSED', detail: `Clear button visible on results page (query=${decodeURIComponent(searchTerm)})` };
    const btnCount = await clearBtn.count().catch(() => 0);
    return { status: 'WARN', detail: `Clear button ${btnCount > 0 ? 'in DOM but not visible' : 'not found in DOM'} with term "${decodeURIComponent(searchTerm)}"` };
  });

  // ── Test 4: Typing in the in-page bar makes clear button appear ─────────────
  await run('4. Clear button appears after typing in the in-page search bar', async () => {
    await page.goto(srBaseUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await dismissCookieBanner(page).catch(() => {});
    await waitForPageReady(page).catch(() => {});
    await page.waitForTimeout(2000);
    const input = await getInput();
    if (!input) return { status: 'WARN', detail: 'In-page search input not found inside #answers-frame' };
    await input.click().catch(() => {});
    await input.pressSequentially(SEARCH_TERMS.fileClaim || 'insurance', { delay: 80 }).catch(() => {});
    await page.waitForTimeout(800);
    const clearBtn = getClearBtn();
    const isVisible = await clearBtn.isVisible({ timeout: 3000 }).catch(() => false);
    if (isVisible) return { status: 'PASSED', detail: 'Clear button appeared after typing' };
    return { status: 'WARN', detail: 'Clear button not visible after typing (Yext may show it only after navigation to results)' };
  });

  // ── Test 5: Clicking the clear button clears the input field ────────────────
  await run('5. Clicking Clear button empties the input field', async () => {
    // Navigate to SR page with a filled query so the clear button is guaranteed visible
    const searchTerm = encodeURIComponent(SEARCH_TERMS.fileClaim || 'insurance');
    const url = srBaseUrl.includes('query=')
      ? srBaseUrl.replace(/query=[^&]*/, `query=${searchTerm}`)
      : `${srBaseUrl}${srBaseUrl.includes('?') ? '&' : '?'}query=${searchTerm}`;
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await dismissCookieBanner(page).catch(() => {});
    await waitForPageReady(page).catch(() => {});
    await page.waitForTimeout(2500);

    const clearBtn = getClearBtn();
    const btnVisible = await clearBtn.isVisible({ timeout: 4000 }).catch(() => false);
    if (!btnVisible) return { status: 'WARN', detail: 'Clear button not visible — cannot test click behaviour (results may not have loaded)' };

    await clearBtn.click().catch(() => {});
    await page.waitForTimeout(500);

    // Verify input is now empty
    const frame = await getFrame();
    if (!frame) return { status: 'WARN', detail: 'Frame unavailable after clear click' };
    const inputValue = await frame.evaluate(sels => {
      for (const sel of sels) {
        const el = document.querySelector(sel);
        if (el) return el.value;
      }
      return null;
    }, INPUT_SELS).catch(() => null);

    if (inputValue === '') return { status: 'PASSED', detail: 'Input cleared after clicking Clear button' };
    if (inputValue === null) return { status: 'WARN', detail: 'Could not read input value after click — input may have been removed from DOM' };
    return { status: 'WARN', detail: `Input value after clear: "${inputValue}" (expected empty string)` };
  });

  // ── Test 6: Clear button hidden again after input is cleared ────────────────
  await run('6. Clear button hidden again after input is cleared', async () => {
    // Reuse page state from Test 5 — input should already be empty
    await page.waitForTimeout(300);
    const clearBtn = getClearBtn();
    const btnCount = await clearBtn.count().catch(() => 0);
    if (btnCount === 0) return { status: 'PASSED', detail: 'Clear button removed from DOM after clearing input' };
    const isVisible = await clearBtn.isVisible({ timeout: 1500 }).catch(() => false);
    if (!isVisible) return { status: 'PASSED', detail: 'Clear button present in DOM but hidden after clearing input' };
    return { status: 'WARN', detail: 'Clear button still visible after input was cleared' };
  });

  const passed = results.filter(r => r.status === 'PASSED').length;
  const warned  = results.filter(r => r.status === 'WARN').length;
  console.log(`\n   SR Page Clear Button [${platform}]: ${passed} passed | ${warned} warn | ${results.length - passed - warned} failed  (of ${results.length})`);
  return results;
}