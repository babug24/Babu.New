/**
 * tests/content.js
 * Search results content validation test suite.
 */

import { config, trunc, SEARCH_TERMS } from '../core/config.js';
import { captureFailureScreenshot } from '../core/retry.js';
import { waitForPageReady, findAndActivateSearch, dismissCookieBanner } from '../utils/helpers.js';
import { validateSuggestionRelevance, validateSearchResultsContent } from '../utils/autocomplete.js';

export async function testSearchResultsContent(page) {
  console.log('\n' + '='.repeat(60));
  console.log(' SEARCH RESULTS CONTENT VALIDATION');
  console.log('='.repeat(60));

  const searchTerms = SEARCH_TERMS.contentTerms;
  const results = [];

  for (const { term } of searchTerms) {
    console.log(`\n   Searching: "${term}"`);
    try {
      // ── Navigate to home and wait for Yext to fully initialise ─────────────
      await page.goto(config.homeUrl, { waitUntil: 'domcontentloaded', timeout: 40000 });
      await dismissCookieBanner(page).catch(() => {});
      await page.evaluate(() => window.scrollTo(0, 0)).catch(() => {});
      await waitForPageReady(page, { networkTimeout: 5000, finalBuffer: 300 });

      // Wait until the Yext input is present, enabled, and not covered
      await page.waitForFunction(() => {
        const el = document.querySelector('#yxt-SearchBar-input--search-bar-1') ||
                   document.querySelector('input[aria-autocomplete="list"]');
        return el && !el.disabled && el.getAttribute('aria-expanded') !== null;
      }, { timeout: 10000 }).catch(() => {});

      // Dismiss banner again in case it reappeared after JS load
      await dismissCookieBanner(page).catch(() => {});
      await page.evaluate(() => window.scrollTo(0, 0)).catch(() => {});
      await page.waitForTimeout(300);

      // ── Locate + interact with search box ──────────────────────────────────
      const searchBox = await findAndActivateSearch(page, false);
      await searchBox.scrollIntoViewIfNeeded();
      await searchBox.click({ force: true, timeout: 15000 });
      await searchBox.clear();
      // Use pressSequentially so Yext keystroke listeners fire
      await searchBox.pressSequentially(term, { delay: 60 });
      await page.waitForTimeout(800);

      const relevance = await validateSuggestionRelevance(page, term);

      await page.keyboard.press('Enter');
      await waitForPageReady(page, { finalBuffer: 500 });

      const content = await validateSearchResultsContent(page, term);
      console.log(`   Result: ${content.status}${content.failReason ? ' - ' + content.failReason : ''}`);

      const detail = [
        content.failReason,
        content.isSearchPage && content.resultsCountText ? `count:"${content.resultsCountText.substring(0, 50)}"` : null,
        content.parsedTotal > 0 ? `total=${content.parsedTotal}` : null,
        content.resultCount > 0 ? `cards=${content.resultCount}` : null,
        content.pageTitle ? `title:"${content.pageTitle.substring(0, 50)}"` : null,
      ].filter(Boolean).join(' | ');
      results.push({ name: term, searchTerm: term, suggestion: relevance, content, status: content.status, detail });
    } catch (err) {
      const shot = await captureFailureScreenshot(page, `results-content-${term.replace(/ /g, '-')}`);
      console.log(`   Error: ${trunc(err.message)}`);
      results.push({ name: term, searchTerm: term, status: 'FAILED', error: trunc(err.message), screenshot: shot });
    }
  }

  console.log(`\n   Results Content: ${results.filter(r => r.status === 'PASSED').length}/${results.length} passed`);
  return results;
}
