/**
 * tests/desktop.js
 * Comprehensive desktop autocomplete test suite (6 tests).
 * Also exports the legacy single-scenario functions used by the contact-page test.
 */

import { config, trunc, SEARCH_TERMS } from '../core/config.js';
import { captureFailureScreenshot } from '../core/retry.js';
import { isAriaCollapsed, ariaLabel } from '../utils/search-context.js';
import { waitForPageReady, clearAndType } from '../utils/helpers.js';
import { findAndActivateSearch } from '../utils/helpers.js';
import { SELECTORS, resolveSelectors, firstVisible } from '../utils/selectors.js';
import {
  getAutocompleteState, validateAutocompleteOpened, validateAutocompleteClosed,
  getSuggestionsCount, getFirstSuggestionText, clickFirstSuggestion, validateSearchResults
} from '../utils/autocomplete.js';

async function hardRefresh(page, label = '') {
  try {
    await page.bringToFront().catch(() => {});
    await page.keyboard.down('Control');
    await page.keyboard.down('Shift');
    await page.keyboard.press('KeyR');
    await page.keyboard.up('Shift');
    await page.keyboard.up('Control');
    await page.waitForLoadState('domcontentloaded', { timeout: 30000 }).catch(() => {});
    await page.waitForTimeout(900);
    console.log(`   Hard refresh applied${label ? ` (${label})` : ''}`);
  } catch {
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    await page.waitForTimeout(900);
    console.log(`   Hard refresh fallback via reload${label ? ` (${label})` : ''}`);
  }
}

// ── Comprehensive desktop suite (mirrors Mobile 6-test structure) ─────────────
export async function testDesktopSearchOnDevice(
  page,
  deviceInfo = { name: 'Desktop Chrome', width: 1280, height: 720, isMobile: false }
) {
  console.log(`\n${'='.repeat(60)}`);
  console.log(` [${deviceInfo.name}] DESKTOP - Autocomplete Validation`);
  console.log(`${'='.repeat(60)}`);

  const results = [];

  const findInput = async () => findAndActivateSearch(page, false);
  const resetToHome = async () => {
    await page.goto(config.homeUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await hardRefresh(page, 'desktop-reset-home');
    await waitForPageReady(page, { networkTimeout: 5000 });
    return findInput();
  };

  // ── Shared: detect search success via URL *or* answers-frame iframe src ────
  // Some environments load results in-page inside an <iframe id="answers-frame">
  // (src="https://search-helpcenter.nationwide.com...?query=...") so the page
  // URL itself never changes.  We check both signals.
  const searchSucceeded = async (urlSnapshot) => {
    const pageUrl = page.url();
    // 1. URL changed or contains search indicators
    if (
      pageUrl.includes('search') ||
      pageUrl.includes('query=') ||
      pageUrl.includes('searchresults') ||
      pageUrl.includes('/result?') ||
      (urlSnapshot && pageUrl !== urlSnapshot)
    ) return { ok: true, via: `url:${pageUrl}` };

    // 2. answers-frame iframe src contains query=
    const iframeSrc = await page.evaluate(() => {
      const fr = document.querySelector('#answers-frame, iframe[title="Help center"], iframe[src*="query="]');
      return fr ? fr.getAttribute('src') || fr.src || '' : '';
    }).catch(() => '');
    if (iframeSrc && iframeSrc.includes('query=')) {
      return { ok: true, via: `iframe-src:${iframeSrc.substring(0, 120)}` };
    }

    // 3. Angular: bolt-autocomplete may route results into a results container
    const hasResultsContainer = await page.evaluate(() => {
      const sels = [
        '.yxt-Results',
        '[class*="yxt-Results"]',
        '#js-answersUniversalResults',
        '[class*="HitchhikerStandard"]',
        'section[class*="result"]',
      ];
      return sels.some(s => document.querySelector(s) !== null);
    }).catch(() => false);
    if (hasResultsContainer) return { ok: true, via: 'results-container-in-dom' };

    return { ok: false, via: `url:${pageUrl}` };
  };

  const getSuggestionNodeCountDeep = async () => page.evaluate(() => {
    const selectors = [
      '[role="option"]',
      'li.bolt-autocomplete-wc--option',
      '.yxt-SearchBar-suggestion',
      '.yxt-SearchBar-autocomplete li',
      '[class*="autocomplete"] [role="option"]',
    ];
    const found = new Set();
    const walk = (root) => {
      for (const selector of selectors) {
        for (const node of root.querySelectorAll(selector)) found.add(node);
      }
      for (const el of root.querySelectorAll('*')) {
        if (el.shadowRoot) walk(el.shadowRoot);
      }
    };
    walk(document);
    return found.size;
  }).catch(() => 0);

  try {
    let searchInput = await findInput();

    // Test 1: Search via keyboard (Enter key)
    console.log(`\n   Test 1: Search — Type + Enter Redirects`);
    await searchInput.click();
    await clearAndType(searchInput, 'mortgage', { delay: 80 });
    await page.waitForTimeout(800);

    // Verify typed value is present in the input
    const inputValue1 = await searchInput.inputValue().catch(() => '');
    console.log(`     Input value before Enter: "${inputValue1}"`);

    const state1 = await getAutocompleteState(page);
    console.log(`     Autocomplete opened: ${state1.isVisible ? 'YES' : 'NO'}`);

    // If autocomplete is open, dismiss it first so Enter submits the form
    // rather than selecting a suggestion
    if (state1.isVisible) {
      await page.keyboard.press('Escape');
      await page.waitForTimeout(300);
    }

    // Ensure focus is still on the search input before pressing Enter
    await searchInput.focus();
    await page.waitForTimeout(200);

    // Confirm active element is the search input
    const focusedBeforeEnter = await page.evaluate(() => {
      const active = document.activeElement;
      return active?.tagName + (active?.id ? '#' + active.id : '') + (active?.getAttribute('aria-label') || '');
    }).catch(() => 'unknown');
    console.log(`     Focused element before Enter: ${focusedBeforeEnter}`);

    const urlBefore1 = page.url();

    // Press Enter directly on the search input element (not page.keyboard)
    // to guarantee Enter is dispatched inside the input/form context
    await searchInput.press('Enter');

    // Wait for navigation/redirect with generous timeout
    await Promise.race([
      page.waitForURL(/search|query=|searchresults|result\?/i, { timeout: 10000 }),
      page.waitForTimeout(5000),
    ]).catch(() => {});

    await waitForPageReady(page);
    await page.waitForTimeout(1000);

    const result1 = await searchSucceeded(urlBefore1);
    console.log(`     Search executed: ${result1.ok ? 'YES' : 'NO'} | via:${result1.via}`);

    // If primary approach failed, try clicking the submit button as fallback
    if (!result1.ok) {
      console.log(`     Fallback: attempting submit button click...`);
      const runtimeSEL = resolveSelectors ? resolveSelectors(page) : SELECTORS;
      const submitBtn = await firstVisible(page, runtimeSEL.globalSubmitButton, 3000).catch(() => null);
      if (submitBtn) {
        await submitBtn.click();
        await Promise.race([
          page.waitForURL(/search|query=|searchresults|result\?/i, { timeout: 10000 }),
          page.waitForTimeout(5000),
        ]).catch(() => {});
        await waitForPageReady(page);
        await page.waitForTimeout(1000);
        const result1b = await searchSucceeded(urlBefore1);
        console.log(`     Submit button fallback: ${result1b.ok ? 'YES' : 'NO'} | via:${result1b.via}`);
        if (result1b.ok) {
          result1.ok = true;
          result1.via = result1b.via + ' (submit-btn-fallback)';
        }
      } else {
        console.log(`     No submit button found for fallback`);
      }
    }

    results.push({
      test: 'Search — Type + Enter Redirects',
      status: result1.ok ? 'PASSED' : 'FAILED',
      detail: result1.ok
        ? `Validation passed for this scenario. (${result1.via})`
        : 'Search interaction did not redirect to expected results. Please review the user flow.',
    });

    searchInput = await resetToHome();

    // Test 2: Keyboard navigation (ArrowDown + Enter)
    console.log(`\n   Test 2: Keyboard navigation on desktop`);
    await searchInput.click();
    await clearAndType(searchInput, SEARCH_TERMS.autoInsurance, { delay: 80 });
    await page.waitForTimeout(800);
    const count2 = await getSuggestionsCount(page);
    console.log(`     Suggestions: ${count2}`);
    if (count2 > 0) {
      const urlBefore2 = page.url();
      await page.keyboard.press('ArrowDown');
      await page.waitForTimeout(300);
      await page.keyboard.press('Enter');
      await waitForPageReady(page);
      await page.waitForTimeout(800);
      const result2 = await searchSucceeded(urlBefore2);
      results.push({
        test: 'Desktop Keyboard Nav',
        status: result2.ok ? 'PASSED' : 'FAILED',
        detail: result2.ok
          ? `Validation passed for this scenario. (${result2.via})`
          : 'Keyboard navigation did not produce results on page or redirect.',
      });
    } else {
      results.push({ test: 'Desktop Keyboard Nav', status: 'SKIPPED' });
    }

    searchInput = await resetToHome();

    // Test 3: Search via autocomplete selection
    console.log(`\n   Test 3: Search — Select Suggestion Redirects`);
    await searchInput.click();
    await clearAndType(searchInput, SEARCH_TERMS.lifeInsurance, { delay: 80 });
    await page.waitForTimeout(800);
    const count3 = await getSuggestionsCount(page);
    if (count3 > 0) {
      const urlBefore3 = page.url();
      // clickFirstSuggestion resolves selectors for both Prod (light DOM) and
      // Angular bolt-autocomplete (shadow DOM) — replaces the inline evaluate
      // which could not pierce shadow roots.
      let clicked3 = false;
      try {
        await Promise.all([
          page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 15000 }).catch(() => {}),
          clickFirstSuggestion(page).then(v => { clicked3 = v; }),
        ]);
      } catch { /* navigation handled above */ }
      await page.waitForTimeout(800);
      const result3 = await searchSucceeded(urlBefore3);
      console.log(`     Suggestion clicked: ${clicked3} | via:${result3.via}`);
      if (!clicked3) {
        results.push({
          test: 'Search — Select Suggestion Redirects',
          status: 'FAILED',
          detail: 'No visible suggestion found to click. Please review autocomplete selector coverage.',
          error: 'Could not click suggestion',
        });
      } else {
        results.push({
          test: 'Search — Select Suggestion Redirects',
          status: result3.ok ? 'PASSED' : 'FAILED',
          detail: result3.ok
            ? `Validation passed for this scenario. (${result3.via})`
            : 'Search interaction did not produce results on page or redirect. Please review the user flow.',
        });
      }
    } else {
      results.push({
        test: 'Search — Select Suggestion Redirects',
        status: 'FAILED',
        detail: 'Search interaction did not redirect to expected results. Please review the user flow.',
        error: 'No autocomplete suggestions available to select',
      });
    }

    searchInput = await resetToHome();

    // ── ARIA Interaction Tests (A / B / C) — Global Header Search ────────────
    // Cover the "Additional Scenario – Expected Behavior" for Global Header.

    // Shared helper: read aria-expanded from light DOM or bolt shadow DOM
    const getAriaExpanded = () => page.evaluate(() => {
      const el = document.querySelector('input[aria-expanded]');
      if (el) return el.getAttribute('aria-expanded');
      for (const host of document.querySelectorAll('bolt-autocomplete, bolt-autocomplete-wc')) {
        const inp = host.shadowRoot?.querySelector('input[aria-expanded]');
        if (inp) return inp.getAttribute('aria-expanded');
      }
      return null;
    }).catch(() => null);

    // ── Test A: Click opens dropdown — aria-expanded false → true ─────────────
    console.log(`\n   Test A: Click-to-open — aria-expanded false → true (Global Header)`);
    try {
      await searchInput.scrollIntoViewIfNeeded({ timeout: 3000 }).catch(() => {});
      await page.keyboard.press('Escape');
      await page.waitForTimeout(200);

      const ariaBeforeClickA = await getAriaExpanded();
      await searchInput.click();
      await clearAndType(searchInput, SEARCH_TERMS.autoInsurance, { delay: 80 });
      await page.waitForTimeout(700);

      const stateAfterClickA = await getAutocompleteState(page);
      const ariaAfterClickA = await getAriaExpanded();
      const dropdownOpenA = stateAfterClickA.isVisible;
      const ariaFlippedA = ariaAfterClickA === 'true';
      const clickOpenOkA = dropdownOpenA && ariaFlippedA;

      console.log(`     aria-expanded before:${ariaBeforeClickA} after:${ariaAfterClickA} | dropdown:${dropdownOpenA}`);
      results.push({
        test: 'Desktop Click-to-Open ARIA',
        status: clickOpenOkA ? 'PASSED' : 'FAILED',
        detail: `dropdownOpen:${dropdownOpenA} ariaBefore:${ariaBeforeClickA} ariaAfter:${ariaAfterClickA}`,
      });
      await page.keyboard.press('Escape');
      await page.waitForTimeout(300);
      await searchInput.clear();
    } catch (errA) {
      console.log(`     Error: ${trunc(errA.message)}`);
      results.push({ test: 'Desktop Click-to-Open ARIA', status: 'FAILED', error: trunc(errA.message) });
    }

    // ── Test B: ArrowDown focuses first suggestion — aria-activedescendant / aria-selected ─
    console.log(`\n   Test B: Arrow key — first suggestion ARIA focus (Global Header)`);
    try {
      await searchInput.click();
      await clearAndType(searchInput, SEARCH_TERMS.autoInsurance, { delay: 80 });
      await page.waitForTimeout(800);

      const sugCountB = await getSuggestionNodeCountDeep();
      if (sugCountB === 0) {
        results.push({ test: 'Desktop Arrow Nav ARIA Focus', status: 'SKIPPED', detail: 'No suggestions available' });
      } else {
        const activeBeforeB = await page.evaluate(() => {
          const el = document.querySelector('input[aria-activedescendant]');
          if (el) return el.getAttribute('aria-activedescendant');
          for (const host of document.querySelectorAll('bolt-autocomplete, bolt-autocomplete-wc')) {
            const inp = host.shadowRoot?.querySelector('input');
            if (inp) return inp.getAttribute('aria-activedescendant') || null;
          }
          return null;
        }).catch(() => null);

        await page.keyboard.press('ArrowDown');
        await page.waitForTimeout(350);

        const activeAfterB = await page.evaluate(() => {
          const el = document.querySelector('input[aria-activedescendant]');
          if (el) return el.getAttribute('aria-activedescendant');
          for (const host of document.querySelectorAll('bolt-autocomplete, bolt-autocomplete-wc')) {
            const inp = host.shadowRoot?.querySelector('input');
            if (inp) return inp.getAttribute('aria-activedescendant') || null;
          }
          return null;
        }).catch(() => null);

        const ariaSelectedCountB = await page.evaluate(() => {
          const found = new Set();
          const walk = (root) => {
            for (const node of root.querySelectorAll('[role="option"][aria-selected="true"], .yxt-SearchBar-suggestion--focused')) found.add(node);
            for (const el of root.querySelectorAll('*')) { if (el.shadowRoot) walk(el.shadowRoot); }
          };
          walk(document);
          return found.size;
        }).catch(() => 0);

        const focusMovedB = (activeAfterB && activeAfterB !== activeBeforeB) || ariaSelectedCountB > 0;
        console.log(`     activedescendant before:${activeBeforeB} after:${activeAfterB} | aria-selected nodes:${ariaSelectedCountB}`);
        results.push({
          test: 'Desktop Arrow Nav ARIA Focus',
          status: focusMovedB ? 'PASSED' : 'FAILED',
          detail: `activeBefore:${activeBeforeB} activeAfter:${activeAfterB} ariaSelectedNodes:${ariaSelectedCountB}`,
        });
      }
      await page.keyboard.press('Escape');
      await page.waitForTimeout(300);
      await searchInput.clear();
    } catch (errB) {
      console.log(`     Error: ${trunc(errB.message)}`);
      results.push({ test: 'Desktop Arrow Nav ARIA Focus', status: 'FAILED', error: trunc(errB.message) });
    }

    // ── Test C: Suggestion selection — aria-expanded true → false, no nodes ───
    console.log(`\n   Test C: Suggestion selection — aria-expanded true → false (Global Header)`);
    try {
      await searchInput.click();
      await clearAndType(searchInput, SEARCH_TERMS.autoInsurance, { delay: 80 });
      await page.waitForTimeout(800);

      const ariaBeforeSelectC = await getAriaExpanded();
      const sugsBeforeC = await getSuggestionNodeCountDeep();

      if (sugsBeforeC === 0) {
        results.push({ test: 'Desktop Suggestion Selection ARIA', status: 'SKIPPED', detail: 'No suggestions available' });
      } else {
        await page.keyboard.press('ArrowDown');
        await page.waitForTimeout(300);
        await page.keyboard.press('Enter');
        await page.waitForTimeout(1500);

        const ariaAfterSelectC = await getAriaExpanded();
        const stateAfterSelectC = await getAutocompleteState(page);
        const sugsAfterC = await getSuggestionNodeCountDeep();
        const urlAfterC = page.url();
        const inputValC = await searchInput.inputValue().catch(() => '');

        const dropdownClosedC = !stateAfterSelectC.isVisible;
        // isAriaCollapsed handles Chrome (null = attr removed) and Edge ('false')
        const ariaCollapsedC = isAriaCollapsed(ariaAfterSelectC);
        const noSugsC = sugsAfterC === 0;
        const navigatedOrPopulatedC = urlAfterC.includes('query=') || urlAfterC.includes('search') || inputValC.length > 0;
        const selectionOkC = dropdownClosedC && ariaCollapsedC && noSugsC;

        console.log(`     aria-expanded before:${ariaBeforeSelectC} after:${ariaAfterSelectC}`);
        console.log(`     closed:${dropdownClosedC} noSugs:${noSugsC} inputValue:"${inputValC}" navigated:${navigatedOrPopulatedC}`);
        results.push({
          test: 'Desktop Suggestion Selection ARIA',
          status: selectionOkC ? 'PASSED' : 'FAILED',
          detail: `closed:${dropdownClosedC} ariaCollapsed:${ariaCollapsedC} noSugs:${noSugsC} navigatedOrPopulated:${navigatedOrPopulatedC} ariaBefore:${ariaBeforeSelectC} ariaAfter:${ariaLabel(ariaAfterSelectC)}`,
        });
        // Restore to home if navigated away
        if (!page.url().includes(config.homeUrl.replace(/https?:\/\//, ''))) {
          searchInput = await resetToHome();
        } else {
          await page.keyboard.press('Escape').catch(() => {});
          await searchInput.clear().catch(() => {});
        }
      }
    } catch (errC) {
      console.log(`     Error: ${trunc(errC.message)}`);
      results.push({ test: 'Desktop Suggestion Selection ARIA', status: 'FAILED', error: trunc(errC.message) });
      searchInput = await resetToHome().catch(() => searchInput);
    }

    searchInput = await resetToHome();

    // Test 4: Escape key closes autocomplete
    console.log(`\n   Test 4: Escape key closes autocomplete`);
    await searchInput.click();
    await clearAndType(searchInput, SEARCH_TERMS.policyDetails, { delay: 80 });
    await page.waitForTimeout(800);
    const before4 = await getAutocompleteState(page);
    const ariaBefore4 = await searchInput.getAttribute('aria-expanded').catch(() => null);
    console.log(`     Autocomplete open before Escape: ${before4.isVisible}`);
    // Use focus() not click() — a click can re-open the dropdown and cause a
    // race where ESC fires before the re-open animation completes.
    await searchInput.focus();
    await page.waitForTimeout(150);
    await page.keyboard.press('Escape');
    // Wait for suggestions to disappear (up to 1 s), then retry once if still open
    for (let _i = 0; _i < 5; _i++) {
      await page.waitForTimeout(200);
      const _state = await getAutocompleteState(page);
      if (!_state.isVisible) break;
      if (_i === 2) { await page.keyboard.press('Escape'); } // second ESC if needed
    }
    const after4 = await getAutocompleteState(page);
    const ariaAfter4 = await searchInput.getAttribute('aria-expanded').catch(() => null);
    const suggestionNodesAfter4 = await getSuggestionNodeCountDeep();
    const closed4 = !after4.isVisible;
    const ariaTransitionOk4 = ariaBefore4 !== 'true' ? closed4 : isAriaCollapsed(ariaAfter4);
    const noSuggestions4 = suggestionNodesAfter4 === 0;
    const esc4   = closed4 && ariaTransitionOk4 && noSuggestions4;
    console.log(`     Escape closed autocomplete: ${esc4 ? 'YES' : 'NO'}`);
    console.log(`     aria-expanded before:${ariaBefore4} after:${ariaLabel(ariaAfter4)}`);
    results.push({
      test: 'Desktop Escape Key',
      status: esc4 ? 'PASSED' : 'FAILED',
      detail: `wasOpen:${before4.isVisible} closed:${closed4} ariaBefore:${ariaBefore4} ariaAfter:${ariaLabel(ariaAfter4)} suggestionNodesAfterEsc:${suggestionNodesAfter4}`,
    });

    // Test 5: Click outside closes autocomplete
    console.log(`\n   Test 5: Click outside closes autocomplete`);
    await searchInput.click();
    await clearAndType(searchInput, SEARCH_TERMS.rentersInsurance, { delay: 80 });
    await page.waitForTimeout(800);
    const before5 = await getAutocompleteState(page);
    console.log(`     Open before outside click: ${before5.isVisible}`);
    await page.locator('body').click({ position: { x: 50, y: 400 } });
    await page.waitForTimeout(500);
    const after5  = await getAutocompleteState(page);
    const click5  = !after5.isVisible;
    console.log(`     Click outside closed: ${click5 ? 'YES' : 'NO'}`);
    results.push({ test: 'Desktop Click Outside', status: click5 ? 'PASSED' : 'FAILED' });

    // Test 6: Desktop top navigation check
    console.log(`\n   Test 6: Desktop top navigation validation`);
    try {
      await page.goto(config.homeUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
      await hardRefresh(page, 'desktop-topnav');
      await waitForPageReady(page);

      let navLinks = null, navSel = null;
      for (const sel of resolveSelectors(page).topNavLinks) {
        const count = await page.locator(sel).count();
        if (count > 0) { navLinks = page.locator(sel); navSel = sel; break; }
      }

      if (navLinks) {
        const total   = await navLinks.count();
        const sample  = Math.min(total, 10);
        let visible   = 0, enabled = 0;
        for (let i = 0; i < sample; i++) {
          const lnk = navLinks.nth(i);
          if (await lnk.isVisible().catch(() => false)) visible++;
          if (await lnk.isEnabled().catch(() => false)) enabled++;
        }
        console.log(`      Selector    : ${navSel} (${total} links)`);
        console.log(`      Visible     : ${visible}/${sample}`);
        console.log(`      Enabled     : ${enabled}/${sample}`);

        // Shadow DOM fallback: bolt-header-wc uses web components — pierce shadow root
        let shadowCount = 0;
        if (visible === 0) {
          shadowCount = await page.evaluate(() => {
            const hosts = [
              ...document.querySelectorAll('bolt-header-wc, bolt-header, [class*="bolt-header"]')
            ];
            let links = [];
            for (const h of hosts) {
              const root = h.shadowRoot;
              if (root) links.push(...root.querySelectorAll('a[href]'));
            }
            // also check nested shadow roots one level deep
            if (!links.length) {
              const all = document.querySelectorAll('*');
              for (const el of all) {
                if (el.shadowRoot) {
                  const found = el.shadowRoot.querySelectorAll('a[href]');
                  if (found.length) { links.push(...found); break; }
                }
              }
            }
            return links.filter(a => {
              const s = getComputedStyle(a);
              return s.display !== 'none' && s.visibility !== 'hidden' && parseFloat(s.opacity) > 0;
            }).length;
          }).catch(() => 0);
          if (shadowCount > 0)
            console.log(`      Shadow DOM nav links found: ${shadowCount}`);
        }

        const passed = visible > 0 || shadowCount > 0;
        results.push({ test: 'Desktop Top Navigation',
          status: passed ? 'PASSED' : 'FAILED',
          detail: `visible:${visible}/${sample} enabled:${enabled}/${sample}${
            shadowCount > 0 ? ` shadowLinks:${shadowCount}` : ''}` });
      } else {
        results.push({ test: 'Desktop Top Navigation', status: 'SKIPPED' });
      }
    } catch (navErr) {
      results.push({ test: 'Desktop Top Navigation', status: 'FAILED', error: trunc(navErr.message) });
    }

  } catch (error) {
    console.log(`   Desktop test failed: ${trunc(error.message)}`);
    results.push({ test: 'Desktop Overall', status: 'FAILED', error: error.message });
  }

  const passed = results.filter(r => r.status === 'PASSED').length;
  const total  = results.filter(r => r.status !== 'SKIPPED').length;
  console.log(`\n   ${deviceInfo.name}: ${passed}/${total} passed`);
  return { device: deviceInfo.name, results, passed, total };
}

// ── Legacy single-scenario functions (kept for contact-page test) ─────────────
export async function testDesktopSearchWithEnterKey(page, searchTerm, isContactPage = false) {
  console.log(`\n${'='.repeat(60)}`);
  const label = isContactPage ? 'CONTACT PAGE' : 'DESKTOP';
  console.log(` ${label} - Type + ENTER key | "${searchTerm}"`);
  console.log(`${'='.repeat(60)}`);

  const searchBox = await findAndActivateSearch(page, false);
  await searchBox.click();
  await clearAndType(searchBox, searchTerm, { delay: 80 });
  await page.waitForTimeout(800);

  await validateAutocompleteOpened(page);
  const suggestionsCount = await getSuggestionsCount(page);
  console.log(`  Suggestions: ${suggestionsCount}`);

  await page.keyboard.press('Enter');
  await waitForPageReady(page);
  await validateAutocompleteClosed(page);
  await validateSearchResults(page, searchTerm, isContactPage);

  console.log(`   PASSED`);
  return { scenario: isContactPage ? 'Contact Page Enter Key' : 'Desktop Enter Key', status: 'PASSED' };
}

export async function testDesktopSearchWithKeyboardNavigation(page, searchTerm) {
  console.log(`\n${'='.repeat(60)}`);
  console.log(` DESKTOP - Arrow Down + ENTER | "${searchTerm}"`);
  console.log(`${'='.repeat(60)}`);

  const searchBox = await findAndActivateSearch(page, false);
  await searchBox.click();
  await clearAndType(searchBox, searchTerm, { delay: 80 });
  await page.waitForTimeout(800);

  await validateAutocompleteOpened(page);
  const count = await getSuggestionsCount(page);
  if (count === 0) {
    console.log(`   No suggestions, skipping`);
    return { scenario: 'Desktop Keyboard Nav', status: 'SKIPPED' };
  }

  const suggestionText = await getFirstSuggestionText(page);
  console.log(`  First suggestion: "${suggestionText}"`);

  await page.keyboard.press('ArrowDown');
  await page.waitForTimeout(300);
  await page.keyboard.press('Enter');
  await waitForPageReady(page);
  await validateAutocompleteClosed(page);
  await validateSearchResults(page, searchTerm, false);

  console.log(`   PASSED`);
  return { scenario: 'Desktop Keyboard Nav', status: 'PASSED' };
}

export async function testDesktopSearchWithMouseClick(page, searchTerm) {
  console.log(`\n${'='.repeat(60)}`);
  console.log(` DESKTOP - Mouse click on suggestion | "${searchTerm}"`);
  console.log(`${'='.repeat(60)}`);

  const searchBox = await findAndActivateSearch(page, false);
  await searchBox.click();
  await clearAndType(searchBox, searchTerm, { delay: 80 });
  await page.waitForTimeout(800);

  await validateAutocompleteOpened(page);
  const count = await getSuggestionsCount(page);
  if (count === 0) {
    console.log(`   No suggestions, skipping`);
    return { scenario: 'Desktop Mouse Click', status: 'SKIPPED' };
  }

  await clickFirstSuggestion(page);
  await waitForPageReady(page);
  await validateAutocompleteClosed(page);
  await validateSearchResults(page, searchTerm, false);

  console.log(`   PASSED`);
  return { scenario: 'Desktop Mouse Click', status: 'PASSED' };
}
