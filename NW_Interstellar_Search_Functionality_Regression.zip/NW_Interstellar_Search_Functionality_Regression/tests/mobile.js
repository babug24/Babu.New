/**
 * tests/mobile.js
 * Mobile/tablet autocomplete suite (6 tests per device) + viewport runner.
 */

import path from 'path';
import { config, trunc, SCREENSHOTS_DIR, SEARCH_TERMS } from '../core/config.js';
import { waitForPageReady, dismissCookieBanner, registerCookieAutoDismiss, clearAndType } from '../utils/helpers.js';
import { SELECTORS, resolveSelectors, firstVisible, isAngularEnv } from '../utils/selectors.js';
import { SEARCH_CONTEXTS } from '../utils/search-context.js';
import { getAutocompleteState, getSuggestionsCount, clickFirstSuggestion } from '../utils/autocomplete.js';

async function hardRefresh(page, label = '') {
  try {
    await page.bringToFront().catch(() => {});
    await page.keyboard.down('Control');
    await page.keyboard.down('Shift');
    await page.keyboard.press('KeyR');
    await page.keyboard.up('Shift');
    await page.keyboard.up('Control');
    await page.waitForLoadState('domcontentloaded', { timeout: 30000 }).catch(() => {});
    await page.waitForTimeout(900);
    console.log(`   Hard refresh applied${label ? ` (${label})` : ''}`);
  } catch {
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    await page.waitForTimeout(900);
    console.log(`   Hard refresh fallback via reload${label ? ` (${label})` : ''}`);
  }
}

// ── Single device test (mirrors testDesktopSearchOnDevice) ────────────────────
export async function testMobileSearchOnDevice(page, deviceInfo) {
  console.log(`\n${'='.repeat(60)}`);
  console.log(` [${deviceInfo.name}] MOBILE - Autocomplete Validation`);
  console.log(`${'='.repeat(60)}`);

  const results = [];
  // Resolve selectors at runtime — picks SELECTORS_ANGULAR for uat-ng URLs
  const SEL = resolveSelectors(page);

  // ── Cookie banner dismissal — must happen before any interaction ────────────
  await dismissCookieBanner(page).catch(() => {});
  await page.waitForTimeout(300);

  // Dismiss any open nav overlay
  for (const sel of SEL.navClose) {
    try {
      const el = page.locator(sel).first();
      if (await el.count() > 0 && await el.isVisible({ timeout: 800 }).catch(() => false)) {
        await el.click(); await page.waitForTimeout(600); break;
      }
    } catch { /* ignore */ }
  }

  // Find search input.
  // On mobile AND tablets (width <= 1024px) the search input is hidden behind
  // the header until the search icon is tapped — always click icon first.
  // On Angular mobile, the hamburger menu must be opened before the search icon is visible.
  let searchInput = null;
  const needsIconFirst = deviceInfo.isMobile || (deviceInfo.width <= 1024);

  if (needsIconFirst) {
    // Open hamburger menu first to reveal search icon (Angular mobile)
    const hamburger = await firstVisible(page, SEL.hamburger, 2000);
    if (hamburger) {
      await hamburger.click();
      console.log(`   Hamburger menu opened (initial)`);
      await page.waitForTimeout(800);
    }

    const icon = await firstVisible(page, SEL.searchIcon);
    if (icon) {
      await icon.click();
      console.log(`   Search icon clicked (icon-first for ${deviceInfo.width}px)`);
      await page.waitForTimeout(600);
    }
  }

  const deadline = Date.now() + 4000;
  while (Date.now() < deadline && !searchInput) {
    searchInput = await firstVisible(page, SEL.searchInput, 400);
    if (!searchInput) await page.waitForTimeout(300);
  }

  // Desktop-width fallback: try icon if direct check failed
  if (!searchInput && !needsIconFirst) {
    const icon = await firstVisible(page, SEL.searchIcon);
    if (icon) { await icon.click(); await page.waitForTimeout(600); }
    const d2 = Date.now() + 3000;
    while (Date.now() < d2 && !searchInput) {
      searchInput = await firstVisible(page, SEL.searchInput, 400);
      if (!searchInput) await page.waitForTimeout(300);
    }
  }

  if (!searchInput) {
    const el = page.locator(SEL.searchInput[0]).first();
    if (await el.count() > 0) {
      await page.evaluate(() => {
        const inp = document.querySelector('#yxt-SearchBar-input--search-bar-1');
        if (inp) { inp.style.visibility = 'visible'; inp.style.display = 'block'; inp.focus(); }
      });
      await page.waitForTimeout(400);
      searchInput = el;
    }
  }

  if (!searchInput) throw new Error(`Search input not found on ${page.url()}`);

  // Helper: re-open search after goBack() — re-clicks icon, re-acquires fresh locator,
  // then scrolls the input into view so subsequent force:true clicks succeed.
  const reOpenSearch = async () => {
    searchInput = null;
    await page.evaluate(() => window.scrollTo(0, 0)).catch(() => {});

    // Dismiss cookie banner if it reappeared after navigation
    await dismissCookieBanner(page).catch(() => {});

    // On mobile Angular, the search icon may require the hamburger menu to be opened first
    if (needsIconFirst) {
      const hamburger = await firstVisible(page, SEL.hamburger, 2000);
      if (hamburger) {
        await hamburger.click();
        console.log(`   Hamburger menu opened`);
        await page.waitForTimeout(800);
      }
    }

    const icon2 = await firstVisible(page, SEL.searchIcon, 2000);
    if (icon2) { await icon2.click(); await page.waitForTimeout(600); }
    const d3 = Date.now() + 4000;
    while (Date.now() < d3 && !searchInput) {
      searchInput = await firstVisible(page, SEL.searchInput, 400);
      if (!searchInput) await page.waitForTimeout(300);
    }
    if (!searchInput) searchInput = page.locator(SEL.searchInput[0]).first();
    // Scroll the input into view so it is within the viewport before clicking
    await searchInput.scrollIntoViewIfNeeded({ timeout: 2000 }).catch(() => {});
    await page.waitForTimeout(200);
  };

  // JS-based input activation — focuses + clears via evaluate, completely bypassing
  // Playwright's viewport bounding-box enforcement (needed after goBack on mobile).
  // Characters are typed one-by-one via JS to fire input/keyup events that trigger
  // Yext autocomplete (page.keyboard.type does not reliably do this on touch emulation).
  const jsFocusInput = async (fillText = '') => {
    await page.evaluate((text) => {
      // Try shadow DOM for Angular bolt-autocomplete, fallback to prod selector
      let inp = null;
      for (const host of document.querySelectorAll('bolt-autocomplete, bolt-textfield-wc, bolt-autocomplete-wc')) {
        inp = host.shadowRoot?.querySelector('input[data-test="input"]') || host.shadowRoot?.querySelector('input');
        if (inp) break;
      }
      if (!inp) inp = document.querySelector('#yxt-SearchBar-input--search-bar-1');
      if (!inp) return;
      inp.style.visibility = 'visible';
      inp.style.display = 'block';
      inp.removeAttribute('readonly');
      inp.focus();
      inp.click();
      inp.value = '';
      inp.dispatchEvent(new Event('input', { bubbles: true }));
      if (text) {
        for (const ch of text) {
          inp.value += ch;
          inp.dispatchEvent(new KeyboardEvent('keydown', { key: ch, bubbles: true }));
          inp.dispatchEvent(new Event('input', { bubbles: true }));
          inp.dispatchEvent(new KeyboardEvent('keyup', { key: ch, bubbles: true }));
        }
      }
    }, fillText);
    await page.waitForTimeout(300);
  };

  const typeForAutocomplete = async (term) => {
    let usedFallback = false;
    try {
      await searchInput.click({ force: true });
      await searchInput.clear();
      await clearAndType(searchInput, term, { delay: 80 });
      await page.waitForTimeout(700);
      const value = await searchInput.inputValue().catch(() => '');
      if (!String(value || '').trim()) {
        usedFallback = true;
        await jsFocusInput(term);
      }
    } catch {
      usedFallback = true;
      await jsFocusInput(term);
    }

    let count = await getSuggestionsCount(page, 1800);
    if (count === 0) {
      usedFallback = true;
      await jsFocusInput(term);
      await page.waitForTimeout(900);
      count = await getSuggestionsCount(page, 3000);
    }
    const state = await getAutocompleteState(page);
    return { count, state, usedFallback };
  };

  try {
    // Test 1: Type + Enter
    console.log(`\n   Test 1: Type + Enter on mobile`);
    const prep1 = await typeForAutocomplete(SEARCH_TERMS.autoInsurance);
    console.log(`     Autocomplete opened: ${prep1.state.isVisible}`);
    const urlBefore1 = page.url();
    await page.keyboard.press('Enter');
    await page.waitForTimeout(2000);
    const url1 = page.url();
    // Check iframe src for same-page search environments
    const iframeSrc1 = await page.evaluate(() => {
      const fr = document.querySelector('#answers-frame, iframe[title="Help center"], iframe[src*="query="]');
      return fr ? (fr.getAttribute('src') || '') : '';
    }).catch(() => '');
    let ok1 = url1.includes('search') || url1.includes('query=') ||
              url1.includes('searchresults') || url1.includes('/result?') ||
              (url1 !== urlBefore1) ||
              (iframeSrc1 && iframeSrc1.includes('query='));
    if (!ok1) {
      const submitBtn = await firstVisible(page, SEL.globalSubmitButton || [], 1200);
      if (submitBtn) {
        await submitBtn.click().catch(() => {});
        await page.waitForTimeout(1800);
        const retryUrl = page.url();
        const retryIframe = await page.evaluate(() => {
          const fr = document.querySelector('#answers-frame, iframe[title="Help center"], iframe[src*="query="]');
          return fr ? (fr.getAttribute('src') || '') : '';
        }).catch(() => '');
        ok1 = retryUrl.includes('search') || retryUrl.includes('query=') ||
              retryUrl.includes('searchresults') || retryUrl.includes('/result?') ||
              (retryIframe && retryIframe.includes('query='));
      }
    }
    console.log(`     Search executed: ${ok1}`);
    results.push({
      test: 'Mobile Type + Enter',
      status: ok1 ? 'PASSED' : 'FAILED',
      detail: `acVisible:${prep1.state.isVisible} suggestions:${prep1.count} fallback:${prep1.usedFallback}`
    });
    // Angular SPA: page.goBack() causes ERR_ABORTED on uat-ng router navigation.
    // Use goto(homeUrl) instead — reliable on both Angular and Prod.
    const isAngularEnvFlag = isAngularEnv(page.url());
    if (isAngularEnvFlag) {
      await page.goto(config.homeUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
      await hardRefresh(page, 'mobile-home-after-test1');
      await page.waitForTimeout(1500);
    } else {
      await page.goBack().catch(async () => {
        await page.goto(config.homeUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
        await hardRefresh(page, 'mobile-home-after-test1-fallback');
      });
      await page.waitForTimeout(2000);
    }
    await reOpenSearch();

    // Test 2: Touch/click suggestion
    console.log(`\n   Test 2: Touch/Click on suggestion`);

    // Ensure cookie banner is dismissed before this test
    await dismissCookieBanner(page).catch(() => {});

    // NOTE: reOpenSearch() above already opened hamburger + search icon and
    // acquired searchInput. Do NOT re-open hamburger here — it would toggle it closed.

    // Use typeForAutocomplete (same proven approach as Test 1) which uses real
    // Playwright keyboard input to trigger Angular's autocomplete HTTP fetch
    let count3 = 0;
    let prep2UsedFallback = false;
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        // Re-acquire searchInput reference if stale
        if (!searchInput || !(await searchInput.isVisible().catch(() => false))) {
          await reOpenSearch();
        }

        // Primary: use typeForAutocomplete (proven in Test 1)
        const prep2 = await typeForAutocomplete(SEARCH_TERMS.lifeInsurance);
        count3 = prep2.count;
        prep2UsedFallback = prep2.usedFallback;
        if (count3 > 0) break;
      } catch (err) {
        console.log(`     Attempt ${attempt} error: ${trunc(err.message)}`);
      }

      console.log(`     Attempt ${attempt}: suggestions=${count3}, retrying...`);
      if (attempt < 3) {
        // Navigate fresh and re-open search for next attempt
        await page.goto(config.homeUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
        await hardRefresh(page, 'mobile-home-retry-test2');
        await waitForPageReady(page, { networkTimeout: 5000 });
        await reOpenSearch();
      }
    }

    console.log(`     Suggestions: ${count3} (fallback: ${prep2UsedFallback})`);
    if (count3 > 0) {
      const clicked = await clickFirstSuggestion(page);
      results.push({ test: 'Mobile Touch/Click', status: clicked ? 'PASSED' : 'FAILED',
        error: clicked ? undefined : 'Suggestion found in DOM but click did not register' });
      if (clicked) await page.waitForTimeout(2000);
    } else {
      console.log(`     No suggestions returned for "life insurance" — marking FAILED`);
      results.push({ test: 'Mobile Touch/Click', status: 'FAILED',
        error: `No autocomplete suggestions appeared for "life insurance" — dropdown did not open or selectors missed` });
    }
    // Angular SPA goBack fix
    if (isAngularEnv(page.url())) {
      await page.goto(config.homeUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
      await hardRefresh(page, 'mobile-home-after-test4');
      await page.waitForTimeout(1500);
    } else {
      await page.goBack().catch(async () => {
        await page.goto(config.homeUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
        await hardRefresh(page, 'mobile-home-after-test4-fallback');
      });
      await page.waitForTimeout(2000);
    }
    await reOpenSearch();

    // Test 3: Escape key closes autocomplete
    console.log(`\n   Test 3: Escape key closes`);
    // Use typeForAutocomplete (real keyboard) to reliably open the dropdown
    const prep3 = await typeForAutocomplete(SEARCH_TERMS.policyDetails);
    console.log(`     Open before Escape: ${prep3.state.isVisible} (suggestions: ${prep3.count})`);
    // Focus the input before ESC — widget ESC handler may live at wrapper/document level
    if (searchInput && await searchInput.isVisible().catch(() => false)) await searchInput.focus();
    await page.keyboard.press('Escape');
    await page.waitForTimeout(600);
    const after4 = await getAutocompleteState(page);
    console.log(`     Open after Escape: ${after4.isVisible}`);
    results.push({ test: 'Mobile Escape Key', status: !after4.isVisible ? 'PASSED' : 'FAILED' });

    // Re-open search for Test 4
    if (!searchInput || !(await searchInput.isVisible().catch(() => false))) {
      await reOpenSearch();
    }

    // Test 4: Click outside closes autocomplete
    console.log(`\n   Test 4: Click outside closes autocomplete`);
    // Use typeForAutocomplete (real keyboard) to reliably open the dropdown
    const prep4 = await typeForAutocomplete(SEARCH_TERMS.rentersInsurance);
    console.log(`     Open before outside click: ${prep4.state.isVisible} (suggestions: ${prep4.count})`);

    // Use Playwright's real mouse click on a safe area outside the autocomplete
    // This properly triggers Angular's focusout/blur handler (unlike synthetic JS events)
    try {
      // Click on the page body/main content area well below the header
      await page.mouse.click(50, Math.min(deviceInfo.height - 50, 600));
    } catch {
      // Fallback: click on a known safe element like <main> or <footer>
      const safeTarget = await page.locator('main, footer, [role="main"], body').first();
      if (safeTarget) {
        await safeTarget.click({ position: { x: 10, y: 10 }, force: true }).catch(() => {});
      }
    }
    await page.waitForTimeout(800);
    const after5 = await getAutocompleteState(page);
    console.log(`     Open after outside click: ${after5.isVisible}`);
    results.push({ test: 'Mobile Click Outside', status: !after5.isVisible ? 'PASSED' : 'FAILED' });

  } catch (error) {
    console.log(`   Mobile test failed: ${trunc(error.message)}`);
    results.push({ test: 'Mobile Overall', status: 'FAILED', error: error.message });
  }

  const passed = results.filter(r => r.status === 'PASSED').length;
  const total  = results.filter(r => r.status !== 'SKIPPED').length;
  console.log(`\n   ${deviceInfo.name}: ${passed}/${total} passed`);
  return { device: deviceInfo.name, results, passed, total };
}

// ── Contact page search test on a given device/page ─────────────────────────
export async function testContactPageOnDevice(page, deviceInfo) {
  console.log(`\n   [${deviceInfo.name}] CONTACT PAGE — Help Center Search`);
  const results = [];

  try {
    await page.goto(
      `${config.homeUrl.replace(/\/$/,'')}/personal/contact/`,
      { waitUntil: 'domcontentloaded', timeout: 30000 }
    );
    await hardRefresh(page, 'contact-page-launch');
    await dismissCookieBanner(page).catch(() => {});
    await waitForPageReady(page);

    // Locate the contact page search input — runtime-resolved for Angular vs Prod
    const CSEL = resolveSelectors(page);
    let searchInput = await firstVisible(page, CSEL.contactSearchInput, 3000);
    if (!searchInput) {
      // Angular: bolt-autocomplete shadow input may not be CSS-visible — try shadow pierce directly
      for (const sel of ['bolt-autocomplete >> input[data-test="input"]', 'input[aria-label="Search"]']) {
        try {
          const el = page.locator(sel).first();
          if (await el.count() > 0) { searchInput = el; break; }
        } catch { /* next */ }
      }
    }
    if (!searchInput) {
      results.push({ test: 'Contact Search — Input Found', status: 'FAILED', error: 'contactSearchInput not found' });
      return { device: deviceInfo.name, results, passed: 0, total: 1 };
    }
    results.push({ test: 'Contact Search — Input Found', status: 'PASSED' });

    // Test 1: Type + Enter
    await searchInput.click();
    await clearAndType(searchInput, SEARCH_TERMS.rentersInsurance, { delay: 80 });
    await page.waitForTimeout(700);
    const acState = await getAutocompleteState(page);
    await page.keyboard.press('Enter');
    await waitForPageReady(page);
    const url1 = page.url();
    const ok1  = url1.includes('search') || url1.includes('query=') || url1.includes('nationwide.com');
    results.push({
      test: 'Contact Search — Autocomplete Appears',
      status: (acState.isVisible || ok1) ? 'PASSED' : 'FAILED',
      detail: `visible=${acState.isVisible} enterRedirect=${ok1}`
    });
    results.push({ test: 'Contact Search — Type + Enter Redirects', status: ok1 ? 'PASSED' : 'FAILED', detail: url1 });

    // Test 2: Back to contact page, click first suggestion
    await page.goto(
      `${config.homeUrl.replace(/\/$/,'')}/personal/contact/`,
      { waitUntil: 'domcontentloaded', timeout: 30000 }
    );
    await hardRefresh(page, 'contact-page-second-pass');
    await waitForPageReady(page);
    searchInput = await firstVisible(page, CSEL.contactSearchInput, 3000);
    if (!searchInput) {
      for (const sel of ['bolt-autocomplete >> input[data-test="input"]', 'input[aria-label="Search"]']) {
        try { const el = page.locator(sel).first(); if (await el.count() > 0) { searchInput = el; break; } } catch { /* next */ }
      }
    }
    if (searchInput) {
      await searchInput.click();
      await searchInput.clear();
      await clearAndType(searchInput, SEARCH_TERMS.autoInsurance, { delay: 80 });
      await page.waitForTimeout(800);
      const suggCount = await getSuggestionsCount(page);
      results.push({
        test: 'Contact Search — Suggestions Render',
        status: suggCount > 0 ? 'PASSED' : 'WARN',
        detail: `${suggCount} suggestions`
      });
      if (suggCount > 0) {
        await clickFirstSuggestion(page);
        await waitForPageReady(page);
        const url2 = page.url();
        results.push({
          test: 'Contact Search — Click Suggestion Redirects',
          status: url2 !== `${config.homeUrl.replace(/\/$/,'')}/personal/contact/` ? 'PASSED' : 'WARN',
          detail: url2
        });
      }
    }
  } catch (err) {
    results.push({ test: 'Contact Search — Overall', status: 'FAILED', error: err.message });
  }

  const passed = results.filter(r => r.status === 'PASSED').length;
  const total  = results.filter(r => r.status !== 'SKIPPED').length;
  console.log(`     Contact page: ${passed}/${total} passed`);
  return { device: deviceInfo.name, results, passed, total };
}

// ── Viewport runner ───────────────────────────────────────────────────────────
// ── Search Results Page test per device ──────────────────────────────────────
export async function testSrPageOnDevice(page, deviceInfo) {
  console.log(`\n   [${deviceInfo.name}] SEARCH RESULTS PAGE — Global Header Search`);
  const results = [];
  const srUrl = `${config.homeUrl.replace(/\/$/, '')}${config.searchResultsBaseUrl || '/searchresults/personal/result?=&referrerPageUrl=&query='}`;
  const srMoreValidationUrl = `${config.homeUrl.replace(/\/$/, '')}/searchresults/personal/result?query=&referrerPageUrl=`;
  const SEL = resolveSelectors(page);
  const needsIconFirst = deviceInfo.isMobile || (deviceInfo.width <= 1024);

  const findVisibleInPageOrFrame = async (selectorList = []) => {
    for (const sel of selectorList) {
      try {
        const onPage = page.locator(sel).first();
        if (await onPage.count() > 0 && await onPage.isVisible({ timeout: 1200 }).catch(() => false)) {
          return { locator: onPage, root: page, where: 'page', selector: sel };
        }
      } catch { /* next selector */ }

      try {
        const inFrame = page.frameLocator('#answers-frame').locator(sel).first();
        if (await inFrame.count() > 0 && await inFrame.isVisible({ timeout: 1200 }).catch(() => false)) {
          return { locator: inFrame, root: page.frameLocator('#answers-frame'), where: 'iframe', selector: sel };
        }
      } catch { /* next selector */ }
    }
    return null;
  };

  try {
    // Mobile-only validation for Answers Navigation "More" control
    const moreButtonSelectors = [
      '#js-answersNavigation button:has-text("More")',
      '#js-answersNavigation [role="button"]:has-text("More")',
      '#js-answersNavigation [aria-label*="more" i]',
      'button:has-text("More")',
    ];
    const answersNavListSelector = '#js-answersNavigation > nav > div > ul';
    const answersNavOptionSelector = `${answersNavListSelector} > li > a, ${answersNavListSelector} > li > button, ${answersNavListSelector} [role="button"], ${answersNavListSelector} [role="tab"], ${answersNavListSelector} a[href]`;
    const shouldShowMore = !!deviceInfo.isMobile;
    const answersNavPages = shouldShowMore
      ? [
          { label: 'base', url: srMoreValidationUrl },
          { label: 'help', url: `${srMoreValidationUrl}&verticalUrl=help.html` },
          { label: 'faqs', url: `${srMoreValidationUrl}&verticalUrl=faqs.html` },
          { label: 'products', url: `${srMoreValidationUrl}&verticalUrl=products.html` },
        ]
      : [{ label: 'base', url: srMoreValidationUrl }];

    for (const pageVariant of answersNavPages) {
      await page.goto(pageVariant.url, { waitUntil: 'domcontentloaded', timeout: 30000 });
      await hardRefresh(page, `sr-page-more-validation-${pageVariant.label}`);
      await dismissCookieBanner(page).catch(() => {});
      await waitForPageReady(page);

      const moreButton = await findVisibleInPageOrFrame(moreButtonSelectors);

      if (!shouldShowMore) {
        results.push({
          test: `[AnswersNav:${pageVariant.label}] More Button Hidden (non-mobile viewport)`,
          status: moreButton ? 'FAILED' : 'PASSED',
          detail: moreButton ? `Unexpectedly visible on ${deviceInfo.name} (${moreButton.where})` : `Not visible on ${deviceInfo.name}`
        });
        continue;
      }

      if (!moreButton) {
        results.push({
          test: `[AnswersNav:${pageVariant.label}] More Button Visible (mobile)`,
          status: 'FAILED',
          detail: `More button was not visible on ${deviceInfo.name}`
        });
        continue;
      }

      results.push({
        test: `[AnswersNav:${pageVariant.label}] More Button Visible (mobile)`,
        status: 'PASSED',
        detail: `Visible in ${moreButton.where} via ${moreButton.selector}`
      });

      const navList = moreButton.root.locator(answersNavListSelector).first();
      const isNavListVisible = async () => navList.isVisible({ timeout: 700 }).catch(() => false);

      const openNavList = async () => {
        for (let attempt = 1; attempt <= 3; attempt++) {
          const alreadyOpen = await isNavListVisible();
          if (alreadyOpen) return true;
          await moreButton.locator.click({ timeout: 3000 }).catch(() => {});
          await page.waitForTimeout(250 * attempt);
          const open = await isNavListVisible();
          if (open) return true;
        }
        return false;
      };

      const closeNavList = async () => {
        for (let attempt = 1; attempt <= 3; attempt++) {
          const currentlyOpen = await isNavListVisible();
          if (!currentlyOpen) return true;
          await moreButton.locator.click({ timeout: 3000 }).catch(() => {});
          await page.waitForTimeout(250 * attempt);
          const stillOpen = await isNavListVisible();
          if (!stillOpen) return true;
        }
        return false;
      };

      const ariaBeforeMore = await moreButton.locator.getAttribute('aria-expanded').catch(() => null);
      const opened = await openNavList();
      const ariaAfterOpenMore = await moreButton.locator.getAttribute('aria-expanded').catch(() => null);
      const closed = await closeNavList();
      const ariaAfterCloseMore = await moreButton.locator.getAttribute('aria-expanded').catch(() => null);

      const moreAriaOk = ariaBeforeMore === 'false' && ariaAfterOpenMore === 'true' && ariaAfterCloseMore === 'false';
      results.push({
        test: `[AnswersNav:${pageVariant.label}] More aria-expanded false→true→false`,
        status: moreAriaOk ? 'PASSED' : 'FAILED',
        detail: `before=${ariaBeforeMore} afterOpen=${ariaAfterOpenMore} afterClose=${ariaAfterCloseMore} closed=${closed}`
      });

      results.push({
        test: `[AnswersNav:${pageVariant.label}] More Opens #js-answersNavigation > nav > div > ul`,
        status: opened ? 'PASSED' : 'FAILED',
        detail: opened ? 'Exact overflow list became visible' : 'Exact overflow list did not become visible after clicking More'
      });

      if (!opened) continue;

      const optionsLocator = moreButton.root.locator(`${answersNavOptionSelector}:visible`);
      const optionCount = await optionsLocator.count().catch(() => 0);
      let clickableCount = 0;
      let ariaFailures = 0;

      for (let i = 0; i < optionCount; i++) {
        // Some implementations collapse the list on click; reopen before each iteration.
        await openNavList();

        const currentOptions = moreButton.root.locator(`${answersNavOptionSelector}:visible`);
        const currentCount = await currentOptions.count().catch(() => 0);
        if (i >= currentCount) break;

        const option = currentOptions.nth(i);
        clickableCount += 1;
        const label = (await option.innerText().catch(() => '')).trim().replace(/\s+/g, ' ') || `option-${i + 1}`;
        const ariaBefore = await option.getAttribute('aria-expanded').catch(() => null);

        await option.click({ timeout: 3500 }).catch(() => {});
        await page.waitForTimeout(250);

        await openNavList();
        const postOptions = moreButton.root.locator(`${answersNavOptionSelector}:visible`);
        const postOption = (await postOptions.count().catch(() => 0)) > i ? postOptions.nth(i) : option;
        const ariaAfter = await postOption.getAttribute('aria-expanded').catch(() => ariaBefore);

        const beforeOk = ariaBefore === null || ariaBefore === 'false';
        const afterOk = ariaAfter === null || ariaAfter === 'false';
        if (!beforeOk || !afterOk) {
          ariaFailures += 1;
          results.push({
            test: `[AnswersNav:${pageVariant.label}] Option ${i + 1} aria-expanded=false`,
            status: 'FAILED',
            detail: `${label} | before=${ariaBefore} after=${ariaAfter}`
          });
        } else {
          results.push({
            test: `[AnswersNav:${pageVariant.label}] Option ${i + 1} clickable + aria-expanded=false`,
            status: 'PASSED',
            detail: label
          });
        }
      }

      results.push({
        test: `[AnswersNav:${pageVariant.label}] Clicked Each Navigation Option`,
        status: clickableCount > 0 ? 'PASSED' : 'FAILED',
        detail: `clicked=${clickableCount}/${optionCount} | ariaFailures=${ariaFailures}`
      });
    }

    // Navigate back to SR URL used by the existing global-header + iframe tests.
    await page.goto(srUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await hardRefresh(page, 'sr-page-launch');
    await dismissCookieBanner(page).catch(() => {});
    await waitForPageReady(page);

    // On mobile/tablet, the global header search input is hidden behind hamburger + search icon
    if (needsIconFirst) {
      const hamburger = await firstVisible(page, SEL.hamburger, 2000);
      if (hamburger) {
        await hamburger.click();
        console.log(`   [${deviceInfo.name}] Hamburger opened`);
        await page.waitForTimeout(800);
      }
      const icon = await firstVisible(page, SEL.searchIcon, 2000);
      if (icon) {
        await icon.click();
        console.log(`   [${deviceInfo.name}] Search icon clicked`);
        await page.waitForTimeout(600);
      }
    }

    // Resolve input — try SR page selectors in order
    const srInputSelectors = SEARCH_CONTEXTS.srPageGlobalHeader.inputSelectors || [
      '#yxt-SearchBar-input--SearchBar',
      '#yxt-SearchBar-input--search-bar-1',
      '.yxt-SearchBar-input',
      'input[aria-label*="Search"]',
    ];
    let searchInput = null;
    const deadline = Date.now() + 4000;
    while (Date.now() < deadline && !searchInput) {
      for (const sel of srInputSelectors) {
        try {
          const el = page.locator(sel).first();
          if (await el.count() > 0 && await el.isVisible({ timeout: 1000 }).catch(() => false)) {
            searchInput = el;
            break;
          }
        } catch { /* next */ }
      }
      if (!searchInput) await page.waitForTimeout(300);
    }
    if (!searchInput) {
      results.push({ test: 'SR Page Search — Input Found', status: 'FAILED', error: 'SR page input not found — tried ' + srInputSelectors.join(', ') });
      return { device: deviceInfo.name, results, passed: 0, total: 1 };
    }
    results.push({ test: 'SR Page Search — Input Found', status: 'PASSED' });

    // Helper: re-open search after navigation (same hamburger → icon pattern)
    const reOpenSearch = async () => {
      searchInput = null;
      await page.evaluate(() => window.scrollTo(0, 0)).catch(() => {});
      await dismissCookieBanner(page).catch(() => {});
      if (needsIconFirst) {
        const hb = await firstVisible(page, SEL.hamburger, 2000);
        if (hb) { await hb.click(); await page.waitForTimeout(800); }
        const ic = await firstVisible(page, SEL.searchIcon, 2000);
        if (ic) { await ic.click(); await page.waitForTimeout(600); }
      }
      const d = Date.now() + 3000;
      while (Date.now() < d && !searchInput) {
        for (const sel of srInputSelectors) {
          try {
            const el = page.locator(sel).first();
            if (await el.count() > 0 && await el.isVisible({ timeout: 1000 }).catch(() => false)) { searchInput = el; break; }
          } catch { /* next */ }
        }
        if (!searchInput) await page.waitForTimeout(300);
      }
      return searchInput || page.locator(srInputSelectors[0]).first();
    };

    // Test 1: Suggestions appear for a short stem
    await searchInput.click();
    await clearAndType(searchInput, SEARCH_TERMS.stem3 || 'co', { delay: 80 });
    await page.waitForTimeout(800);
    const suggCount = await getSuggestionsCount(page);
    results.push({
      test: 'SR Page Search — Suggestions Render',
      status: suggCount > 0 ? 'PASSED' : 'WARN',
      detail: `${suggCount} suggestions for "${SEARCH_TERMS.stem3 || 'co'}"`
    });

    // Test 2: Type + Enter updates query param
    await page.keyboard.press('Escape');
    await page.waitForTimeout(300);
    await searchInput.click();
    await clearAndType(searchInput, SEARCH_TERMS.fileClaim || 'file a claim', { delay: 80 });
    await page.waitForTimeout(700);
    const urlBefore = page.url();
    await searchInput.focus();
    await searchInput.press('Enter');
    await Promise.race([
      page.waitForURL(/query=|search/i, { timeout: 8000 }),
      page.waitForTimeout(4000),
    ]).catch(() => {});
    await waitForPageReady(page, { finalBuffer: 300 });
    const urlAfter = page.url();
    const navigated = urlAfter.includes('query=') || urlAfter.includes('search') || urlAfter !== urlBefore;
    results.push({ test: 'SR Page Search — Type + Enter Navigates', status: navigated ? 'PASSED' : 'FAILED', detail: urlAfter });

    // Test 3: Return to SR page and click first suggestion
    await page.goto(srUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await waitForPageReady(page);
    await dismissCookieBanner(page).catch(() => {});
    searchInput = await reOpenSearch();
    if (searchInput) {
      await searchInput.click();
      await clearAndType(searchInput, SEARCH_TERMS.autoInsurance || 'auto insurance', { delay: 80 });
      await page.waitForTimeout(900);
      const sc2 = await getSuggestionsCount(page);
      if (sc2 > 0) {
        const urlB2 = page.url();
        let clicked = false;
        try {
          await Promise.all([
            page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 12000 }).catch(() => {}),
            clickFirstSuggestion(page).then(v => { clicked = v; }),
          ]);
        } catch { /* handled */ }
        await page.waitForTimeout(800);
        const urlA2 = page.url();
        results.push({
          test: 'SR Page Search — Click Suggestion Navigates',
          status: (clicked && (urlA2 !== urlB2 || urlA2.includes('query='))) ? 'PASSED' : 'WARN',
          detail: `clicked=${clicked} url=${urlA2.substring(0, 80)}`
        });
      } else {
        results.push({ test: 'SR Page Search — Click Suggestion Navigates', status: 'SKIPPED', detail: 'No suggestions' });
      }
    }

    // ── In-page Search Bar (inside #answers-frame iframe) ───────────────────
    // The SR page embeds a second Yext search bar inside an iframe (#answers-frame).
    // This is distinct from the Global Header bar tested above.
    console.log(`\n   [${deviceInfo.name}] SEARCH RESULTS PAGE — In-page Search Bar (#answers-frame)`);
    try {
      await page.goto(srUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
      await waitForPageReady(page);
      await dismissCookieBanner(page).catch(() => {});
      await page.waitForTimeout(2000); // allow iframe to boot

      const frameEl = await page.waitForSelector('#answers-frame', { timeout: 8000 }).catch(() => null);
      if (!frameEl) {
        results.push({ test: '[In-page Bar] Frame Found (#answers-frame)', status: 'WARN', detail: '#answers-frame not present on SR page at this viewport' });
      } else {
        results.push({ test: '[In-page Bar] Frame Found (#answers-frame)', status: 'PASSED' });
        const frame = await frameEl.contentFrame().catch(() => null);
        if (!frame) {
          results.push({ test: '[In-page Bar] Frame Accessible', status: 'WARN', detail: 'Could not access contentFrame — cross-origin or not loaded' });
        } else {
          results.push({ test: '[In-page Bar] Frame Accessible', status: 'PASSED' });
          const frameRoot = page.frameLocator('#answers-frame');

          // Resolve in-page input inside iframe
          const inPageSelectors = SEARCH_CONTEXTS.srPageSearchBar.inputSelectors;
          let inPageInput = null;
          for (const sel of inPageSelectors) {
            try {
              const el = frameRoot.locator(sel).first();
              if (await el.count() > 0 && await el.isVisible({ timeout: 2000 }).catch(() => false)) {
                inPageInput = el;
                break;
              }
            } catch { /* next */ }
          }
          // Generic fallback inside iframe
          if (!inPageInput) {
            const fb = frameRoot.locator('input[aria-autocomplete="list"], input.js-yext-query, input[type="search"]').first();
            if (await fb.count() > 0 && await fb.isVisible({ timeout: 2000 }).catch(() => false)) inPageInput = fb;
          }

          if (!inPageInput) {
            results.push({ test: '[In-page Bar] Input Found', status: 'WARN', detail: 'In-page search input not found inside #answers-frame' });
          } else {
            results.push({ test: '[In-page Bar] Input Found', status: 'PASSED' });

            // Test: suggestions render in iframe
            await inPageInput.click().catch(() => {});
            await inPageInput.pressSequentially(SEARCH_TERMS.stem3 || 'co', { delay: 80 }).catch(() => {});
            await page.waitForTimeout(800);
            const iframeSuggCount = await frame.evaluate(() => {
              const sels = ['[role="option"]', '.yxt-SearchBar-suggestion', '[role="listbox"] [role="option"]'];
              const found = new Set();
              for (const s of sels) for (const n of document.querySelectorAll(s)) found.add(n);
              return found.size;
            }).catch(() => 0);
            results.push({
              test: '[In-page Bar] Suggestions Render',
              status: iframeSuggCount > 0 ? 'PASSED' : 'WARN',
              detail: `${iframeSuggCount} suggestions for "${SEARCH_TERMS.stem3 || 'co'}" inside iframe`
            });

            // Test: Type + Enter navigates
            await page.keyboard.press('Escape').catch(() => {});
            await page.waitForTimeout(200);
            await inPageInput.click().catch(() => {});
            await inPageInput.pressSequentially(SEARCH_TERMS.fileClaim || 'file a claim', { delay: 80 }).catch(() => {});
            await page.waitForTimeout(600);
            const urlBeforeIframe = page.url();
            await inPageInput.press('Enter').catch(() => {});
            await Promise.race([
              page.waitForURL(/query=|search/i, { timeout: 8000 }),
              page.waitForTimeout(4000),
            ]).catch(() => {});
            const urlAfterIframe = page.url();
            const iframeNavigated = urlAfterIframe.includes('query=') || urlAfterIframe.includes('search') || urlAfterIframe !== urlBeforeIframe;
            results.push({
              test: '[In-page Bar] Type + Enter Navigates',
              status: iframeNavigated ? 'PASSED' : 'WARN',
              detail: `url=${urlAfterIframe.substring(0, 80)}`
            });
          }
        }
      }
    } catch (iframeErr) {
      console.log(`   [${deviceInfo.name}] In-page bar tests error: ${trunc(iframeErr.message)}`);
      results.push({ test: '[In-page Bar] Overall', status: 'WARN', detail: trunc(iframeErr.message) });
    }

  } catch (err) {
    results.push({ test: 'SR Page Search — Overall', status: 'FAILED', error: trunc(err.message) });
  }

  const passed = results.filter(r => r.status === 'PASSED').length;
  const total  = results.filter(r => r.status !== 'SKIPPED').length;
  console.log(`     SR page: ${passed}/${total} passed`);
  return { device: deviceInfo.name, results, passed, total };
}

// ── 5-device SR-page runner ────────────────────────────────────────────────────
export async function testMobileSrPageViewports(context) {
  console.log('\n' + '='.repeat(60));
  console.log(' MOBILE/TABLET — SEARCH RESULTS PAGE TESTING');
  console.log('='.repeat(60));

  const devices = [
    { name: 'iPhone SE',       width: 375,  height: 667,  isMobile: true  },
    { name: 'iPhone 12/13',    width: 390,  height: 844,  isMobile: true  },
    { name: 'Android Pixel',   width: 360,  height: 800,  isMobile: true  },
    { name: 'iPad Portrait',   width: 768,  height: 1024, isMobile: false },
    { name: 'iPad Landscape',  width: 1024, height: 768,  isMobile: false },
  ];

  const allResults = [];
  const browser = context.browser();

  for (const device of devices) {
    console.log(`\n   Testing SR Page: ${device.name}`);
    const mobileCtx = await browser.newContext({
      viewport:         { width: device.width, height: device.height },
      hasTouch:         device.isMobile,
      isMobile:         device.isMobile,
      userAgent: device.isMobile
        ? 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1'
        : config.headers['User-Agent'],
      extraHTTPHeaders: config.headers,
    });
    const mobilePage = await mobileCtx.newPage();
    registerCookieAutoDismiss(mobilePage);

    try {
      const deviceResults = await testSrPageOnDevice(mobilePage, device);
      allResults.push(deviceResults);
    } catch (error) {
      console.log(`      Failed: ${trunc(error.message)}`);
      allResults.push({ device: device.name, status: 'FAILED', error: error.message });
    } finally {
      await mobilePage.close().catch(() => {});
      await mobileCtx.close().catch(() => {});
      await new Promise(r => setTimeout(r, 500));
    }
  }

  return allResults;
}

export async function testMobileViewports(context) {
  console.log('\n' + '='.repeat(60));
  console.log(' MOBILE/TABLET VIEWPORT TESTING');
  console.log('='.repeat(60));

  const devices = [
    { name: 'iPhone SE',       width: 375,  height: 667,  isMobile: true  },
    { name: 'iPhone 12/13',    width: 390,  height: 844,  isMobile: true  },
    { name: 'Android Pixel',   width: 360,  height: 800,  isMobile: true  },
    { name: 'iPad Portrait',   width: 768,  height: 1024, isMobile: false },
    { name: 'iPad Landscape',  width: 1024, height: 768,  isMobile: false },
  ];

  const allResults = [];
  const browser = context.browser();

  for (const device of devices) {
    console.log(`\n   Testing: ${device.name}`);
    const mobileCtx = await browser.newContext({
      viewport:         { width: device.width, height: device.height },
      hasTouch:         device.isMobile,
      isMobile:         device.isMobile,
      userAgent: device.isMobile
        ? 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1'
        : config.headers['User-Agent'],
      extraHTTPHeaders: config.headers
    });
    const mobilePage = await mobileCtx.newPage();
    registerCookieAutoDismiss(mobilePage);

    try {
      await mobilePage.goto(config.homeUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
      await hardRefresh(mobilePage, `${device.name}-initial-launch`);
      await dismissCookieBanner(mobilePage);
      await waitForPageReady(mobilePage);

      const deviceResults = await testMobileSearchOnDevice(mobilePage, device);
      // Also validate Contact Page search on every device (mobile + tablet)
      const contactResults = await testContactPageOnDevice(mobilePage, device);
      // Merge: prefix contact results with "[Contact]" to distinguish in report
      const mergedResults = [
        ...deviceResults.results,
        ...contactResults.results.map(r => ({ ...r, test: `[Contact] ${r.test}` }))
      ];
      allResults.push({
        ...deviceResults,
        results: mergedResults,
        passed: mergedResults.filter(r => r.status === 'PASSED').length,
        total:  mergedResults.filter(r => r.status !== 'SKIPPED').length,
      });

      const hasHScroll = await mobilePage.evaluate(() =>
        document.documentElement.scrollWidth > document.documentElement.clientWidth
      );
      console.log(`     Horizontal overflow: ${hasHScroll ? 'YES (WARNING)' : 'none'}`);

      await mobilePage.screenshot({
        path: path.join(SCREENSHOTS_DIR, `mobile-${device.name.replace(/\s/g, '-')}.png`)
      });
    } catch (error) {
      console.log(`      Failed: ${trunc(error.message)}`);
      allResults.push({ device: device.name, status: 'FAILED', error: error.message });
    } finally {
      await mobilePage.close().catch(() => {});
      await mobileCtx.close().catch(() => {});
      await new Promise(r => setTimeout(r, 500));
    }
  }

  return allResults;
}
