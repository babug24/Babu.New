/**
 * tests/elements.js
 * ElementPresenceValidator — validates DOM presence, shadow DOM, bolt-components,
 * alignment, ARIA, and interactability of page elements.
 */

import { config, trunc, SEARCH_TERMS } from '../core/config.js';
import { waitForPageReady, dismissCookieBanner, findAndActivateSearch, clearAndType } from '../utils/helpers.js';
import { SELECTORS, getSelectors, firstVisible, resolveSelectors } from '../utils/selectors.js';
import { getAutocompleteState } from '../utils/autocomplete.js';

export class ElementPresenceValidator {
  constructor(page) {
    this.page    = page;
    this.results = [];
  }

  // 1. Standard element presence + visibility
  async validateElement(selector, description, required = true) {
    console.log(`\n   Validating: ${description}`);
    try {
      const el      = this.page.locator(selector).first();
      const present = await el.count() > 0;
      if (required && !present) throw new Error(`Element not found: ${selector}`);
      if (present) {
        const visible = await el.isVisible().catch(() => false);
        console.log(`     Present: ${present} | Visible: ${visible} [${selector}]`);
        this.results.push({ description, status: visible ? 'PASSED' : 'FAILED',
          detail: `present=true, visible=${visible}` });
        return;
      }
      this.results.push({ description, status: 'FAILED', error: 'Not found in DOM' });
    } catch (error) {
      console.log(`      Error: ${trunc(error.message)}`);
      this.results.push({ description, status: 'FAILED', error: error.message });
      if (required) throw error;
    }
  }

  // 2. Text content validation
  async validateTextContent(selector, description, expectedText, required = false) {
    console.log(`\n   Validating text: ${description}`);
    try {
      const el = this.page.locator(selector).first();
      if (await el.count() === 0) {
        this.results.push({ description, status: required ? 'FAILED' : 'SKIPPED', error: 'Element not found' });
        return;
      }
      const text    = (await el.textContent().catch(() => '')).trim();
      const matches = text.toLowerCase().includes(expectedText.toLowerCase());
      console.log(`     Contains "${expectedText}": ${matches} | text: "${text.substring(0, 70)}"`);
      this.results.push({ description, status: matches ? 'PASSED' : 'FAILED',
        detail: `expected="${expectedText}" | found="${text.substring(0, 100)}"` });
    } catch (error) {
      this.results.push({ description, status: 'FAILED', error: error.message });
    }
  }

  // 3. Shadow DOM element (3-strategy)
  async validateShadowDomElement(selector, description, required = false) {
    console.log(`\n   Validating Shadow DOM: ${description}`);
    try {
      // Strategy A: Playwright native
      const el = this.page.locator(selector).first();
      if (await el.count() > 0) {
        const visible = await el.isVisible().catch(() => false);
        this.results.push({ description, status: 'PASSED', detail: `strategy=playwright, visible=${visible}` });
        return;
      }
      // Strategy B: JS shadow walk
      const found = await this.page.evaluate(sel => {
        const direct = document.querySelector(sel);
        if (direct) return { found: true, path: 'direct' };
        const walk = (root, depth = 0) => {
          if (depth > 10) return null;
          for (const el of root.querySelectorAll('*')) {
            try { if (el.matches?.(sel)) return { found: true, path: `shadow-depth-${depth}` }; } catch {}
            if (el.shadowRoot) { const r = walk(el.shadowRoot, depth + 1); if (r) return r; }
          }
          return null;
        };
        return walk(document.body) || { found: false };
      }, selector).catch(() => ({ found: false }));

      console.log(`     JS shadow walk: ${found.found ? found.path : 'not found'}`);
      this.results.push({ description, status: found.found ? 'PASSED' : 'FAILED',
        detail: found.found ? `strategy=js-shadow(${found.path})` : 'not found in any shadow root' });
      if (required && !found.found) throw new Error(`Shadow DOM element not found: ${selector}`);
    } catch (error) {
      this.results.push({ description, status: 'FAILED', error: error.message });
      if (required) throw error;
    }
  }

  // 4. bolt-button validation
  async validateBoltButton(iconName, description, required = false) {
    console.log(`\n   Validating bolt-button[iconleft="${iconName}"]: ${description}`);
    const hostSel = `bolt-button[iconleft="${iconName}"]`;
    try {
      const host      = this.page.locator(hostSel).first();
      const present   = await host.count() > 0;
      if (!present) {
        this.results.push({ description, status: 'FAILED', error: `Host not found: ${hostSel}` });
        return;
      }
      const visible  = await host.isVisible().catch(() => false);
      const iconAttr = await host.getAttribute('iconleft').catch(() => null);
      const attrOk   = iconAttr === iconName;
      const innerIcon = await this.page.evaluate(({ hSel, iName }) => {
        const h = document.querySelector(hSel);
        if (!h?.shadowRoot) return { found: false };
        const ic = h.shadowRoot.querySelector('bolt-icon,[class*="icon"]');
        return { found: !!ic, tag: ic?.tagName, name: ic?.getAttribute('name') };
      }, { hSel: hostSel, iName: iconName }).catch(() => ({ found: false }));

      console.log(`     Present: ${present} | Visible: ${visible} | attr ok: ${attrOk} | inner icon: ${innerIcon.found}`);
      this.results.push({ description, status: (present && visible && attrOk) ? 'PASSED' : 'FAILED',
        detail: `present=${present}, visible=${visible}, attrOk=${attrOk}, innerIcon=${innerIcon.found}` });
    } catch (error) {
      this.results.push({ description, status: 'FAILED', error: error.message });
    }
  }

  // 5. Center alignment check
  async validateCenterAlignment(selector, description, required = false) {
    console.log(`\n   Validating center alignment: ${description}`);
    try {
      let element = null;
      for (const s of selector.split(',').map(s => s.trim())) {
        const el = this.page.locator(s).first();
        if (await el.count() > 0) { element = el; break; }
      }
      if (!element) {
        this.results.push({ description, status: 'FAILED', error: 'Element not found' }); return;
      }
      const m = await element.evaluate(el => {
        const st = window.getComputedStyle(el);
        const r  = el.getBoundingClientRect();
        return {
          textAlign: st.textAlign, justifyContent: st.justifyContent,
          marginLeft: st.marginLeft, marginRight: st.marginRight,
          geoCentered: Math.abs((r.left + r.right) / 2 - window.innerWidth / 2) < 20,
          parentTextAlign: el.parentElement ? window.getComputedStyle(el.parentElement).textAlign : 'n/a'
        };
      }).catch(() => null);
      if (!m) { this.results.push({ description, status: 'FAILED', error: 'Could not compute styles' }); return; }
      const centered = m.textAlign === 'center' || m.justifyContent === 'center' ||
                       (m.marginLeft === 'auto' && m.marginRight === 'auto') ||
                       m.parentTextAlign === 'center' || m.geoCentered;
      console.log(`     Centered: ${centered} (textAlign=${m.textAlign}, geo=${m.geoCentered})`);
      this.results.push({ description, status: centered ? 'PASSED' : 'FAILED',
        detail: `textAlign=${m.textAlign}, justify=${m.justifyContent}, marginAuto=${m.marginLeft==='auto'}, geo=${m.geoCentered}` });
    } catch (error) {
      this.results.push({ description, status: 'FAILED', error: error.message });
    }
  }

  // 6. ARIA attribute validation
  async validateAriaAttribute(selector, description, attrName, expectedValue, required = false) {
    console.log(`\n   Validating ARIA [${attrName}]: ${description}`);
    try {
      const el = this.page.locator(selector).first();
      if (await el.count() === 0) {
        this.results.push({ description, status: required ? 'FAILED' : 'SKIPPED', error: 'Element not found' }); return;
      }
      const actual  = await el.getAttribute(attrName).catch(() => null);
      const matches = actual === expectedValue;
      console.log(`     ${attrName}="${actual}" expected="${expectedValue}" matches=${matches}`);
      this.results.push({ description, status: matches ? 'PASSED' : 'FAILED', detail: `${attrName}="${actual}"` });
    } catch (error) {
      this.results.push({ description, status: 'FAILED', error: error.message });
    }
  }

  // 7. Interactability: visible + enabled + not aria-disabled
  async validateInteractable(selector, description, required = false) {
    console.log(`\n   Validating interactable: ${description}`);
    try {
      const el = this.page.locator(selector).first();
      if (await el.count() === 0) {
        this.results.push({ description, status: required ? 'FAILED' : 'SKIPPED', error: 'Element not found' }); return;
      }
      const [visible, enabled, ariaDisabled] = await Promise.all([
        el.isVisible().catch(() => false),
        el.isEnabled().catch(() => false),
        el.getAttribute('aria-disabled').catch(() => null)
      ]);
      const ok = visible && enabled && ariaDisabled !== 'true';
      console.log(`     Visible: ${visible} | Enabled: ${enabled} | aria-disabled: ${ariaDisabled ?? 'not set'} | OK: ${ok}`);
      this.results.push({ description, status: ok ? 'PASSED' : 'FAILED',
        detail: `visible=${visible}, enabled=${enabled}, aria-disabled=${ariaDisabled ?? 'not set'}` });
    } catch (error) {
      this.results.push({ description, status: 'FAILED', error: error.message });
    }
  }

  getValidationSummary() {
    const passed  = this.results.filter(r => r.status === 'PASSED').length;
    const failed  = this.results.filter(r => r.status === 'FAILED').length;
    const skipped = this.results.filter(r => r.status === 'SKIPPED').length;
    console.log(`\n   Element Validation: ${passed} passed, ${failed} failed, ${skipped} skipped`);
    return { total: this.results.length, passed, failed, skipped, results: this.results };
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Submit Button Test  (AC-30)
// Validates the search submit / form button for both search components.
// Env-aware: auto-picks the right selector map based on the active page URL.
//
// options.component : 'global' | 'contact'
// options.pageUrl   : URL to navigate to (optional)
// ─────────────────────────────────────────────────────────────────────────────
export async function testSubmitButton(page, options = {}) {
  const component = options.component || 'global';
  const label     = component === 'contact'        ? 'Contact Page Search'
                  : component === 'results'         ? 'Search Results Page Search'
                  : component === 'results-header'  ? 'Search Results Page — Global Header Search'
                  : 'Global Header Search';

  console.log(`\n${'='.repeat(60)}`);
  console.log(` SUBMIT BUTTON (AC-30) — ${label.toUpperCase()}`);
  console.log('='.repeat(60));

  const results = [];

  // ── Navigate if URL provided ────────────────────────────────────────────────
  if (options.pageUrl) {
    await page.goto(options.pageUrl, { waitUntil: 'domcontentloaded', timeout: 40000 });
    await dismissCookieBanner(page).catch(() => {});
    await waitForPageReady(page, { networkTimeout: 5000 });
  }

  // ── Resolve correct selectors for current env ─────────────────────────────
  const SEL      = resolveSelectors(page);
  // 'results' uses the dedicated Search Results page Yext search bar
  const btnSels  = component === 'contact'       ? SEL.contactSubmitButton
                 : component === 'results'        ? SEL.searchResultsSubmitButton
                 : component === 'results-header' ? (SEL.searchResultsGlobalHeaderSubmitButton || SEL.globalSubmitButton)
                 : SEL.globalSubmitButton;
  const inpSels  = component === 'contact'       ? SEL.contactSearchInput
                 : component === 'results'        ? SEL.searchResultsInput
                 : component === 'results-header' ? (SEL.searchResultsGlobalHeaderInput || SEL.searchInput)
                 : SEL.searchInput;
  const envLabel = page.url().includes('uat-ng') ? 'Angular' : 'Prod';
  console.log(`   Env detected: ${envLabel}`);

  // ── AC-30a: Submit button present and visible ─────────────────────────────
  console.log('\n   AC-30a: Submit button is present and visible');
  let submitBtn = null;
  try {
    // Activate search first so the submit button becomes visible
    if (component === 'global') {
      // Global header: click search icon to open the search bar
      const icon = await firstVisible(page, SEL.searchIcon, 2000);
      if (icon) { await icon.click(); await page.waitForTimeout(600); }
    }
    // Note: for component === 'results' / 'results-header' the submit button is
    // already visible on page load — no activation step required.
    submitBtn = await firstVisible(page, btnSels, 3000);
    const present = !!submitBtn;
    console.log(`     Submit btn found: ${present}`);
    results.push({
      test:   `AC-30a Submit btn present — ${label} [${envLabel}]`,
      status: present ? 'PASSED' : 'WARN',
      detail: `tried ${btnSels.length} selectors`,
    });
  } catch (err) {
    results.push({ test: `AC-30a Submit btn present — ${label} [${envLabel}]`, status: 'FAILED', error: trunc(err.message) });
  }

  // ── AC-30b: Submit button is enabled (not disabled) ──────────────────────
  console.log('\n   AC-30b: Submit button is enabled');
  try {
    if (!submitBtn) {
      results.push({ test: `AC-30b Submit btn enabled — ${label} [${envLabel}]`, status: 'SKIPPED', detail: 'btn not found' });
    } else {
      const enabled      = await submitBtn.isEnabled().catch(() => false);
      const ariaDisabled = await submitBtn.getAttribute('aria-disabled').catch(() => null);
      const ok           = enabled && ariaDisabled !== 'true';
      console.log(`     enabled=${enabled} aria-disabled=${ariaDisabled}`);
      results.push({
        test:   `AC-30b Submit btn enabled — ${label} [${envLabel}]`,
        status: ok ? 'PASSED' : 'FAILED',
        detail: `enabled=${enabled} aria-disabled=${ariaDisabled ?? 'not set'}`,
      });
    }
  } catch (err) {
    results.push({ test: `AC-30b Submit btn enabled — ${label} [${envLabel}]`, status: 'FAILED', error: trunc(err.message) });
  }

  // ── AC-30c: Clicking submit button with a query navigates to results ───────
  console.log('\n   AC-30c: Click submit button triggers search navigation');
  try {
    const inp = await firstVisible(page, inpSels, 4000);
    if (!inp) {
      results.push({ test: `AC-30c Submit btn click navigates — ${label} [${envLabel}]`, status: 'SKIPPED', detail: 'input not found' });
    } else {
      await inp.click();
      await inp.clear();
      await clearAndType(inp, SEARCH_TERMS.autoInsurance, { delay: 70 });
      await page.waitForTimeout(600);
      // Re-resolve submit button after typing (Angular may show it only after input)
      if (!submitBtn) submitBtn = await firstVisible(page, btnSels, 2000);
      if (submitBtn) {
        const urlBefore = page.url();

        // Detect whether submitBtn is a bolt-button host (Angular) and pierce to inner button
        const tag = await submitBtn.evaluate(el => el.tagName.toLowerCase()).catch(() => '');
        if (tag === 'bolt-button') {
          // Click the inner shadow-DOM button directly for Angular bolt-button
          await submitBtn.evaluate(el => {
            const inner = el.shadowRoot?.querySelector('button');
            if (inner) inner.click();
          }).catch(() => submitBtn.click());
        } else {
          await submitBtn.click();
        }

        await page.waitForTimeout(3000);
        const urlAfter   = page.url();
        const navigated  = urlAfter !== urlBefore;

        // For Search Results page: verify URL follows /searchresults/personal/result?query= pattern
        const resultsUrlPattern = config.searchResultsPath || '/searchresults/personal/result';
        const onSearchResultsPage = urlAfter.includes(resultsUrlPattern) && urlAfter.includes('query=');
        const onResults  = component === 'results'
          ? onSearchResultsPage
          : urlAfter.includes('query=') || urlAfter.includes('search') ||
            urlAfter.includes('/result') || navigated;

        // Also check for inline results rendered on the same page (Angular SPA pattern)
        const inlineResults = await page.locator(
          '[class*="result"], [class*="search-result"], bolt-card, .HitchhikerResultsStandard-Card, [data-type="result"]'
        ).count().catch(() => 0);

        const btnTagUsed = `btn-tag=${tag || 'unknown'}`;
        let reason;
        if (component === 'results') {
          reason = onSearchResultsPage
            ? `URL navigated to Search Results page — path and query confirmed (${resultsUrlPattern}?query=)`
            : navigated
              ? `URL changed but did not match expected pattern ${resultsUrlPattern}?query= — got: ${urlAfter}`
              : 'URL unchanged — submit did not trigger navigation to Search Results page';
        } else {
          reason = !navigated && !onResults && inlineResults === 0
            ? 'URL unchanged and no inline results found — click may have landed on bolt-button host shell (shadow DOM not pierced), or Angular search renders results in a panel not detected by current selectors'
            : navigated
              ? 'URL changed — navigation confirmed'
              : `URL unchanged but ${inlineResults} inline result element(s) found — Angular SPA renders results in-page without URL change`;
        }

        console.log(`     URL before: ${urlBefore}`);
        console.log(`     URL after : ${urlAfter}`);
        console.log(`     navigated=${navigated} onResults=${onResults}${component === 'results' ? ` onSearchResultsPage=${onSearchResultsPage}` : ''} inlineResults=${inlineResults} ${btnTagUsed}`);
        results.push({
          test:   `AC-30c Submit btn click navigates — ${label} [${envLabel}]`,
          status: (onResults || (component !== 'results' && inlineResults > 0)) ? 'PASSED' : 'WARN',
          detail: `navigated=${navigated} urlBefore=${urlBefore} urlAfter=${urlAfter}${component === 'results' ? ` onSearchResultsPage=${onSearchResultsPage}` : ''} inlineResults=${inlineResults} ${btnTagUsed} — ${reason}`,
        });
      } else {
        // Fallback: submit via Enter key
        await page.keyboard.press('Enter');
        await page.waitForTimeout(3000);
        const urlAfter = page.url();
        const navigated = urlAfter !== options.pageUrl;
        results.push({
          test:   `AC-30c Submit btn click navigates — ${label} [${envLabel}]`,
          status: 'WARN',
          detail: `Submit btn not visible after typing — fell back to Enter key. navigated=${navigated} url=${urlAfter}. Root cause: ${label} submit button selectors did not match a visible element; button may require input focus-activation first.`,
        });
      }
    }
  } catch (err) {
    results.push({ test: `AC-30c Submit btn click navigates — ${label} [${envLabel}]`, status: 'FAILED', error: trunc(err.message) });
  }

  // ── AC-30d: Submit button has accessible label ────────────────────────────
  console.log('\n   AC-30d: Submit button has aria-label or title');
  try {
    // Navigate back to original page if we left it
    if (options.pageUrl && !page.url().includes(new URL(options.pageUrl).pathname)) {
      await page.goto(options.pageUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
      await waitForPageReady(page);
    }
    submitBtn = await firstVisible(page, btnSels, 3000);
    if (!submitBtn) {
      if (component === 'global') {
        const icon2 = await firstVisible(page, SEL.searchIcon, 2000);
        if (icon2) { await icon2.click(); await page.waitForTimeout(600); }
        submitBtn = await firstVisible(page, btnSels, 2000);
      }
    }
    if (!submitBtn) {
      results.push({ test: `AC-30d Submit btn a11y label — ${label} [${envLabel}]`, status: 'SKIPPED', detail: 'btn not found' });
    } else {
      const ariaLabel = await submitBtn.getAttribute('aria-label').catch(() => null);
      const title     = await submitBtn.getAttribute('title').catch(() => null);
      const innerTxt  = (await submitBtn.textContent().catch(() => '')).trim();

      const innerA11y = await submitBtn.evaluate(el => {
        const hostTag = el.tagName.toLowerCase();
        if (hostTag !== 'bolt-button') {
          return { shadowAriaLabel: null, shadowTitle: null, shadowText: '' };
        }
        const innerBtn = el.shadowRoot?.querySelector('button');
        if (!innerBtn) {
          return { shadowAriaLabel: null, shadowTitle: null, shadowText: '' };
        }
        return {
          shadowAriaLabel: innerBtn.getAttribute('aria-label'),
          shadowTitle: innerBtn.getAttribute('title'),
          shadowText: (innerBtn.textContent || '').trim(),
        };
      }).catch(() => ({ shadowAriaLabel: null, shadowTitle: null, shadowText: '' }));

      const hasLabel  =
        !!ariaLabel ||
        !!title ||
        innerTxt.length > 0 ||
        !!innerA11y.shadowAriaLabel ||
        !!innerA11y.shadowTitle ||
        String(innerA11y.shadowText || '').length > 0;

      console.log(
        `     aria-label="${ariaLabel}" title="${title}" text="${innerTxt}" ` +
        `shadow-aria-label="${innerA11y.shadowAriaLabel}" shadow-title="${innerA11y.shadowTitle}" shadow-text="${innerA11y.shadowText}"`
      );
      results.push({
        test:   `AC-30d Submit btn a11y label — ${label} [${envLabel}]`,
        status: hasLabel ? 'PASSED' : 'FAILED',
        detail: `aria-label="${ariaLabel}" title="${title}" text="${innerTxt}" shadow-aria-label="${innerA11y.shadowAriaLabel}" shadow-title="${innerA11y.shadowTitle}" shadow-text="${innerA11y.shadowText}" — button has no accessible label (a11y failure)`,
      });
    }
  } catch (err) {
    results.push({ test: `AC-30d Submit btn a11y label — ${label} [${envLabel}]`, status: 'FAILED', error: trunc(err.message) });
  }

  const passed  = results.filter(r => r.status === 'PASSED').length;
  const warned  = results.filter(r => r.status === 'WARN').length;
  const skipped = results.filter(r => r.status === 'SKIPPED').length;
  console.log(`\n   Submit Button [${label}]: ${passed} passed | ${warned} warn | ${skipped} skipped`);
  return { device: label, results, passed, total: results.length };
}

// ─────────────────────────────────────────────────────────────────────────────
// Visual Presence Validation
// Validates the search UI in its DEFAULT state (no interaction required) across
// all 5 coverage areas:
//   VP-01  Element visibility    — input, wrapper, submit btn present + visible
//   VP-02  Default UI state      — input empty, placeholder present, no dropdown
//   VP-03  Layout alignment      — search bar is horizontally centred / aligned
//   VP-04  Classes / styling     — expected CSS classes attached to key elements
//   VP-05  A11y visual state     — aria-expanded=false & listbox hidden on load
//
// options.component : 'global' | 'contact'
// options.pageUrl   : URL to navigate to (optional)
// ─────────────────────────────────────────────────────────────────────────────
export async function testVisualPresence(page, options = {}) {
  const component = options.component || 'global';
  const label     = component === 'contact'        ? 'Contact Page Search'
                  : component === 'results'         ? 'Search Results Page Search'
                  : component === 'results-header'  ? 'Search Results Page — Global Header Search'
                  : 'Global Header Search';

  console.log(`\n${'='.repeat(60)}`);
  console.log(` VISUAL PRESENCE VALIDATION — ${label.toUpperCase()}`);
  console.log('='.repeat(60));

  if (options.pageUrl) {
    await page.goto(options.pageUrl, { waitUntil: 'domcontentloaded', timeout: 40000 });
    await dismissCookieBanner(page).catch(() => {});
    await waitForPageReady(page, { networkTimeout: 5000 });
  }

  const SEL     = resolveSelectors ? resolveSelectors(page) : SELECTORS;
  const v       = new ElementPresenceValidator(page);
  const results = [];

  const run = async (id, name, fn) => {
    console.log(`\n   ${id}: ${name}`);
    try {
      const r = await fn();
      results.push({ test: `${id} ${name} — ${label}`, ...r });
      console.log(`     → ${r.status}${r.detail ? '  ' + r.detail : ''}`);
    } catch (err) {
      results.push({ test: `${id} ${name} — ${label}`, status: 'FAILED', error: trunc(err.message) });
      console.log(`     → FAILED  ${trunc(err.message)}`);
    }
  };

  // ── Resolve input selector for this component ──────────────────────────────
  // 'results' uses the dedicated Search Results page Yext search bar
  const inputSels = component === 'contact'       ? SEL.contactSearchInput
                  : component === 'results'        ? SEL.searchResultsInput
                  : component === 'results-header' ? (SEL.searchResultsGlobalHeaderInput || SEL.searchInput)
                  : SEL.searchInput;

  const getInputEl = () => firstVisible(page, inputSels, 5000);

  // ══ VP-01 — ELEMENT VISIBILITY ════════════════════════════════════════════
  // VP-01a: Search input is in the DOM and visible
  await run('VP-01a', 'Search input present & visible', async () => {
    const inp = await getInputEl();
    if (!inp) return { status: 'FAILED', detail: 'input not found' };
    const visible = await inp.isVisible().catch(() => false);
    return { status: visible ? 'PASSED' : 'FAILED', detail: `visible=${visible}` };
  });

  // VP-01b: Search wrapper / container is visible
  await run('VP-01b', 'Search wrapper / container visible', async () => {
    const wrapSels = [
      // Angular (bolt-component stack)
      'bolt-autocomplete',                          // Angular global header host (uat-ng)
      '#search > bolt-autocomplete',                // Angular — scoped to header slot
      'div[id="search"] bolt-autocomplete',
      'bolt-autocomplete-wc',                       // bolt WC variant
      // Prod (Yext)
      '.yxt-SearchBar-wrapper', '.ch-searchbar', 'form[role="search"]',
      '[class*="SearchBar"]', '[class*="search-wrapper"]',
      // Generic
      'nw-help-center-search', '.nw-help-center-search',
    ];
    for (const s of wrapSels) {
      try {
        const el = page.locator(s).first();
        if (await el.count() > 0 && await el.isVisible({ timeout: 2000 }).catch(() => false)) {
          return { status: 'PASSED', detail: `selector="${s}" visible=true` };
        }
      } catch { /* next */ }
    }
    return { status: 'WARN', detail: 'No common wrapper selector matched — may use custom component' };
  });

  // VP-01c: Submit button is present and visible (before any interaction)
  await run('VP-01c', 'Submit button present & visible', async () => {
    const btnSels = component === 'contact'       ? SEL.contactSubmitButton
                  : component === 'results'        ? SEL.searchResultsSubmitButton
                  : component === 'results-header' ? (SEL.searchResultsGlobalHeaderSubmitButton || SEL.globalSubmitButton)
                  : SEL.globalSubmitButton;
    const sels    = Array.isArray(btnSels) ? btnSels : [btnSels];
    for (const s of sels) {
      try {
        const el = page.locator(s).first();
        if (await el.count() > 0 && await el.isVisible({ timeout: 2000 }).catch(() => false)) {
          return { status: 'PASSED', detail: `selector="${s}" visible=true` };
        }
      } catch { /* next — skip broken selectors */ }
    }
    // Fallback: any button inside a search form (Prod)
    const formFallback = page.locator('form button[type="submit"], form button.yxt-SearchBar-button').first();
    if (await formFallback.count() > 0 && await formFallback.isVisible({ timeout: 1000 }).catch(() => false)) {
      return { status: 'PASSED', detail: 'submit button found via form fallback' };
    }
    // Angular fallback: bolt-autocomplete submit button may only appear after input gets focus.
    // Focus the input, then re-check the shadow-DOM button selectors.
    try {
      const inputEl = await findAndActivateSearch(page, false);
      if (inputEl) {
        await inputEl.fill('a').catch(() => {});
        await page.waitForTimeout(400);
        for (const s of sels) {
          try {
            const el = page.locator(s).first();
            if (await el.count() > 0 && await el.isVisible({ timeout: 1500 }).catch(() => false)) {
              return { status: 'PASSED', detail: `selector="${s}" visible=true (revealed after focus)` };
            }
          } catch { /* next */ }
        }
        // Also check any bolt-button or shadow button in the header
        for (const s of ['bolt-autocomplete >> button', '#search button', 'header button[aria-label*="search" i]', 'header button[aria-label*="submit" i]']) {
          try {
            const el = page.locator(s).first();
            if (await el.count() > 0 && await el.isVisible({ timeout: 1000 }).catch(() => false)) {
              return { status: 'PASSED', detail: `selector="${s}" visible=true (focus fallback)` };
            }
          } catch { /* next */ }
        }
      }
    } catch { /* focus fallback failed — fall through to WARN */ }
    return { status: 'WARN', detail: 'Submit button not found — may be icon-only or hidden until focus' };
  });

  // VP-01d: Page header / nav is rendered (site-level check)
  await run('VP-01d', 'Page header rendered', async () => {
    const headerSels = ['bolt-header', '#header', 'header', '[role="banner"]'];
    for (const s of headerSels) {
      const el = page.locator(s).first();
      if (await el.count() > 0 && await el.isVisible({ timeout: 2000 }).catch(() => false)) {
        return { status: 'PASSED', detail: `selector="${s}"` };
      }
    }
    return { status: 'WARN', detail: 'Header not matched by common selectors' };
  });

  // ══ VP-02 — DEFAULT UI STATE ══════════════════════════════════════════════
  // VP-02a: Input is empty on page load (no pre-filled value)
  await run('VP-02a', 'Input is empty by default', async () => {
    const inp = await getInputEl();
    if (!inp) return { status: 'SKIPPED', detail: 'input not found' };
    const val = await inp.inputValue().catch(() => '');
    return { status: val === '' ? 'PASSED' : 'WARN', detail: `value="${val}"` };
  });

  // VP-02b: Input has a placeholder text hint
  await run('VP-02b', 'Input has placeholder text', async () => {
    const inp = await getInputEl();
    if (!inp) return { status: 'SKIPPED', detail: 'input not found' };
    const ph = await inp.getAttribute('placeholder').catch(() => null);
    const hasPlaceholder = ph && ph.trim().length > 0;
    return {
      status: hasPlaceholder ? 'PASSED' : 'WARN',
      detail: `placeholder="${ph ?? 'not set'}"`,
    };
  });

  // VP-02c: Autocomplete dropdown is NOT visible on page load
  await run('VP-02c', 'Autocomplete dropdown hidden on load', async () => {
    const dropSels = [
      '.yxt-SearchBar-autocomplete', '[role="listbox"]',
      'bolt-autocomplete-wc [role="listbox"]', '[class*="autocomplete-list"]',
    ];
    for (const s of dropSels) {
      const el = page.locator(s).first();
      if (await el.count() > 0 && await el.isVisible({ timeout: 1000 }).catch(() => false)) {
        return { status: 'FAILED', detail: `Dropdown visible unexpectedly: "${s}"` };
      }
    }
    return { status: 'PASSED', detail: 'No autocomplete dropdown visible on load' };
  });

  // ══ VP-03 — LAYOUT ALIGNMENT ══════════════════════════════════════════════
  // VP-03a: Search bar is horizontally centred or left-aligned within its container
  await run('VP-03a', 'Search bar layout alignment', async () => {
    const inp = await getInputEl();
    if (!inp) return { status: 'SKIPPED', detail: 'input not found' };
    const metrics = await inp.evaluate(el => {
      const st  = window.getComputedStyle(el);
      const r   = el.getBoundingClientRect();
      const mid = (r.left + r.right) / 2;
      return {
        display:        st.display,
        width:          Math.round(r.width),
        viewportMid:    Math.round(window.innerWidth / 2),
        elementMid:     Math.round(mid),
        offsetFromCentre: Math.abs(mid - window.innerWidth / 2),
        textAlign:      st.textAlign,
      };
    }).catch(() => null);
    if (!metrics) return { status: 'WARN', detail: 'Could not compute layout metrics' };
    const aligned = metrics.width > 0 && metrics.display !== 'none';
    return {
      status: aligned ? 'PASSED' : 'FAILED',
      detail: `width=${metrics.width}px display=${metrics.display} textAlign=${metrics.textAlign} centreOffset=${metrics.offsetFromCentre}px`,
    };
  });

  // VP-03b: Input has a reasonable minimum width (not collapsed / zero-width)
  await run('VP-03b', 'Search input has minimum usable width', async () => {
    const inp = await getInputEl();
    if (!inp) return { status: 'SKIPPED', detail: 'input not found' };
    const width = await inp.evaluate(el => el.getBoundingClientRect().width).catch(() => 0);
    return {
      status: width >= 100 ? 'PASSED' : 'FAILED',
      detail: `width=${Math.round(width)}px (min 100px required)`,
    };
  });

  // ══ VP-04 — CLASSES / BASIC STYLING ══════════════════════════════════════
  // VP-04a: Search input carries expected CSS class(es)
  await run('VP-04a', 'Search input has expected CSS classes', async () => {
    const inp = await getInputEl();
    if (!inp) return { status: 'SKIPPED', detail: 'input not found' };
    const cls = await inp.getAttribute('class').catch(() => '');
    const knownClasses = ['yxt-SearchBar-input', 'js-yext-query', 'bolt-textfield', 'search-input'];
    const matched = knownClasses.filter(c => (cls || '').includes(c));
    return {
      status: matched.length > 0 ? 'PASSED' : 'WARN',
      detail: `matched=[${matched.join(', ')}] class="${(cls || '').substring(0, 80)}"`,
    };
  });

  // VP-04b: Search wrapper carries Yext or bolt component class
  await run('VP-04b', 'Search wrapper has component class', async () => {
    const wrapSels = ['.yxt-SearchBar-wrapper', '.ch-searchbar', 'bolt-autocomplete-wc'];
    for (const s of wrapSels) {
      const el = page.locator(s).first();
      if (await el.count() > 0) {
        const cls = await el.getAttribute('class').catch(() => '');
        return { status: 'PASSED', detail: `selector="${s}" class="${(cls || '').substring(0, 60)}"` };
      }
    }
    return { status: 'WARN', detail: 'No Yext / bolt wrapper class found — may be custom' };
  });

  // VP-04c: No error / failure CSS class on input in default state
  await run('VP-04c', 'No error state class on input by default', async () => {
    const inp = await getInputEl();
    if (!inp) return { status: 'SKIPPED', detail: 'input not found' };
    const cls = await inp.getAttribute('class').catch(() => '');
    const errorClasses = ['error', 'invalid', 'has-error', 'is-invalid', 'field-error'];
    const found = errorClasses.filter(c => (cls || '').toLowerCase().includes(c));
    return {
      status: found.length === 0 ? 'PASSED' : 'FAILED',
      detail: found.length === 0 ? 'No error classes present' : `Error classes: [${found.join(', ')}]`,
    };
  });

  // ══ VP-05 — ACCESSIBILITY VISUAL STATE (COLLAPSED UI) ════════════════════
  // VP-05a: aria-expanded is "false" (not "true") on page load
  await run('VP-05a', 'aria-expanded="false" in collapsed state', async () => {
    const inp = await getInputEl();
    if (!inp) return { status: 'SKIPPED', detail: 'input not found' };
    const expanded = await inp.getAttribute('aria-expanded').catch(() => null);
    if (expanded === null) return { status: 'WARN', detail: 'aria-expanded not present on input (may be on wrapper)' };
    return {
      status: expanded === 'false' ? 'PASSED' : 'WARN',
      detail: `aria-expanded="${expanded}"`,
    };
  });

  // VP-05b: role="combobox" is present on the search input
  await run('VP-05b', 'role="combobox" on search input', async () => {
    const inp = await getInputEl();
    if (!inp) return { status: 'SKIPPED', detail: 'input not found' };
    const role = await inp.getAttribute('role').catch(() => null);
    return {
      status: role === 'combobox' ? 'PASSED' : 'WARN',
      detail: `role="${role ?? 'not set'}"`,
    };
  });

  // VP-05c: aria-autocomplete is set (indicates screen-reader widget type)
  await run('VP-05c', 'aria-autocomplete attribute present', async () => {
    const inp = await getInputEl();
    if (!inp) return { status: 'SKIPPED', detail: 'input not found' };
    const ac = await inp.getAttribute('aria-autocomplete').catch(() => null);
    const valid = ['list', 'inline', 'both'].includes(ac || '');
    return {
      status: ac ? (valid ? 'PASSED' : 'WARN') : 'WARN',
      detail: `aria-autocomplete="${ac ?? 'not set'}"`,
    };
  });

  // VP-05d: Listbox element is present in DOM but hidden/empty when collapsed
  await run('VP-05d', 'Listbox hidden / empty in collapsed state', async () => {
    const lbSel = '[role="listbox"]';
    const lb    = page.locator(lbSel).first();
    if (await lb.count() === 0) {
      return { status: 'PASSED', detail: 'No listbox in DOM on load (added dynamically)' };
    }
    const visible   = await lb.isVisible({ timeout: 1000 }).catch(() => false);
    const itemCount = await page.locator(`${lbSel} [role="option"]`).count().catch(() => 0);
    if (!visible || itemCount === 0) {
      return { status: 'PASSED', detail: `listbox inDOM=true visible=${visible} options=${itemCount}` };
    }
    return { status: 'WARN', detail: `Listbox visible with ${itemCount} options on load — unexpected` };
  });

  // VP-05e: Input is not aria-disabled in default state
  await run('VP-05e', 'Input not aria-disabled in default state', async () => {
    const inp = await getInputEl();
    if (!inp) return { status: 'SKIPPED', detail: 'input not found' };
    const disabled    = await inp.getAttribute('aria-disabled').catch(() => null);
    const htmlDisable = await inp.isDisabled().catch(() => false);
    const ok = disabled !== 'true' && !htmlDisable;
    return {
      status: ok ? 'PASSED' : 'FAILED',
      detail: `aria-disabled="${disabled ?? 'not set'}" disabled=${htmlDisable}`,
    };
  });

  // ══ SR-01 — SEARCH RESULTS PAGE ELEMENTS (only runs when component === 'results') ═══════
  if (component === 'results') {
    // SR-01a: Results container / card list is present and not empty
    await run('SR-01a', 'Search results container present', async () => {
      const resultSels = [
        '.HitchhikerResultsStandard',
        '[class*="ResultsStandard"]',
        '.yxt-ResultsHeader',
        '[data-type="result"]',
        '[class*="search-result"]',
        '[class*="SearchResult"]',
        '.HitchhikerResultsStandard-Card',
        'bolt-card',
        '[class*="result-card"]',
        '.js-yext-results',
      ];
      for (const s of resultSels) {
        try {
          const el = page.locator(s).first();
          if (await el.count() > 0 && await el.isVisible({ timeout: 3000 }).catch(() => false)) {
            const count = await page.locator(s).count().catch(() => 1);
            return { status: 'PASSED', detail: `selector="${s}" visible=true count=${count}` };
          }
        } catch { /* next */ }
      }
      return { status: 'WARN', detail: 'No results container found — page may still be loading or returned zero results' };
    });

    // SR-01b: Page URL contains the Search Results path pattern
    await run('SR-01b', 'URL matches /searchresults/personal/result?query= pattern', async () => {
      const currentUrl = page.url();
      const resultsPath = config.searchResultsPath || '/searchresults/personal/result';
      const hasPath  = currentUrl.includes(resultsPath);
      const hasQuery = currentUrl.includes('query=');
      return {
        status: (hasPath && hasQuery) ? 'PASSED' : 'WARN',
        detail: `url="${currentUrl}" hasPath=${hasPath} hasQuery=${hasQuery}`,
      };
    });

    // SR-01c: Results count text is present (e.g. "X results for …")
    await run('SR-01c', 'Results count / header text visible', async () => {
      const countSels = [
        '.yxt-ResultsHeader-count',
        '[class*="ResultsHeader"]',
        '[class*="results-count"]',
        '[class*="resultsCount"]',
        '[class*="results-header"]',
        '.HitchhikerResultsStandard-title',
        'h1, h2',
      ];
      for (const s of countSels) {
        try {
          const el = page.locator(s).first();
          if (await el.count() > 0) {
            const txt = (await el.textContent().catch(() => '')).trim();
            if (txt.length > 0) {
              return { status: 'PASSED', detail: `selector="${s}" text="${txt.substring(0, 80)}"` };
            }
          }
        } catch { /* next */ }
      }
      return { status: 'WARN', detail: 'No results count / header text found' };
    });
  }

  const passed  = results.filter(r => r.status === 'PASSED').length;
  const warned  = results.filter(r => r.status === 'WARN').length;
  const failed  = results.filter(r => r.status === 'FAILED').length;
  const skipped = results.filter(r => r.status === 'SKIPPED').length;
  console.log(`\n   Visual Presence [${label}]: ${passed} passed | ${failed} failed | ${warned} warn | ${skipped} skipped`);
  return { device: label, results, passed, total: results.length };
}
