/**
 * run-visual-only.js
 * Runs ONLY the Visual Presence Validation suite (VP-01–05) for both
 * Global Header Search and Contact Page Search.
 *
 * Usage:  node run-visual-only.js [--headless]
 */
import { chromium }       from 'playwright';
import { config }         from './core/config.js';
import { testVisualPresence } from './tests/elements.js';
import { waitForPageReady, dismissCookieBanner, registerCookieAutoDismiss } from './utils/helpers.js';

const headless = process.argv.includes('--headless');

const browser  = await chromium.launch({ headless, slowMo: headless ? 0 : 50 });
const context  = await browser.newContext({ viewport: { width: 1280, height: 800 } });
const page     = await context.newPage();

const badge = s =>
  s === 'PASSED'  ? '✓ PASSED'  :
  s === 'FAILED'  ? '✗ FAILED'  :
  s === 'WARN'    ? '⚠ WARN'    :
  s === 'SKIPPED' ? '~ SKIP'    : `~ ${s}`;

const printResults = (suite, raw) => {
  const results = raw.results || [];
  console.log(`\n${'─'.repeat(62)}`);
  console.log(` ${suite}`);
  console.log('─'.repeat(62));
  for (const r of results) {
    const detail = r.detail || r.error || '';
    console.log(`  ${badge(r.status).padEnd(12)} ${(r.test || r.name || '?').replace(` — ${suite}`, '')}${detail ? '  — ' + detail.substring(0, 80) : ''}`);
  }
  const p = results.filter(r => r.status === 'PASSED').length;
  const f = results.filter(r => r.status === 'FAILED').length;
  const w = results.filter(r => r.status === 'WARN').length;
  const s = results.filter(r => r.status === 'SKIPPED').length;
  console.log(`\n  ${p} passed | ${f} failed | ${w} warn | ${s} skipped  (of ${results.length})`);
  return { p, f, w };
};

console.log('\n══════════════════════════════════════════════════════════════');
console.log('  VISUAL PRESENCE VALIDATION (VP-01 – VP-05)');
console.log(`  URL: ${config.homeUrl}`);
console.log('══════════════════════════════════════════════════════════════');

try {
  await page.goto(config.homeUrl, { waitUntil: 'domcontentloaded', timeout: 40000 });
  await dismissCookieBanner(page).catch(() => {});
  await waitForPageReady(page, { networkTimeout: 5000 });

  // ── Suite 15a: Global Header ──────────────────────────────────────────────
  const globalRaw = await testVisualPresence(page, { component: 'global' });
  const g = printResults('Visual Presence — Global Header Search', globalRaw);

  // ── Suite 15b: Contact Page ───────────────────────────────────────────────
  const contactUrl = `${config.homeUrl.replace(/\/$/,'')}${config.contactPath || '/personal/contact/'}`;
  const contactRaw = await testVisualPresence(page, { component: 'contact', pageUrl: contactUrl });
  const c = printResults('Visual Presence — Contact Page Search', contactRaw);

  // ── Suite 15c: Search Results Page (page-level Yext bar) ──────────────────
  const resultsUrl = `${config.homeUrl.replace(/\/$/, '')}${config.searchResultsBaseUrl || '/searchresults/personal/result?=&referrerPageUrl=&query='}`;
  const resultsRaw = await testVisualPresence(page, { component: 'results', pageUrl: resultsUrl });
  const r = printResults('Visual Presence — Search Results Page Search', resultsRaw);

  // ── Suite 15d: Search Results Page — Global Header bar ───────────────────
  // The SR page also has the #header Global Header search bar:
  //   wrapper: #header > div.ch-searchbar.component.yxt-Answers-component.yxt-SearchBar-wrapper
  //   input:   #yxt-SearchBar-input--SearchBar
  await page.goto(resultsUrl, { waitUntil: 'domcontentloaded', timeout: 40000 });
  await dismissCookieBanner(page).catch(() => {});
  await waitForPageReady(page, { networkTimeout: 5000 });
  const resultsHeaderRaw = await testVisualPresence(page, { component: 'results-header', pageUrl: resultsUrl });
  const rh = printResults('Visual Presence — Search Results Page Global Header Search', resultsHeaderRaw);

  const totalF = g.f + c.f + r.f + rh.f;
  const totalP = g.p + c.p + r.p + rh.p;
  const totalW = g.w + c.w + r.w + rh.w;
  console.log(`\n${'═'.repeat(62)}`);
  console.log(`  OVERALL: ${totalP} passed | ${totalF} failed | ${totalW} warn`);
  console.log('══════════════════════════════════════════════════════════════\n');
  process.exit(totalF > 0 ? 1 : 0);

} finally {
  await browser.close();
}
