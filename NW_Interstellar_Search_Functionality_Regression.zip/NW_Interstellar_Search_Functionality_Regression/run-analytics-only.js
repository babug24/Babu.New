/**
 * run-analytics-only.js
 * Runs ONLY the Analytics / dataLayer Validation suite (AC-66–69).
 * Usage:  node run-analytics-only.js [--headless]
 */
import { chromium } from 'playwright';
import { testAnalyticsTracking } from './tests/analytics.js';

const headless = process.argv.includes('--headless');

const browser = await chromium.launch({ headless });
console.log('\n══════════════════════════════════════════════════');
console.log('  ANALYTICS / dataLayer Validation (AC-66–69)');
console.log('══════════════════════════════════════════════════');

try {
  const raw     = await testAnalyticsTracking(browser, { headless });
  const results = raw.results || [];

  console.log('\n──────────────────────────────────────────────────');
  for (const r of results) {
    const icon   = r.status === 'PASSED' ? '✓' : r.status === 'WARN' ? '⚠' : '✗';
    const detail = r.detail || r.error || '';
    console.log(`  ${icon} ${r.status.padEnd(7)} ${(r.test || r.name || '?')}${detail ? '  — ' + detail : ''}`);
  }

  const p = results.filter(r => r.status === 'PASSED').length;
  const f = results.filter(r => r.status === 'FAILED').length;
  const w = results.filter(r => r.status === 'WARN').length;
  const s = results.filter(r => r.status === 'SKIPPED').length;
  console.log(`\n  ${p} passed | ${f} failed | ${w} warn | ${s} skipped  (of ${results.length})`);
  console.log('══════════════════════════════════════════════════\n');

  process.exit(f > 0 ? 1 : 0);
} finally {
  await browser.close();
}
