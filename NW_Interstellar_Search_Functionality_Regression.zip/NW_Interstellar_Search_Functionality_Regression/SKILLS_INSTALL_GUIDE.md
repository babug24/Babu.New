# Skills Install Guide (Reusable for Other Projects)

This guide captures the exact working process we used to install and use `skills` in this environment.

## 1) Move to your target project

```powershell
cd <your-project-path>
```

## 2) Preferred way: run via `npx` (no global install required)

```powershell
npx skills --help
```

If this works, continue using `npx skills ...` commands in that project.

## 3) If adding skill directly from GitHub path fails

If this fails:

```powershell
npx skills add mattpocock/skills/grill-me
```

use the local zip workflow below (this is what worked for us).

## 4) Download and extract the skill repository locally

```powershell
Invoke-WebRequest -Uri "https://github.com/mattpocock/skills/archive/refs/heads/main.zip" -OutFile skills.zip
Expand-Archive skills.zip -Force
```

This creates:

- `./skills/skills-main/`

## 5) Install skills from local folder

Interactive mode:

```powershell
npx skills add ./skills/skills-main
```

Non-interactive all-in-one mode:

```powershell
npx skills add ./skills/skills-main --all -y
```

## 6) Verify installed skills

```powershell
npx skills list
```

## 7) Useful commands for daily use

```powershell
npx skills find
npx skills update -y
npx skills remove
```

## 8) Registry-restricted environment fallback

If `npm install -g skills` fails with `403 Forbidden`, skip global install and use `npx skills ...` per project.

Optional local install in project:

```powershell
npm install skills
npx skills --help
```

## 9) Quick setup for a new project (copy/paste)

```powershell
cd <your-project-path>
npx skills --help
Invoke-WebRequest -Uri "https://github.com/mattpocock/skills/archive/refs/heads/main.zip" -OutFile skills.zip
Expand-Archive skills.zip -Force
npx skills add ./skills/skills-main --all -y
npx skills list
```

## Notes

- Prefer `npx skills` over global install in restricted corporate networks.
- Keep skills project-local for reproducibility across teams.
- If prompted, choose project scope unless you specifically need global/user-level install.
