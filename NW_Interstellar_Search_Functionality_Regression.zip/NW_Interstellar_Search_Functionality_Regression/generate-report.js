const fs = require('fs');
const path = require('path');

const resultsPath = path.join(__dirname, 'report', 'results.json');
const outputPath = path.join(__dirname, 'report', 'nw-test-report.html');

if (!fs.existsSync(resultsPath)) {
  console.error('No results.json found in report folder. Run tests first.');
  process.exit(1);
}

const data = JSON.parse(fs.readFileSync(resultsPath, 'utf-8'));

// Aggregate stats
let totalTests = 0, passed = 0, failed = 0, skipped = 0, totalDuration = 0;
const browserResults = {};
const testRows = [];

for (const suite of data.suites || []) {
  for (const spec of suite.specs || []) {
    for (const test of spec.tests || []) {
      const browser = test.projectName || 'chromium';
      const status   = test.status === 'expected' ? 'passed'
                     : test.status === 'skipped'  ? 'skipped'
                     : 'failed';
      const duration = test.results?.[0]?.duration || 0;
      const error    = test.results?.[0]?.error?.message || '';

      totalTests++;
      totalDuration += duration;
      if (status === 'passed')  passed++;
      else if (status === 'failed')  failed++;
      else if (status === 'skipped') skipped++;

      browserResults[browser] = browserResults[browser] || { passed: 0, failed: 0, skipped: 0 };
      browserResults[browser][status]++;

      testRows.push({ title: spec.title, browser, status, duration, error });
    }
  }
}

const passRate = totalTests ? ((passed / totalTests) * 100).toFixed(1) : 0;
const avgDuration = totalTests ? (totalDuration / totalTests / 1000).toFixed(2) : 0;
const runDate = new Date().toLocaleString();

const browserLabels = JSON.stringify(Object.keys(browserResults));
const browserPassed = JSON.stringify(Object.values(browserResults).map(b => b.passed));
const browserFailed = JSON.stringify(Object.values(browserResults).map(b => b.failed));

const rowsHtml = testRows.map((t, i) => {
  const statusClass = t.status === 'passed' ? 'status-pass' : t.status === 'failed' ? 'status-fail' : 'status-skip';
  const statusIcon  = t.status === 'passed' ? '✅' : t.status === 'failed' ? '❌' : '⏭️';
  const dur = (t.duration / 1000).toFixed(2) + 's';
  const errHtml = t.error
    ? `<div class="error-msg">${t.error.replace(/</g, '&lt;').replace(/>/g, '&gt;').substring(0, 200)}</div>`
    : '';
  return `
  <tr class="test-row ${t.status === 'failed' ? 'row-fail' : ''}">
    <td class="tc-num">${i + 1}</td>
    <td class="tc-title">${t.title}${errHtml}</td>
    <td><span class="badge browser-badge">${t.browser}</span></td>
    <td><span class="${statusClass}">${statusIcon} ${t.status.toUpperCase()}</span></td>
    <td class="tc-dur">${dur}</td>
  </tr>`;
}).join('');

const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>NW Help Center – Test Report</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Segoe UI', Arial, sans-serif; background: #f0f4f8; color: #222; }

    /* ---------- TOP HEADER ---------- */
    .header {
      background: linear-gradient(135deg, #002D62 0%, #005EB8 60%, #0077CC 100%);
      color: #fff; padding: 28px 40px; display: flex; align-items: center;
      justify-content: space-between;
    }
    .header h1 { font-size: 1.7rem; font-weight: 700; letter-spacing: .5px; }
    .header .sub { font-size: .85rem; opacity: .8; margin-top: 4px; }
    .header .badge-env {
      background: rgba(255,255,255,.18); border-radius: 20px;
      padding: 6px 16px; font-size: .8rem; font-weight: 600;
    }

    /* ---------- PASS-RATE BANNER ---------- */
    .pass-banner {
      background: ${Number(passRate) === 100 ? '#1a7f42' : Number(passRate) >= 80 ? '#e07b00' : '#c0392b'};
      color: #fff; text-align: center; padding: 10px;
      font-size: 1rem; font-weight: 600; letter-spacing: .4px;
    }

    /* ---------- SUMMARY CARDS ---------- */
    .cards { display: flex; gap: 16px; padding: 28px 40px 10px; flex-wrap: wrap; }
    .card {
      background: #fff; border-radius: 12px; padding: 22px 28px;
      flex: 1 1 140px; min-width: 130px;
      box-shadow: 0 2px 10px rgba(0,0,0,.08);
      display: flex; flex-direction: column; align-items: center;
    }
    .card .num { font-size: 2.4rem; font-weight: 800; line-height: 1.1; }
    .card .lbl { font-size: .75rem; text-transform: uppercase; letter-spacing: .8px; color: #666; margin-top: 4px; }
    .card.total .num  { color: #005EB8; }
    .card.pass  .num  { color: #1a7f42; }
    .card.fail  .num  { color: #c0392b; }
    .card.skip  .num  { color: #888; }
    .card.rate  .num  { color: ${Number(passRate) === 100 ? '#1a7f42' : Number(passRate) >= 80 ? '#e07b00' : '#c0392b'}; }
    .card.dur   .num  { color: #6c3fc5; font-size: 1.6rem; }

    /* ---------- CHARTS SECTION ---------- */
    .charts { display: flex; gap: 20px; padding: 10px 40px 20px; flex-wrap: wrap; }
    .chart-box {
      background: #fff; border-radius: 12px; padding: 24px;
      box-shadow: 0 2px 10px rgba(0,0,0,.08); flex: 1 1 260px;
    }
    .chart-box h3 { font-size: .9rem; color: #555; text-transform: uppercase; margin-bottom: 16px; letter-spacing: .6px; }
    .chart-wrap { position: relative; height: 220px; }

    /* ---------- TABLE ---------- */
    .table-section { padding: 0 40px 40px; }
    .table-section h2 { font-size: 1.1rem; color: #333; margin-bottom: 12px; }
    .search-bar {
      width: 100%; padding: 9px 14px; border: 1px solid #ccd; border-radius: 8px;
      font-size: .9rem; margin-bottom: 12px; outline: none;
    }
    .search-bar:focus { border-color: #005EB8; }
    .filter-btns { display: flex; gap: 8px; margin-bottom: 14px; flex-wrap: wrap; }
    .filter-btn {
      padding: 5px 14px; border-radius: 20px; border: 2px solid transparent;
      cursor: pointer; font-size: .8rem; font-weight: 600; transition: .15s;
    }
    .filter-btn.all    { background:#e8eef6; color:#005EB8; border-color:#005EB8; }
    .filter-btn.pass   { background:#e6f4ec; color:#1a7f42; border-color:#1a7f42; }
    .filter-btn.fail   { background:#fdecea; color:#c0392b; border-color:#c0392b; }
    .filter-btn.skip   { background:#f5f5f5; color:#888;    border-color:#aaa; }
    .filter-btn:hover  { opacity: .8; }
    table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,.08); }
    thead tr { background: #002D62; color: #fff; }
    th { padding: 12px 14px; font-size: .8rem; text-transform: uppercase; letter-spacing: .6px; text-align: left; }
    td { padding: 11px 14px; font-size: .85rem; border-bottom: 1px solid #eee; vertical-align: top; }
    tr:last-child td { border-bottom: none; }
    tr.row-fail { background: #fff8f8; }
    tr.test-row:hover { background: #f0f6ff; }
    .tc-num  { color: #999; width: 36px; }
    .tc-title{ max-width: 500px; }
    .tc-dur  { color: #555; white-space: nowrap; }
    .status-pass { color: #1a7f42; font-weight: 700; font-size: .8rem; }
    .status-fail { color: #c0392b; font-weight: 700; font-size: .8rem; }
    .status-skip { color: #888;    font-weight: 700; font-size: .8rem; }
    .badge { display: inline-block; padding: 2px 10px; border-radius: 12px; font-size: .75rem; font-weight: 600; }
    .browser-badge { background: #e8eef6; color: #005EB8; }
    .error-msg { color: #c0392b; font-size: .75rem; margin-top: 4px; font-style: italic; white-space: pre-wrap; word-break: break-word; }

    /* ---------- FOOTER ---------- */
    footer { text-align: center; padding: 18px; color: #999; font-size: .75rem; }
  </style>
</head>
<body>

<div class="header">
  <div>
    <div class="h1">🏛️ Nationwide – Help Center Navigation</div>
    <h1>Regression Test Report</h1>
    <div class="sub">📅 Executed: ${runDate}</div>
  </div>
  <div class="badge-env">NW Interstellar Regression</div>
</div>

<div class="pass-banner">
  ${Number(passRate) === 100 ? '🎉' : Number(passRate) >= 80 ? '⚠️' : '🚨'}
  Overall Pass Rate: ${passRate}%
  &nbsp;|&nbsp; ${passed} Passed &nbsp;|&nbsp; ${failed} Failed &nbsp;|&nbsp; ${skipped} Skipped
</div>

<!-- SUMMARY CARDS -->
<div class="cards">
  <div class="card total"><div class="num">${totalTests}</div><div class="lbl">Total Tests</div></div>
  <div class="card pass"> <div class="num">${passed}</div>  <div class="lbl">Passed</div></div>
  <div class="card fail"> <div class="num">${failed}</div>  <div class="lbl">Failed</div></div>
  <div class="card skip"> <div class="num">${skipped}</div> <div class="lbl">Skipped</div></div>
  <div class="card rate"> <div class="num">${passRate}%</div><div class="lbl">Pass Rate</div></div>
  <div class="card dur">  <div class="num">${avgDuration}s</div><div class="lbl">Avg Duration</div></div>
</div>

<!-- CHARTS -->
<div class="charts">
  <div class="chart-box">
    <h3>📊 Test Results Overview</h3>
    <div class="chart-wrap"><canvas id="doughnutChart"></canvas></div>
  </div>
  <div class="chart-box">
    <h3>🌐 Results by Browser</h3>
    <div class="chart-wrap"><canvas id="browserChart"></canvas></div>
  </div>
  <div class="chart-box">
    <h3>⏱️ Duration Distribution</h3>
    <div class="chart-wrap"><canvas id="durationChart"></canvas></div>
  </div>
</div>

<!-- TEST TABLE -->
<div class="table-section">
  <h2>📋 Detailed Test Results</h2>
  <input class="search-bar" id="searchInput" placeholder="🔍 Search test name..." oninput="filterTable()" />
  <div class="filter-btns">
    <button class="filter-btn all"  onclick="setFilter('all')">All (${totalTests})</button>
    <button class="filter-btn pass" onclick="setFilter('passed')">✅ Passed (${passed})</button>
    <button class="filter-btn fail" onclick="setFilter('failed')">❌ Failed (${failed})</button>
    <button class="filter-btn skip" onclick="setFilter('skipped')">⏭️ Skipped (${skipped})</button>
  </div>
  <table id="resultTable">
    <thead>
      <tr>
        <th>#</th><th>Test Name</th><th>Browser</th><th>Status</th><th>Duration</th>
      </tr>
    </thead>
    <tbody id="tableBody">${rowsHtml}</tbody>
  </table>
</div>

<footer>Nationwide Help Center Regression | Generated ${runDate} | Playwright Automation</footer>

<script>
  // ── Doughnut chart ────────────────────────────────────
  new Chart(document.getElementById('doughnutChart'), {
    type: 'doughnut',
    data: {
      labels: ['Passed', 'Failed', 'Skipped'],
      datasets: [{ data: [${passed}, ${failed}, ${skipped}],
        backgroundColor: ['#1a7f42','#c0392b','#aaa'],
        borderWidth: 3, borderColor: '#fff' }]
    },
    options: { responsive: true, maintainAspectRatio: false,
      plugins: { legend: { position: 'bottom' },
        tooltip: { callbacks: { label: ctx => ctx.label + ': ' + ctx.parsed + ' (' +
          ((ctx.parsed / ${totalTests}) * 100).toFixed(1) + '%)' } } } }
  });

  // ── Browser grouped bar chart ─────────────────────────
  new Chart(document.getElementById('browserChart'), {
    type: 'bar',
    data: {
      labels: ${browserLabels},
      datasets: [
        { label: 'Passed',  data: ${browserPassed}, backgroundColor: '#1a7f42', borderRadius: 6 },
        { label: 'Failed',  data: ${browserFailed}, backgroundColor: '#c0392b', borderRadius: 6 }
      ]
    },
    options: { responsive: true, maintainAspectRatio: false,
      plugins: { legend: { position: 'bottom' } },
      scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } }
  });

  // ── Duration histogram ────────────────────────────────
  const durations = [${testRows.map(t => (t.duration / 1000).toFixed(2)).join(',')}];
  const bins = ['0-5s','5-10s','10-20s','20-30s','30s+'];
  const counts = [0,0,0,0,0];
  durations.forEach(d => {
    if      (d < 5)  counts[0]++;
    else if (d < 10) counts[1]++;
    else if (d < 20) counts[2]++;
    else if (d < 30) counts[3]++;
    else             counts[4]++;
  });
  new Chart(document.getElementById('durationChart'), {
    type: 'bar',
    data: { labels: bins,
      datasets: [{ label: 'Tests', data: counts,
        backgroundColor: '#005EB8', borderRadius: 6 }]
    },
    options: { responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } }
  });

  // ── Filter / Search ───────────────────────────────────
  let activeFilter = 'all';
  function setFilter(f) { activeFilter = f; filterTable(); }
  function filterTable() {
    const q = document.getElementById('searchInput').value.toLowerCase();
    document.querySelectorAll('#tableBody .test-row').forEach(row => {
      const title  = row.querySelector('.tc-title').textContent.toLowerCase();
      const status = row.querySelector('[class^="status-"]')?.textContent.toLowerCase() || '';
      const matchSearch = title.includes(q);
      const matchFilter = activeFilter === 'all' || status.includes(activeFilter);
      row.style.display = matchSearch && matchFilter ? '' : 'none';
    });
  }
</script>
</body>
</html>`;

fs.writeFileSync(outputPath, html, 'utf-8');
console.log(`\n✅  Custom HTML report generated: report/nw-test-report.html\n`);
