import { chromium } from 'playwright';
import { config } from './core/config.js';
import { waitForPageReady, dismissCookieBanner } from './utils/helpers.js';
import { testSubmitButton } from './tests/elements.js';

const headless = process.argv.includes('--headless');

(async () => {
  const browser = await chromium.launch({ headless, slowMo: headless ? 0 : 40 });
  const context = await browser.newContext({
    viewport: { width: 1280, height: 800 },
    extraHTTPHeaders: config.headers || {},
  });
  const page = await context.newPage();

  try {
    const goto = async (url) => {
      await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 40000 });
      await dismissCookieBanner(page).catch(() => {});
      await waitForPageReady(page, { networkTimeout: 5000 });
    };

    await goto(config.homeUrl);
    const globalRes = await testSubmitButton(page, {
      component: 'global',
      pageUrl: config.homeUrl,
      envLabel: 'Prod',
    });

    const contactUrl = `${config.homeUrl.replace(/\/$/, '')}${config.contactPath || '/personal/contact/'}`;
    await goto(contactUrl);
    const contactRes = await testSubmitButton(page, {
      component: 'contact',
      pageUrl: contactUrl,
      envLabel: 'Prod',
    });

    // ── Search Results page — same submit / present / a11y checks ──────────────
    // Navigate to a real results URL so the search bar is present on the page.
    const resultsUrl = `${config.homeUrl.replace(/\/$/, '')}${config.searchResultsBaseUrl || '/searchresults/personal/result?=&referrerPageUrl=&query='}`;
    await goto(resultsUrl);
    const resultsRes = await testSubmitButton(page, {
      component: 'results',
      pageUrl: resultsUrl,
      envLabel: 'Prod',
    });

    // ── Search Results page — Global Header bar ────────────────────────────────
    // The SR page also contains the Global Header search (#yxt-SearchBar-input--SearchBar)
    // scoped under #header > div.ch-searchbar.component.yxt-Answers-component.yxt-SearchBar-wrapper
    await page.goto(resultsUrl, { waitUntil: 'domcontentloaded', timeout: 40000 });
    await dismissCookieBanner(page).catch(() => {});
    await waitForPageReady(page, { networkTimeout: 5000 });
    const resultsHeaderRes = await testSubmitButton(page, {
      component: 'results-header',
      pageUrl: resultsUrl,
      envLabel: 'Prod',
    });

    const all = [...(globalRes.results || []), ...(contactRes.results || []), ...(resultsRes.results || []), ...(resultsHeaderRes.results || [])];
    const p = all.filter(r => r.status === 'PASSED').length;
    const f = all.filter(r => r.status === 'FAILED').length;
    const w = all.filter(r => r.status === 'WARN').length;
    const s = all.filter(r => r.status === 'SKIPPED').length;

    console.log('\n──────────────────────────────────────────────────────────────');
    console.log(' Submit-only summary');
    console.log('──────────────────────────────────────────────────────────────');
    for (const r of all) {
      const icon = r.status === 'PASSED' ? '✓' : r.status === 'FAILED' ? '✗' : r.status === 'WARN' ? '⚠' : '~';
      console.log(` ${icon} ${r.status.padEnd(7)} ${(r.test || '').trim()}${r.detail ? `  — ${r.detail}` : ''}${r.error ? `  — ${r.error}` : ''}`);
    }
    console.log(`\n ${p} passed | ${f} failed | ${w} warn | ${s} skipped  (of ${all.length})`);

    process.exit(f > 0 ? 1 : 0);
  } finally {
    await page.close().catch(() => {});
    await context.close().catch(() => {});
    await browser.close().catch(() => {});
  }
})().catch(err => {
  console.error(`FATAL: ${err.message}`);
  process.exit(1);
});
