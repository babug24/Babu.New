/**
 * utils/autocomplete.js
 * All autocomplete-related queries, validation helpers, and
 * search-results-content validation.
 */

import path from 'path';
import { SCREENSHOTS_DIR, trunc } from '../core/config.js';
import { SELECTORS, resolveSelectors, firstVisible } from './selectors.js';

// ── State query ───────────────────────────────────────────────────────────────
// PRIMARY signal: aria-expanded on the search input (Yext native).
//   aria-expanded="true"  → autocomplete open
//   aria-expanded="false" → autocomplete closed
// FALLBACK: CSS visibility scan of known dropdown selectors.
export async function getAutocompleteState(page) {
  // 0. Angular: input is inside bolt-autocomplete shadow DOM — pierce it first
  const shadowResult = await page.evaluate(() => {
    const hosts = document.querySelectorAll('bolt-autocomplete, bolt-autocomplete-wc, bolt-textfield-wc');
    for (const host of hosts) {
      const inp = host.shadowRoot?.querySelector('input[aria-expanded]');
      if (inp) {
        return { found: true, expanded: inp.getAttribute('aria-expanded') === 'true', id: 'bolt-shadow-input' };
      }
      // Also check for visible listbox in shadow root as fallback
      const listbox = host.shadowRoot?.querySelector('[role="listbox"], ul.bolt-autocomplete-wc--listbox');
      if (listbox) {
        const rect = listbox.getBoundingClientRect();
        if (rect.height > 0) return { found: true, expanded: true, id: 'bolt-shadow-listbox' };
      }
    }
    return null;
  }).catch(() => null);

  if (shadowResult) {
    return { isVisible: shadowResult.expanded, selector: `aria-expanded on ${shadowResult.id}`, method: 'aria-expanded-shadow' };
  }

  // 1. aria-expanded check on all known Yext input IDs
  const ariaResult = await page.evaluate(() => {
    const inputIds = [
      '#yxt-SearchBar-input--search-bar-1',
      '#yxt-SearchBar-input--help-search-bar',
    ];
    for (const id of inputIds) {
      const el = document.querySelector(id);
      if (el) {
        const expanded = el.getAttribute('aria-expanded');
        if (expanded !== null)
          return { found: true, expanded: expanded === 'true', id };
      }
    }
    // Also check any input with aria-expanded set by Yext
    const anyInput = document.querySelector('input[aria-expanded]');
    if (anyInput) {
      return { found: true, expanded: anyInput.getAttribute('aria-expanded') === 'true', id: anyInput.id || 'input[aria-expanded]' };
    }
    return { found: false };
  }).catch(() => ({ found: false }));

  if (ariaResult.found) {
    return { isVisible: ariaResult.expanded, selector: `aria-expanded on ${ariaResult.id}`, method: 'aria-expanded' };
  }

  // 2. Fallback: CSS visibility scan of known dropdown selectors (runtime-resolved per env)
  const runtimeSEL = resolveSelectors ? resolveSelectors(page) : SELECTORS;
  for (const sel of runtimeSEL.autocomplete) {
    try {
      const el = page.locator(sel).first();
      if (await el.count() > 0 && await el.isVisible({ timeout: 300 }).catch(() => false)) {
        return { isVisible: true, selector: sel, method: 'css-visibility' };
      }
    } catch { /* continue */ }
  }
  return { isVisible: false, selector: null, method: 'css-visibility' };
}

export async function validateAutocompleteOpened(page, expectedTimeout = 3000) {
  const startTime = Date.now();
  const deadline  = startTime + expectedTimeout;
  let foundSelector = null;

  while (Date.now() < deadline) {
    const state = await getAutocompleteState(page);
    if (state.isVisible) { foundSelector = state.selector; break; }
    await page.waitForTimeout(100);
  }

  if (!foundSelector) {
    await page.screenshot({ path: path.join(SCREENSHOTS_DIR, 'autocomplete-not-opened.png') });
    throw new Error('Autocomplete dropdown failed to open after typing');
  }
  console.log(`   Autocomplete opened (${Date.now() - startTime}ms) - ${foundSelector}`);
}

export async function validateAutocompleteClosed(page, timeout = 3000) {
  const startTime = Date.now();
  const deadline  = startTime + timeout;

  while (Date.now() < deadline) {
    const state = await getAutocompleteState(page);
    if (!state.isVisible) {
      console.log(`   Autocomplete closed (${Date.now() - startTime}ms)`);
      return;
    }
    await page.waitForTimeout(100);
  }

  await page.screenshot({ path: path.join(SCREENSHOTS_DIR, 'autocomplete-not-closed.png') });
  throw new Error('Autocomplete dropdown remained open after selection');
}

// ── Suggestion helpers ────────────────────────────────────────────────────────
export async function getSuggestionsCount(page, waitMs = 1500) {
  // 0. aria-expanded pre-check (supports shadow DOM for Angular bolt-autocomplete)
  const ariaOpen = await page.evaluate(() => {
    // Light DOM check (Prod/Yext)
    const el = document.querySelector(
      '#yxt-SearchBar-input--search-bar-1, #yxt-SearchBar-input--help-search-bar, input[aria-expanded]'
    );
    if (el) return el.getAttribute('aria-expanded');
    // Shadow DOM check (Angular)
    for (const host of document.querySelectorAll('bolt-autocomplete, bolt-autocomplete-wc')) {
      const inp = host.shadowRoot?.querySelector('input[aria-expanded]');
      if (inp) return inp.getAttribute('aria-expanded');
    }
    return null;
  }).catch(() => null);

  if (ariaOpen === 'false') {
    // Not open yet — wait up to 1500 ms for aria-expanded to flip to true
    try {
      await page.waitForFunction(() => {
        const el = document.querySelector(
          '#yxt-SearchBar-input--search-bar-1, #yxt-SearchBar-input--help-search-bar, input[aria-expanded]'
        );
        if (el?.getAttribute('aria-expanded') === 'true') return true;
        // Shadow DOM
        for (const host of document.querySelectorAll('bolt-autocomplete, bolt-autocomplete-wc')) {
          const inp = host.shadowRoot?.querySelector('input[aria-expanded]');
          if (inp?.getAttribute('aria-expanded') === 'true') return true;
        }
        return false;
      }, { timeout: 1500 });
    } catch { /* didn't open — proceed to selector scan anyway */ }
  }

  // 1. Wait up to waitMs for any known suggestion selector to appear (runtime-resolved)
  const runtimeSEL = resolveSelectors ? resolveSelectors(page) : SELECTORS;
  const deadline = Date.now() + waitMs;
  while (Date.now() < deadline) {
    for (const sel of runtimeSEL.suggestions) {
      try {
        const count = await page.locator(sel).count();
        if (count > 0) return count;
      } catch { /* skip broken selector */ }
    }
    await page.waitForTimeout(200);
  }

  // 2. DOM fallback — count visible li/button children inside any autocomplete container
  const domCount = await page.evaluate(() => {
    // Angular: check shadow DOM of bolt-autocomplete first
    for (const host of document.querySelectorAll('bolt-autocomplete, bolt-autocomplete-wc')) {
      const items = host.shadowRoot?.querySelectorAll('li.bolt-autocomplete-wc--option, [role="option"]');
      if (items?.length) return items.length;
    }
    // Prod: check light DOM containers
    const selStr = [
      '.yxt-SearchBar-autocomplete',
      '[class*="autocomplete"]',
      '[role="listbox"]',
      'ul[class*="suggest"]',
      '[class*="Autocomplete"]',
      '[class*="suggestions"]',
      '[class*="dropdown"]',
      '[aria-label*="suggestions" i]',
      '[aria-label*="autocomplete" i]',
    ].join(', ');
    const containers = [...document.querySelectorAll(selStr)];
    for (const c of containers) {
      const items = [...c.querySelectorAll('li, button, [role="option"], [class*="suggestion"]')]
        .filter(el => {
          const s = getComputedStyle(el);
          return s.display !== 'none' && s.visibility !== 'hidden';
        });
      if (items.length > 0) return items.length;
    }
    return 0;
  }).catch(() => 0);

  return domCount;
}

export async function getFirstSuggestionText(page) {
  const SEL = resolveSelectors ? resolveSelectors(page) : SELECTORS;
  for (const sel of SEL.suggestions) {
    try {
      const el = page.locator(sel).first();
      if (await el.count() > 0) {
        const text = await el.textContent();
        if (text?.trim()) return text.trim();
      }
    } catch { /* skip broken selector */ }
  }
  return null;
}

export async function clickFirstSuggestion(page) {
  // 1. Try known selectors (runtime-resolved per env)
  const SEL = resolveSelectors ? resolveSelectors(page) : SELECTORS;
  for (const sel of SEL.suggestions) {
    try {
      const el = page.locator(sel).first();
      if (await el.count() > 0 && await el.isVisible().catch(() => false)) {
        const text = await el.textContent();
        console.log(`    Clicking suggestion: "${text?.trim()}"`);
        await el.click();
        return true;
      }
    } catch { /* skip broken selector */ }
  }
  // 2. DOM fallback — find first visible li/button inside autocomplete container
  const clicked = await page.evaluate(() => {
    const containers = document.querySelectorAll(
      '.yxt-SearchBar-autocomplete, [class*="autocomplete"], [role="listbox"], ul[class*="suggest"]'
    );
    for (const c of containers) {
      const items = c.querySelectorAll('li, button, [role="option"]');
      for (const item of items) {
        const r = item.getBoundingClientRect();
        if (r.width > 0 && r.height > 0) { item.click(); return true; }
      }
    }
    return false;
  }).catch(() => false);
  return clicked;
}

// ── Post-search URL validation ────────────────────────────────────────────────
export async function validateSearchResults(page, searchTerm, isContactPage = false) {
  console.log(`   Validating search results...`);
  const url = page.url();
  if (isContactPage) {
    if (!url.includes('query=') && !url.includes('q='))
      throw new Error(`Search query not found in URL. URL: ${url}`);
    console.log(`   Search executed - URL contains query parameter`);
    return true;
  }
  if (!url.includes('/searchresults/') && !url.includes('?query='))
    throw new Error(`Not on search results page. URL: ${url}`);
  console.log(`   On search results page`);
  return true;
}

// ── Suggestion relevance scoring ──────────────────────────────────────────────
export async function validateSuggestionRelevance(page, searchTerm) {
  const suggestions = [];
  for (const sel of SELECTORS.suggestions) {
    const els   = page.locator(sel);
    const count = await els.count();
    if (count > 0) {
      for (let i = 0; i < Math.min(count, 10); i++) {
        const text = (await els.nth(i).textContent().catch(() => '')).trim();
        if (text) suggestions.push(text);
      }
      break;
    }
  }

  if (!suggestions.length) return { status: 'SKIPPED', count: 0, detail: 'No suggestions rendered' };

  const term     = searchTerm.toLowerCase().split(' ')[0];
  const relevant = suggestions.filter(s => s.toLowerCase().includes(term));
  const pct      = Math.round((relevant.length / suggestions.length) * 100);
  const hasDupes = suggestions.length !== new Set(suggestions).size;

  console.log(`   Suggestions (${suggestions.length}): ${suggestions.slice(0, 3).join(' | ')}${suggestions.length > 3 ? '...' : ''}`);
  console.log(`   Relevance: ${relevant.length}/${suggestions.length} contain "${term}" (${pct}%)`);
  if (hasDupes) console.log(`   Duplicates: YES`);

  return { status: pct >= 50 ? 'PASSED' : 'WARN', count: suggestions.length, pct, hasDuplicates: hasDupes };
}

// ── Search results page content validation ────────────────────────────────────
export async function validateSearchResultsContent(page, searchTerm) {
  console.log(`   Validating results page for "${searchTerm}"...`);

  // ── Wait for Yext to finish loading results ───────────────────────────────
  // After Enter, Yext renders asynchronously — [aria-live="polite"] shows
  // "Please wait..." until results (or no-results) DOM is ready.
  // We must wait for that to resolve before reading any counts or cards.
  console.log(`     Waiting for Yext results to render...`);
  try {
    await page.waitForFunction(
      () => {
        const liveEl = document.querySelector('[aria-live="polite"]');
        // Done when: element gone, empty, or no longer "Please wait..."
        if (!liveEl) return true;
        const t = liveEl.textContent.trim();
        return t === '' || (!/please wait/i.test(t) && !/loading/i.test(t) && !/searching/i.test(t));
      },
      { timeout: 15000 }
    );
    console.log(`     Yext ready.`);
  } catch {
    console.log(`     Yext wait timed out — proceeding with current DOM state.`);
  }
  // Extra buffer for card DOM to paint after the count element settles
  await page.waitForTimeout(1500);

  const url = page.url();

  // ── Yext pagescdn iframe detection ─────────────────────────────────────────
  // Nationwide embeds search results inside an iframe hosted on pagescdn.com.
  // Playwright can query cross-origin frames directly — use it as the context
  // for all result-detection steps below (falls back to `page` if not found).
  let ctx = page;  // default: main page context
  try {
    const yextFrame = page.frames().find(f => /pagescdn\.com|search\.nationwide\.com/i.test(f.url()));
    if (yextFrame) {
      // Give the iframe a moment to fully render its result cards
      await yextFrame.waitForTimeout?.(2000).catch(() => page.waitForTimeout(2000));
      ctx = yextFrame;
      console.log(`     Yext iframe    : found (${yextFrame.url().substring(0, 100)})`);
    } else {
      console.log(`     Yext iframe    : not found — using main page`);
    }
  } catch {
    console.log(`     Yext iframe    : detection failed — using main page`);
  }

  // 1. Redirect validation
  // CONFIRMED URL patterns from browser recordings:
  //   Homepage search   → /search/?query=...
  //   Contact page search → /searchresults/personal/result?query=...
  const isSearchPage = url.includes('/search') || url.includes('query=') ||
                       url.includes('search?')  || url.includes('#search') ||
                       url.includes('searchresults') || url.includes('/result?') ||
                       url.includes('searchresults/personal/result');
  const queryInUrl   = url.includes(encodeURIComponent(searchTerm).replace(/%20/g, '+')) ||
                       url.includes(searchTerm.replace(/ /g, '+')) ||
                       url.includes(searchTerm.replace(/ /g, '%20')) ||
                       url.toLowerCase().includes(searchTerm.toLowerCase());

  console.log(`     URL            : ${url.substring(0, 120)}`);
  console.log(`     Is search page : ${isSearchPage}`);
  console.log(`     Query in URL   : ${queryInUrl}`);

  // 2. Results count text — read [aria-live="polite"] first (Yext announcer)
  //    then fall through to other known selectors.
  let resultsCountText = '';
  let parsedTotal = 0;

  // Priority: read the Yext aria-live region immediately after it settles
  const ariaLiveText = await ctx.evaluate(() => {
    const el = document.querySelector('[aria-live="polite"]');
    return el ? el.textContent.trim() : '';
  }).catch(() => '');
  const loadingPhrases = [/please wait/i, /loading/i, /^\.\.\.$/,  /searching/i, /fetching/i,
                          /autocomplete results are available/i];
  const isLoadingText = (t) => !t || loadingPhrases.some(p => p.test(t));

  if (ariaLiveText && !isLoadingText(ariaLiveText)) {
    console.log(`     aria-live text : "${ariaLiveText.substring(0, 100)}"`);
    resultsCountText = ariaLiveText;
  }

  // 2a. Wait for a count element to appear (fallback if aria-live didn't have it)
  if (!resultsCountText) {
    for (const sel of SELECTORS.resultsCountText) {
      try {
        await ctx.waitForSelector(sel, { state: 'attached', timeout: 4000 });
        break;
      } catch { /* not this selector, try next */ }
    }
  }

  // 2b. Read the count text from whichever selector is present.
  //     Retry up to 3×1 s if we only get a loading placeholder.
  for (let attempt = 0; attempt < 3 && !resultsCountText; attempt++) {
    if (attempt > 0) await page.waitForTimeout(1000);
    for (const sel of SELECTORS.resultsCountText) {
      try {
        const el = ctx.locator(sel).first();
        if (await el.count() > 0) {
          const txt = (await el.textContent({ timeout: 3000 }).catch(() => '')).trim();
          if (txt && !isLoadingText(txt)) { resultsCountText = txt; break; }
        }
      } catch { /* continue */ }
    }
  }

  // 2c. Full-page DOM fallback — scan every element's text for "Showing X-Y of Z" pattern
  //     Catches Yext results pages, help-center pages, or any variant DOM structure.
  if (!resultsCountText) {
    // Wait an extra 2 s for dynamic content to settle before scanning
    await page.waitForTimeout(2000);
    resultsCountText = await ctx.evaluate(() => {
      const patterns = [
        /showing\s+[\d,]+-[\d,]+\s+of\s+[\d,]+/i,
        /[\d,]+\s+results?\s+for/i,
        /of\s+[\d,]+\s+results?/i,
        /[\d,]+\s+matches?/i,
      ];
      const excluded = [/please wait/i, /loading/i, /searching/i, /fetching/i];
      const walk = (node) => {
        if (node.nodeType === 3) { // text node
          const t = (node.textContent || '').trim();
          if (t.length > 4 && t.length < 200 &&
              patterns.some(p => p.test(t)) &&
              !excluded.some(e => e.test(t))) return t;
        }
        for (const child of (node.childNodes || [])) {
          const r = walk(child);
          if (r) return r;
        }
        return '';
      };
      return walk(document.body) || '';
    }).catch(() => '');
    if (resultsCountText) console.log(`     Results count (DOM scan): "${resultsCountText}"`);
  }

  // 2d. Parse the total number from the count text
  if (resultsCountText) {
    const m = resultsCountText.match(/of\s+([\d,]+)/i) ||
              resultsCountText.match(/([\d,]+)\s+results?/i) ||
              resultsCountText.match(/([\d,]+)\s+matches?/i);
    if (m) parsedTotal = parseInt(m[1].replace(/,/g, ''), 10);
    console.log(`     Results count  : "${resultsCountText}"`);
    if (parsedTotal > 0) console.log(`     Parsed total   : ${parsedTotal}`);
  }

  // 3. Result card presence
  let resultCount = 0, matchedSel = null;
  for (const sel of SELECTORS.resultCards) {
    const count = await ctx.locator(sel).count();
    if (count > 0) { resultCount = count; matchedSel = sel; break; }
  }
  const hasResults = resultCount > 0 || parsedTotal > 0;
  const effectiveCount = parsedTotal > 0 ? parsedTotal : resultCount;
  console.log(`     Result cards   : ${resultCount > 0 ? resultCount + ' (' + matchedSel + ')' : 'NONE (selector miss)'}`);
  if (parsedTotal > 0 && resultCount === 0)
    console.log(`     Using parsed total from count text: ${parsedTotal}`);

  // 3. Card quality (sample first 5)
  let cardsWithTitle = 0, cardsWithLink = 0;
  if (matchedSel && resultCount > 0) {
    const cards  = ctx.locator(matchedSel);
    const sample = Math.min(await cards.count(), 5);
    for (let i = 0; i < sample; i++) {
      const card = cards.nth(i);
      if (await card.locator('h2,h3,h4,[class*="title"],[class*="Title"],a').first().count() > 0) cardsWithTitle++;
      if (await card.locator('a[href]').first().count() > 0) cardsWithLink++;
    }
    console.log(`     Cards w/title  : ${cardsWithTitle}/${sample}`);
    console.log(`     Cards w/link   : ${cardsWithLink}/${sample}`);
  }

  // 4. Keyword relevance
  const keywords = searchTerm.toLowerCase().split(' ').filter(w => w.length > 3);
  let relevantTerms = 0;
  if (hasResults && matchedSel && keywords.length) {
    const pageText = (await ctx.locator(matchedSel).allTextContents().catch(() => [])).join(' ').toLowerCase();
    relevantTerms  = keywords.filter(kw => pageText.includes(kw)).length;
    console.log(`     Relevant terms : ${relevantTerms}/${keywords.length} keywords found`);
  }
  // 5. Page header
  let pageHeader = '';
  for (const sel of SELECTORS.pageHeader) {
    const el = ctx.locator(sel).first();
    if (await el.count() > 0) {
      pageHeader = (await el.textContent().catch(() => '')).trim().substring(0, 80);
      if (pageHeader) break;
    }
  }
  console.log(`     Page header    : "${pageHeader}"`);

  // 6. No-results message
  const noResultMsg = await ctx.locator(SELECTORS.noResults.join(',')).count() > 0;
  if (noResultMsg) console.log(`     No-results msg : YES (unexpected for "${searchTerm}")`);

  // 7. Pagination
  const hasPagination = await ctx.locator(SELECTORS.pagination.join(',')).count() > 0;
  console.log(`     Pagination     : ${hasPagination ? 'present' : 'not found'}`);

  const pageTitle = await page.title().catch(() => '');
  console.log(`     Page title     : "${pageTitle.substring(0, 80)}"`);

  // Determine status
  let status = 'FAILED', failReason = null;
  if (!isSearchPage) {
    failReason = `Did not redirect to search page (url: ${url.substring(0, 80)})`;
  } else if (!queryInUrl) {
    failReason = 'Search query not reflected in URL';
  } else if (noResultMsg) {
    status = 'WARN';
    failReason = 'No-results message shown on page';
  } else if (hasResults) {
    status = 'PASSED';
  } else {
    // On search page with correct URL, but card selectors and count both missed —
    // Yext results may use class names not in our list.  Treat as WARN.
    status = 'WARN';
    failReason = 'On search page but result cards / count text not detected (Yext selectors may need updating)';
    console.log(`     Note: correct URL redirect but could not detect result cards or count`);
  }
  if (failReason) console.log(`     FAIL reason    : ${failReason}`);

  return {
    hasResults, resultCount: effectiveCount, parsedTotal, resultsCountText,
    matchedSel, queryInUrl, isSearchPage,
    cardsWithTitle, cardsWithLink, relevantTerms,
    hasPagination, noResultMsg, pageTitle, pageHeader,
    status, failReason: failReason || null
  };
}
