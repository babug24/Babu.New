/**
 * utils/selectors.js
 * Single source of truth for every CSS/Playwright selector used in tests.
 *
 * ── ENVIRONMENT STRATEGY ──────────────────────────────────────────────────────
 * Nationwide is migrating to Angular (uat-ng.nationwide.com).  The Angular build
 * uses Bolt web-components (bolt-textfield-wc, bolt-autocomplete-wc) instead of
 * the legacy Yext widget. Selectors differ significantly between envs.
 *
 * Two canonical selector maps are exported:
 *   SELECTORS_PROD     — legacy Yext-based (nationwide.com)
 *   SELECTORS_ANGULAR  — Bolt WC-based     (uat-ng.nationwide.com)
 *
 * SELECTORS (default export) is auto-resolved from BASE_URL at import time.
 * All existing test files importing { SELECTORS } continue to work unchanged.
 *
 * For explicit overrides:
 *   import { getSelectors } from '../utils/selectors.js';
 *   const SEL = getSelectors(page.url());
 *
 * Note on Angular contact page dynamic IDs:
 *   bolt-autocomplete-wc--<number>  — the numeric suffix is dynamic per render.
 *   We therefore use ARIA / data-attribute selectors that are stable across builds.
 *
 * Usage:
 *   import { SELECTORS, firstVisible } from '../utils/selectors.js';
 *   const el = await firstVisible(page, SELECTORS.searchInput);
 */

import { BASE_URL, ANGULAR_ENV_URLS, CLI_ANGULAR_FLAG } from '../core/config.js';

// ═══════════════════════════════════════════════════════════════════════════════
//  PROD  (nationwide.com — Yext / legacy stack)
// ═══════════════════════════════════════════════════════════════════════════════
export const SELECTORS_PROD = {

  // ── Global Header Search wrapper ───────────────────────────────────────────
  // CSS: #header > div.ch-searchbar.component.yxt-Answers-component.yxt-SearchBar-wrapper
  globalHeaderSearch: [
    '#header > div.ch-searchbar.component.yxt-Answers-component.yxt-SearchBar-wrapper',
    '#header div.yxt-SearchBar-wrapper',
    '#header div.ch-searchbar',
    '.ch-searchbar.yxt-SearchBar-wrapper',
    '#header [class*="yxt-Answers-component"]',
  ],

  // ── Search input ───────────────────────────────────────────────────────────
  searchInput: [
    '#yxt-SearchBar-input--search-bar-1',
    'input[aria-label="Conduct a search"]',
    'input[name="query"]',
    'input[type="search"]',
    'input[placeholder*="Search" i]',
  ],

  // ── Search icon / trigger button ───────────────────────────────────────────
  searchIcon: [
    'bolt-button[iconleft="search"]',
    'header button[aria-label*="search" i]',
    '#header button[aria-label*="search" i]',
    'button[aria-label="Search"]',
    '[data-js="search-toggle"]',
    '[class*="search"][role="button"]',
  ],

  // ── Global Header — Submit / Search button  (AC-30) ───────────────────────
  // CSS: #header > div.ch-searchbar…yxt-SearchBar-wrapper > div > div > form >
  //        button.js-yext-submit.yxt-SearchBar-button
  globalSubmitButton: [
    '#header > div.ch-searchbar.component.yxt-Answers-component.yxt-SearchBar-wrapper > div > div > form > button.js-yext-submit.yxt-SearchBar-button',
    '#header button.js-yext-submit',
    '#header .yxt-SearchBar-button',
    '.ch-searchbar button[type="submit"]',
    '.yxt-SearchBar-wrapper button[type="submit"]',
  ],

  // ── Contact Page — Submit / Search button  (AC-30) ────────────────────────
  // CSS: #p65218 > … > div.nw-help-center-search-submit > bolt-button
  contactSubmitButton: [
    '.nw-help-center-search-submit bolt-button',
    '.nw-help-center-search-submit button',
    '#p65218 bolt-button[type="submit"]',
    '#p65218 button[type="submit"]',
  ],

  // ── Autocomplete dropdown ──────────────────────────────────────────────────
  autocomplete: [
    '.yxt-SearchBar-autocomplete',
    '.autocomplete-container',
    '[class*="autocomplete"]',
    '[role="listbox"]',
    'ul[class*="suggest"]',
    'div[class*="autocomplete"]',
    '[class*="yxt-SearchBar-autocomplete"]',
    '.yxt-SearchBar-autocomplete--visible',
  ],

  // ── Individual autocomplete suggestions ───────────────────────────────────
  suggestions: [
    '.yxt-SearchBar-suggestion',
    'li[role="option"]',
    '.yxt-SearchBar-autocomplete li',
    '.yxt-SearchBar-autocomplete button',
    '[class*="Autocomplete"] li',
    '[class*="Autocomplete"] button',
    '[class*="autocomplete"] li',
    '[class*="autocomplete"] [role="option"]',
    '[role="listbox"] li',
    '[role="listbox"] [role="option"]',
    '.suggestion-item',
    'button[class*="suggest"]',
    '[class*="suggestion"][role]',
  ],

  // ── Clear button ───────────────────────────────────────────────────────────
  clearButton: [
    '.yxt-SearchBar-clear',
    'button[aria-label*="clear" i]',
    'button[class*="clear"]',
  ],

  // ── Search result cards ────────────────────────────────────────────────────
  resultCards: [
    '.HitchhikerResultsStandard-Card',
    '.HitchhikerResultsGridThreeColumns-Card',
    '.HitchhikerProductProminentImage',
    '.HitchhikerFaqAccordion',
    '.HitchhikerStandard',
    '.yxt-Card',
    '.yxt-StandardCard',
    '[class*="HitchhikerResultsStandard"]',
    '[class*="HitchhikerResultsGrid"]',
    '[class*="HitchhikerStandard"]',
    '[class*="result-card"]',
    '[class*="yxt-Card"]',
    '[data-type="result"]',
    '.yxt-AlternativeVerticals-item',
    '[class*="Hitchhiker"]',
    '[class*="yxt-Result"]',
  ],

  // ── Hamburger / mobile nav ─────────────────────────────────────────────────
  hamburger: [
    'div.bolt-header-wc--menu-button > button',
    '.bolt-header-wc--menu-button > button',
    'bolt-header >> button[aria-label*="menu" i]',
    'button[aria-label*="menu" i]',
    'button[aria-label*="navigation" i]',
    'bolt-button[iconleft="menu"]',
    '.hamburger',
    '[data-testid="hamburger"]',
    'button.nw-hamburger',
    '[aria-expanded][aria-controls*="nav" i]',
  ],

  // ── Nav-open detection ─────────────────────────────────────────────────────
  navOpen: [
    'nav[aria-expanded="true"]',
    '[class*="bolt-header-wc--main-nav"]',
    '[class*="bolt-header-wc--nav-open"]',
    '.nav-overlay',
    '[class*="mobile-nav"]',
    '[class*="nav-open"]',
    '.nw-nav--open',
  ],

  // ── Nav close icon ─────────────────────────────────────────────────────────
  navClose: [
    'bolt-icon.bolt-header-wc--main-menuIcon-close',
    '[aria-label="Close menu"]',
    '[aria-label="Close navigation"]',
  ],

  // ── Top navigation links ───────────────────────────────────────────────────
  topNavLinks: [
    'bolt-header-wc >> a[href]',
    'bolt-header >> a[href]',
    'nav a[href]',
    'header nav a',
    '[class*="bolt-header-wc"] a[href]',
    '[class*="primary-nav"] a',
    '[role="navigation"] a[href]',
  ],

  // ── Cookie/consent banner ──────────────────────────────────────────────────
  cookieBanner: [
    '#truste-consent-button',
    '[id*="consent"] button[class*="accept"]',
    '[id*="cookie"] button[class*="accept"]',
    'button[aria-label*="accept" i][class*="cookie"]',
    '.trustarc-banner-accept',
    '#truste-button-but',
    'button:has-text("Accept")',
    'button:has-text("I Accept")',
    'button:has-text("Accept All")',
    'button:has-text("Accept Cookies")',
    '.cc-accept',
    '#cookie-btn-accept',
  ],

  // ── No-results message ─────────────────────────────────────────────────────
  noResults: [
    '[class*="no-result"]',
    '[class*="noResult"]',
    ':text("no results")',
    ':text("0 results")',
    ':text("did not find")',
    ':text("No results found")',
  ],

  // ── Results count text ─────────────────────────────────────────────────────
  resultsCountText: [
    '.Answers-resultsText.js-helpcenter-resultcount',
    '.Answers-resultsText',
    '.js-helpcenter-resultcount',
    '[class*="resultsText"]',
    '[class*="resultcount" i]',
    '[class*="results-count"]',
    '[class*="result-count"]',
    '[class*="search-results-count"]',
    '[aria-live="polite"]',
  ],

  // ── Pagination ─────────────────────────────────────────────────────────────
  pagination: [
    '[class*="Pagination"]',
    '[class*="pagination"]',
    'nav[aria-label*="page" i]',
    '.yxt-Pagination',
  ],

  // ── Page header / H1 ──────────────────────────────────────────────────────
  pageHeader: [
    'h1',
    '[class*="results-header"]',
    '[class*="search-header"]',
  ],

  // ── Loading / spinner ─────────────────────────────────────────────────────
  loading: [
    '.loading',
    '.spinner',
    '[aria-label*="loading" i]',
    '.skeleton',
    '[class*="skeleton"]',
    '[class*="loader"]',
  ],

  // ── Contact page — search form wrapper ────────────────────────────────────
  // XPath: //*[@id="p65218"]/div/div[2]/div/div[2]/div[2]/div[1]/div/div/div/form
  contactSearchForm: [
    '#p65218 > div > div.column.small-12.large-expand > div > div.nw-help-center-search-prompt > div.nw-help-center-search > div.nw-help-center-search-query > div > div > div > form',
    '.nw-help-center-search-query form',
    '.nw-help-center-search form',
    '#p65218 form',
  ],

  // ── Contact page — search input ────────────────────────────────────────────
  // CONFIRMED: input ID = #yxt-SearchBar-input--help-search-bar
  contactSearchInput: [
    '#yxt-SearchBar-input--help-search-bar',
    '#p65218 > div > div.column.small-12.large-expand > div > div.nw-help-center-search-prompt > div.nw-help-center-search > div.nw-help-center-search-query > div > div > div > form input',
    '.nw-help-center-search-query input',
    '.nw-help-center-search input[type="text"]',
    '.nw-help-center-search input[type="search"]',
    '.nw-help-center-search input',
    '#p65218 input[type="text"]',
    '#p65218 input[type="search"]',
    '#p65218 input',
    '#yxt-SearchBar-input--search-bar-1',
    'input[aria-label="Conduct a search"]',
  ],

  // ── Search Results page — search input ───────────────────────────────
  // CONFIRMED (uat.nationwide.com/searchresults/personal/result):
  //   id="yxt-SearchBar-input--search-bar-1"  class="js-yext-query yxt-SearchBar-input"
  //   Same Yext widget as homepage — but NOT inside #header.
  searchResultsInput: [
    '#yxt-SearchBar-input--search-bar-1',
    'input.js-yext-query.yxt-SearchBar-input',
    'input[aria-label="Conduct a search"]',
    'input[name="query"]',
  ],

  // ── Search Results page — submit button ──────────────────────────────
  // CONFIRMED: button.js-yext-submit.yxt-SearchBar-button inside .yxt-SearchBar-form
  //            NOT scoped to #header (different from globalSubmitButton)
  //            Button is visible on page load without requiring input focus.
  searchResultsSubmitButton: [
    '.yxt-SearchBar-form > button.js-yext-submit.yxt-SearchBar-button',
    'button.js-yext-submit.yxt-SearchBar-button',
    '.yxt-SearchBar-wrapper button.js-yext-submit',
    '.ch-searchbar button.js-yext-submit',
    'form.yxt-SearchBar-form button[type="submit"]',
  ],

  // ── Search Results page — Global Header search input ───────────────────
  // DOM CONFIRMED (nationwide.com/searchresults/personal/result — Prod Chrome):
  //   Wrapper: div.ch-searchbar.yxt-SearchBar-wrapper > div.yxt-SearchBar > div.yxt-SearchBar-container
  //   Input:   #yxt-SearchBar-input--SearchBar  (light DOM)
  //   Listbox: #yxt-SearchBar-autocomplete--SearchBar > div[role="listbox"]
  //   Options: li.yxt-AutoComplete-option[role="option"]  id=yxt-AutoComplete-option-SearchBar.autocomplete-0-N
  //   Note: option IDs contain a DOT (SearchBar.autocomplete) vs homepage (search-bar-1.autocomplete).
  //   Chrome may serve this input without #header scope — confirmed confirmed full path below.
  searchResultsGlobalHeaderInput: [
    '#header > div.ch-searchbar.component.yxt-Answers-component.yxt-SearchBar-wrapper > div > div input.js-yext-query',   // CONFIRMED Chrome path
    '#header > div.ch-searchbar.component.yxt-Answers-component.yxt-SearchBar-wrapper > div > div input',
    '#yxt-SearchBar-input--SearchBar',
    '#header input.js-yext-query.yxt-SearchBar-input',
    '#header input[aria-autocomplete="list"]',
    '#header input[aria-label="Conduct a search"]',
  ],

  // ── Search Results page — Global Header submit button ──────────────────
  searchResultsGlobalHeaderSubmitButton: [
    '#header button.js-yext-submit.yxt-SearchBar-button',
    '#header .yxt-SearchBar-form button[type="submit"]',
    '#header button.js-yext-submit',
    '#header .ch-searchbar button[type="submit"]',
  ],
};


// ═══════════════════════════════════════════════════════════════════════════════
//  ANGULAR  (uat-ng.nationwide.com — Bolt web-component stack)
//
//  Key differences vs PROD:
//  • Search uses bolt-textfield-wc / bolt-autocomplete-wc web components
//  • Input IDs are DYNAMIC (bolt-autocomplete-wc--<number>) — never relied on
//  • Suggestions use bolt-wc listbox pattern
//  • Submit button is a <button> inside .bolt-textfield-wc--input-container
//  • Contact page: same bolt-autocomplete-wc, identified by aria attributes
// ═══════════════════════════════════════════════════════════════════════════════
export const SELECTORS_ANGULAR = {

  // ── Global Header Search wrapper ───────────────────────────────────────────
  // CONFIRMED (uat-ng.nationwide.com):
  //   <div id="search" slot="search"><bolt-autocomplete ...>
  //   Host lives in the header slot, NOT scoped to <header> tag
  globalHeaderSearch: [
    '#search > bolt-autocomplete',                        // CONFIRMED — div#search slot
    'div[id="search"] bolt-autocomplete',
    'bolt-autocomplete[arialabel="Search"]',
    'header bolt-autocomplete',
    'header div.bolt-textfield-wc--input-container',
    'header [class*="bolt-textfield-wc"]',
  ],

  // ── Search input (Global Header) ───────────────────────────────────────────
  // INPUT IS IN SHADOW DOM of bolt-autocomplete — use pierce/ (recorder-confirmed)
  // CONFIRMED by Chrome DevTools recorder: pierce/[data-test='input']
  //   also: #bolt-autocomplete-wc--<id> + [data-test='input'] (two-step chain)
  //   placeholder="" (empty on header), class="bolt-textfield-wc--input"
  searchInput: [
    '#search bolt-autocomplete >> input[data-test="input"]',
    'bolt-autocomplete >> input[data-test="input"]',
    'bolt-autocomplete[arialabel="Search"] >> input[data-test="input"]',
    'input[aria-label="Search"][role="combobox"]',
    'input[data-test="input"][aria-autocomplete="list"]',
    'header input[aria-label="Search"]',
    'header input[role="combobox"]',
  ],

  // ── Search icon / trigger (Angular uses visible input bar, no hidden icon) ─
  searchIcon: [
    'header button[aria-label*="search" i]',
    'header bolt-button[iconleft="search"]',
    'header [class*="search"][role="button"]',
    // Prod fallback kept for mixed-mode pages
    'bolt-button[iconleft="search"]',
    '[data-js="search-toggle"]',
  ],

  // ── Global Header — Submit button  (AC-30) ─────────────────────────────────
  // SUBMIT BUTTON IS IN SHADOW DOM of bolt-autocomplete — use pierce/ (recorder-confirmed)
  // CONFIRMED by recorder: bolt-autocomplete >> button[data-test='button'] (inner button)
  //   Submits search: clicking bolt-icon inside it also triggers navigation.
  //   aria-label="Submit Search"
  globalSubmitButton: [
    '#search bolt-autocomplete >> button[data-test="button"]',       // CONFIRMED — shadow pierce (safe for .count())
    'bolt-autocomplete >> button[data-test="button"]',
    'bolt-autocomplete >> button.bolt-textfield-wc--icon-button',
    'bolt-autocomplete >> button[aria-label="Submit Search"]',
    'header button[aria-label*="Submit Search" i]',
  ],

  // ── Contact Page — Submit button  (AC-30) ──────────────────────────────────
  // CONFIRMED (uat-ng.nationwide.com/personal/contact/):
  //   Host: div.nw-help-center-search-submit > bolt-button (LIGHT DOM — clickable directly)
  //   Inner button is in shadow DOM: bolt-button >> button[data-test="button"]
  //   bolt-button uses "arialabel" (no hyphen) NOT "aria-label" as its custom attribute.
  //   AC-30d must check both arialabel (host) and aria-label (shadow inner <button>).
  contactSubmitButton: [
    '#l88006 > ngx-nationwide-shell > div > div > div.nw-help-center-search > div.nw-help-center-search-submit > bolt-button',
    '.nw-help-center-search-submit > bolt-button',                               // CONFIRMED host (light DOM)
    '.nw-help-center-search-submit bolt-button >> button[data-test="button"]',   // shadow pierce — inner <button>
    'div.nw-help-center-search-submit bolt-button',
    '#l88006 div.nw-help-center-search-submit > bolt-button',
    'bolt-button[arialabel="Search"][iconleft="search"]',                        // bolt custom attr (no hyphen)
    'bolt-button[iconleft="search"][arialabel="Search"]',
    'bolt-button[iconleft="search"]',
  ],

  // ── Autocomplete dropdown — listbox is in SHADOW DOM of bolt-autocomplete ──
  // CONFIRMED: ul.bolt-autocomplete-wc--listbox[role="listbox"] inside shadow root
  autocomplete: [
    'bolt-autocomplete >> ul.bolt-autocomplete-wc--listbox',       // CONFIRMED — shadow pierce (safe for .count())
    'bolt-autocomplete >> [role="listbox"]',
    '[id*="listbox"]',
    '[role="listbox"]',
    '[class*="autocomplete"]',
  ],

  // ── Individual autocomplete suggestions — in SHADOW DOM ───────────────────
  // CONFIRMED: li.bolt-autocomplete-wc--option[role="option"] inside shadow root
  suggestions: [
    'bolt-autocomplete >> li.bolt-autocomplete-wc--option',        // CONFIRMED — shadow pierce (safe for .count())
    'bolt-autocomplete >> [role="option"]',
    '[role="listbox"] [role="option"]',
    '[role="listbox"] li',
    // Prod fallbacks for mixed pages
    '.yxt-SearchBar-suggestion',
    '[class*="autocomplete"] [role="option"]',
  ],

  // ── Clear button ───────────────────────────────────────────────────────────
  clearButton: [
    'button[aria-label*="clear" i]',
    '.bolt-textfield-wc--clear',
    'button[class*="clear"]',
    '.yxt-SearchBar-clear',
  ],

  // ── Search result cards ────────────────────────────────────────────────────
  resultCards: [
    // Angular likely to use bolt-card or similar — add confirmed selectors here
    'bolt-card',
    '[class*="bolt-card"]',
    '[class*="result-card"]',
    '[data-type="result"]',
    // Yext fallbacks (Yext may still serve on Angular env)
    '.HitchhikerResultsStandard-Card',
    '.yxt-Card',
    '[class*="Hitchhiker"]',
  ],

  // ── Hamburger / mobile nav ─────────────────────────────────────────────────
  hamburger: [
    'bolt-header >> button[aria-label*="menu" i]',
    'div.bolt-header-wc--menu-button > button',
    '.bolt-header-wc--menu-button > button',
    'button[aria-label*="menu" i]',
    'button[aria-label*="navigation" i]',
    'bolt-button[iconleft="menu"]',
    '.hamburger',
    '[data-testid="hamburger"]',
  ],

  // ── Nav-open detection ─────────────────────────────────────────────────────
  navOpen: [
    'nav[aria-expanded="true"]',
    '[class*="bolt-header-wc--main-nav"]',
    '[class*="bolt-header-wc--nav-open"]',
    '.nav-overlay',
    '[class*="mobile-nav"]',
    '[class*="nav-open"]',
  ],

  // ── Nav close icon ─────────────────────────────────────────────────────────
  navClose: [
    'bolt-icon.bolt-header-wc--main-menuIcon-close',
    '[aria-label="Close menu"]',
    '[aria-label="Close navigation"]',
  ],

  // ── Top navigation links ───────────────────────────────────────────────────
  topNavLinks: [
    'bolt-header-wc >> a[href]',
    'bolt-header >> a[href]',
    'nav a[href]',
    'header nav a',
    '[class*="bolt-header-wc"] a[href]',
    '[role="navigation"] a[href]',
  ],

  // ── Cookie/consent banner ──────────────────────────────────────────────────
  cookieBanner: [
    '#truste-consent-button',
    '[id*="consent"] button[class*="accept"]',
    '[id*="cookie"] button[class*="accept"]',
    '.trustarc-banner-accept',
    '#truste-button-but',
    'button:has-text("Accept")',
    'button:has-text("I Accept")',
    'button:has-text("Accept All")',
    'button:has-text("Accept Cookies")',
    '.cc-accept',
  ],

  // ── No-results message ─────────────────────────────────────────────────────
  noResults: [
    '[class*="no-result"]',
    '[class*="noResult"]',
    ':text("no results")',
    ':text("0 results")',
    ':text("did not find")',
    ':text("No results found")',
  ],

  // ── Results count text ─────────────────────────────────────────────────────
  resultsCountText: [
    '[aria-live="polite"]',
    '[class*="resultsText"]',
    '[class*="resultcount" i]',
    '[class*="results-count"]',
    '[class*="result-count"]',
    '.Answers-resultsText',
    '.js-helpcenter-resultcount',
  ],

  // ── Pagination ─────────────────────────────────────────────────────────────
  pagination: [
    'nav[aria-label*="page" i]',
    '[class*="pagination"]',
    '[class*="Pagination"]',
    '.yxt-Pagination',
  ],

  // ── Page header / H1 ──────────────────────────────────────────────────────
  pageHeader: [
    'h1',
    '[class*="results-header"]',
    '[class*="search-header"]',
  ],

  // ── Loading / spinner ─────────────────────────────────────────────────────
  loading: [
    '.loading',
    '.spinner',
    '[aria-label*="loading" i]',
    '.skeleton',
    '[class*="skeleton"]',
    '[class*="loader"]',
  ],

  // ── Contact page — search form wrapper ────────────────────────────────────
  // CONFIRMED (uat-ng.nationwide.com/personal/contact/):
  //   Light DOM path: ngx-nationwide-shell > div > div.nw-help-center-search-prompt > div.nw-help-center-search
  //   Form inside: div.nw-help-center-search-container > form[role="search"]
  contactSearchForm: [
    'div.nw-help-center-search',                                   // CONFIRMED light DOM
    'div.nw-help-center-search-container > form[role="search"]',   // CONFIRMED form element
    '#l88006 div.nw-help-center-search',
    'bolt-autocomplete',                                           // CONFIRMED tag (not -wc)
    // Prod fallback
    '#p65218 form',
    '.nw-help-center-search form',
  ],

  // ── Contact page — search input ────────────────────────────────────────────
  // INPUT IS IN SHADOW DOM of bolt-autocomplete (tag: bolt-autocomplete, NOT bolt-autocomplete-wc)
  // CONFIRMED attrs: data-test="input" role="combobox" aria-label="Search"
  //   class="bolt-textfield-wc--input" placeholder="Enter a search term"
  //   aria-autocomplete="list" aria-controls="bolt-autocomplete-wc--<id>--listbox"
  contactSearchInput: [
    'div.nw-help-center-search bolt-autocomplete >> input[data-test="input"]',  // CONFIRMED shadow pierce
    'bolt-autocomplete >> input[data-test="input"]',
    'bolt-autocomplete >> input[aria-label="Search"]',
    'input[aria-label="Search"][role="combobox"]',
    'input[aria-controls*="listbox"]',
    // Prod fallbacks
    '#yxt-SearchBar-input--help-search-bar',
    '.nw-help-center-search-query input',
    '#p65218 input[type="text"]',
  ],

  // ── Search Results page — search input ───────────────────────────────
  // CONFIRMED: same Yext widget as UAT-Prod (same id/class pattern on results page)
  searchResultsInput: [
    '#yxt-SearchBar-input--search-bar-1',
    'input.js-yext-query.yxt-SearchBar-input',
    'input[aria-label="Conduct a search"]',
    'input[name="query"]',
  ],

  // ── Search Results page — submit button ──────────────────────────────
  // CONFIRMED: same class structure as UAT-Prod — not scoped to #header
  searchResultsSubmitButton: [
    '.yxt-SearchBar-form > button.js-yext-submit.yxt-SearchBar-button',
    'button.js-yext-submit.yxt-SearchBar-button',
    '.yxt-SearchBar-wrapper button.js-yext-submit',
    '.ch-searchbar button.js-yext-submit',
    'form.yxt-SearchBar-form button[type="submit"]',
  ],

  // ── Search Results page — Global Header search input ───────────────────
  // DOM CONFIRMED (uat-ng.nationwide.com/searchresults/personal/result):
  //   The SR page embeds the YEXT widget (not bolt-autocomplete).
  //   Wrapper:  div.Answers-search#js-answersSearchBar > div.yxt-SearchBar
  //   Input:    #yxt-SearchBar-input--SearchBar  (light DOM — no shadow pierce)
  //   Listbox:  #yxt-SearchBar-autocomplete--SearchBar > div > div[role="listbox"]
  //   Options:  li.yxt-AutoComplete-option[role="option"]  id=yxt-AutoComplete-option-SearchBar.autocomplete-0-N
  //   Note: option IDs contain a DOT (SearchBar.autocomplete) — different from
  //         homepage variant which uses (search-bar-1.autocomplete).
  searchResultsGlobalHeaderInput: [
    '#yxt-SearchBar-input--SearchBar',                             // CONFIRMED — light DOM
    'input.js-yext-query.yxt-SearchBar-input[aria-controls*="SearchBar"]',
    '#header input.js-yext-query.yxt-SearchBar-input',
    '#header input[aria-autocomplete="list"]',
    '#header input[aria-label="Conduct a search"]',
  ],

  // ── Search Results page — Global Header submit button ──────────────────
  // CONFIRMED: same Yext widget — button.js-yext-submit inside the form
  searchResultsGlobalHeaderSubmitButton: [
    '#header button.js-yext-submit.yxt-SearchBar-button',
    '#header .yxt-SearchBar-form button[type="submit"]',
    '#header button.js-yext-submit',
    '#header .ch-searchbar button[type="submit"]',
    '.yxt-SearchBar-form > button.js-yext-submit',                // fallback when #header scope absent
  ],
};


// ═══════════════════════════════════════════════════════════════════════════════
//  Environment detection + auto-resolver
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Returns true if the given URL belongs to the Angular (uat-ng) environment.
 */
/**
 * Detects whether a URL belongs to an Angular (bolt-component) environment.
 *
 * Detection priority (first match wins):
 *   1. --angular CLI flag          — forces Angular mode for any URL
 *   2. url.csv type=angular rows   — ANGULAR_ENV_URLS set from config
 *   3. URL pattern heuristics      — 'uat-ng.' | 'angular' in hostname | '-ng.' subdomain
 *
 * To add a new Angular URL: add it to url.csv with type=angular.
 * To run any URL in Angular mode: pass --angular flag.
 * No code changes needed for either case.
 */
export function isAngularEnv(url = '') {
  if (CLI_ANGULAR_FLAG) return true;
  const normalized = String(url).replace(/\/$/, '').toLowerCase();
  // Check against known Angular URLs from url.csv
  for (const angularUrl of ANGULAR_ENV_URLS) {
    if (normalized.startsWith(angularUrl.toLowerCase())) return true;
  }
  // URL pattern heuristics: uat-ng. | -ng. | /angular | bolt- in hostname
  try {
    const host = new URL(normalized).hostname;
    if (host.includes('uat-ng.') || host.startsWith('ng.') ||
        /-ng\./.test(host) || host.includes('-angular.') ||
        host.includes('.angular.')) return true;
  } catch { /* ignore invalid URL */ }
  return false;
}

/**
 * Returns the correct selector map for the given URL.
 * Falls back to SELECTORS_PROD for any unrecognised environment.
 *
 * @param {string} [baseUrl]  — defaults to BASE_URL from config
 * @returns {typeof SELECTORS_PROD}
 */
export function getSelectors(baseUrl = BASE_URL) {
  return isAngularEnv(baseUrl) ? SELECTORS_ANGULAR : SELECTORS_PROD;
}

/**
 * SELECTORS — backward-compatible default, auto-resolved from BASE_URL.
 * All existing test files importing { SELECTORS } continue to work with no changes.
 */
export const SELECTORS = getSelectors(BASE_URL);


// ═══════════════════════════════════════════════════════════════════════════════
//  Locator helpers
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Returns the first Playwright Locator from selectorList that is present+visible,
 * or null if none found within `timeout` ms total.
 */
export async function firstVisible(page, selectorList, timeout = 800) {
  for (const sel of selectorList) {
    try {
      const el = page.locator(sel).first();
      if (await el.count() > 0 && await el.isVisible({ timeout }).catch(() => false)) return el;
    } catch { /* continue */ }
  }
  return null;
}

/**
 * Returns the first Playwright Locator from selectorList that is present in DOM
 * (not necessarily visible).
 */
export async function firstPresent(page, selectorList) {
  for (const sel of selectorList) {
    try {
      const el = page.locator(sel).first();
      if (await el.count() > 0) return el;
    } catch { /* continue */ }
  }
  return null;
}

/**
 * Runtime selector resolver — use this inside tests when the page URL may
 * differ from the URL the script was launched with (e.g. after navigation).
 *
 * Example:
 *   const SEL = resolveSelectors(page.url());
 *   const inp = await firstVisible(page, SEL.searchInput);
 *
 * @param {import('playwright').Page} page
 * @returns {typeof SELECTORS_PROD}
 */
export function resolveSelectors(page) {
  return getSelectors(page.url());
}


