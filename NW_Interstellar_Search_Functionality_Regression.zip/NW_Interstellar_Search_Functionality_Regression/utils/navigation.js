/**
 * utils/navigation.js
 * Page navigation helpers — home, contact, help-center.
 */

import { config } from '../core/config.js';
import { waitForPageReady, dismissCookieBanner } from './helpers.js';

export async function navigateToHomePage(page) {
  await page.goto(config.homeUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
  await dismissCookieBanner(page);
  await waitForPageReady(page);
}

export async function navigateToContactPage(context) {
  console.log(`\n Navigating to contact page...`);
  const contactPage = await context.newPage();
  await contactPage.setExtraHTTPHeaders(config.headers);
  await contactPage.goto(`${config.homeUrl}${config.contactPath}`, { waitUntil: 'domcontentloaded', timeout: 30000 });
  await dismissCookieBanner(contactPage);
  await waitForPageReady(contactPage);
  return contactPage;
}

export async function clickHelpCenterLink(page) {
  const frames = [page.mainFrame(), ...page.frames()];
  for (const frame of frames) {
    const link = frame.locator('a:has-text("Help center")').first();
    if (await link.count() > 0) {
      await link.click();
      return true;
    }
  }
  throw new Error('Help center link not found');
}
