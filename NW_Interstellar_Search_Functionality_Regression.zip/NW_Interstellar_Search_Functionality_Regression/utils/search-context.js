/**
 * utils/search-context.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Single source of truth for per-surface search behaviour variations.
 *
 * Each search surface (Global Header, Contact Page, SR Page Global Header) has
 * its own Yext widget instance with slightly different configuration:
 *   • Different input element IDs → different inputSelectors
 *   • Different ARIA option-ID prefixes (affects aria-controls validation)
 *   • Different aria-expanded collapse behaviour per browser
 *     Chrome removes the attribute (null) on collapse; Edge sets it to "false"
 *   • Different reset URLs for test-state recovery
 *
 * Usage — pass a context preset into any test function:
 *   import { SEARCH_CONTEXTS, isAriaCollapsed } from '../utils/search-context.js';
 *   await testAriaStateValidation(page, SEARCH_CONTEXTS.globalHeader);
 *   await testAdvancedAutocompleteBehavior(page, SEARCH_CONTEXTS.contactPage);
 *   await testSearchResultsPageAdvancedAutocomplete(page, SEARCH_CONTEXTS.srPageGlobalHeader);
 *
 * Extending — to support a new surface, add an entry here; no test code changes needed.
 */

import { config } from '../core/config.js';

// ── Shared aria-expanded collapse checker ─────────────────────────────────────
/**
 * Returns true if the aria-expanded value represents a collapsed state.
 *
 * Behaviour varies by browser and Yext widget variant:
 *   • Edge / Firefox      → sets aria-expanded="false" on collapse
 *   • Chrome (SR page)    → removes the attribute entirely (null = collapsed)
 *   • Never-had-it (null) → treat as collapsed (not yet opened)
 *
 * @param {string|null} value — result of element.getAttribute('aria-expanded')
 * @returns {boolean}
 */
export function isAriaCollapsed(value) {
  return value === 'false' || value === null;
}

/**
 * Returns true if the aria-expanded value represents an open/expanded state.
 * @param {string|null} value
 * @returns {boolean}
 */
export function isAriaExpanded(value) {
  return value === 'true';
}

/**
 * Returns a human-readable label for an aria-expanded value in report detail strings.
 * @param {string|null} value
 * @returns {string}
 */
export function ariaLabel(value) {
  if (value === null) return 'null(attr-removed=collapsed)';
  return value;
}

// ── Search surface context presets ────────────────────────────────────────────
export const SEARCH_CONTEXTS = {

  /**
   * Global Header Search — Homepage (nationwide.com)
   * Yext widget instance: search-bar-1
   */
  globalHeader: {
    platform:       'Desktop',
    pageLabel:      'Homepage',
    component:      'Global Header Search',

    // Input selectors — tried in order, first visible wins
    inputSelectors: [
      '#yxt-SearchBar-input--search-bar-1',
      'input[aria-label="Conduct a search"]',
      '#header input.js-yext-query',
    ],

    // ARIA — option IDs use this prefix (e.g. yxt-AutoComplete-option-search-bar-1.autocomplete-0-0)
    optionIdPrefix: 'search-bar-1.autocomplete',

    // URL to navigate to when resetting test state
    resetUrl: () => config.homeUrl,

    // aria-expanded collapse: Chrome removes the attribute (null), Edge sets "false"
    // Both are valid — use isAriaCollapsed() for all checks
    ariaExpandedCollapseAllowsNull: true,

    // Keystroke delay (ms) — slower for reliable Yext keystroke event detection
    keystrokeDelay: 80,

    // Whether this surface supports aria-controls → listbox linkage
    supportsAriaControls: true,

    // Whether this surface supports aria-activedescendant on ArrowDown
    supportsActivedescendant: true,
  },

  /**
   * Contact Page Search — /personal/contact (nationwide.com)
   * Yext widget instance: help-search-bar
   */
  contactPage: {
    platform:       'Desktop',
    pageLabel:      'Contact Page',
    component:      'Contact Page Search',

    inputSelectors: [
      '#yxt-SearchBar-input--help-search-bar',
      'input[aria-label="Conduct a search"]',
      '.nw-help-center-search input.js-yext-query',
    ],

    optionIdPrefix: 'help-search-bar.autocomplete',

    resetUrl: () => `${config.homeUrl.replace(/\/$/, '')}${config.contactPath}`,

    ariaExpandedCollapseAllowsNull: false,  // Contact page Edge & Chrome both set "false"

    keystrokeDelay: 50,

    supportsAriaControls: true,
    supportsActivedescendant: true,
  },

  /**
   * Search Results Page — Global Header Search (nationwide.com/searchresults/…)
   * Yext widget instance: SearchBar (capital S, no number)
   * DOM confirmed: same Yext widget structure as homepage but different ID suffix
   */
  srPageGlobalHeader: {
    platform:       'Desktop',
    pageLabel:      'Search Results Page',
    component:      'Global Header Search',

    inputSelectors: [
      // Confirmed XPath: //*[@id="header"]/div[1]/div/div  →  input inside
      '#header > div.ch-searchbar.component.yxt-Answers-component.yxt-SearchBar-wrapper > div > div input.js-yext-query',
      '#header > div.ch-searchbar.component.yxt-Answers-component.yxt-SearchBar-wrapper > div > div input',
      '#header input.js-yext-query.yxt-SearchBar-input',
      '#header input[aria-autocomplete="list"]',
      '#header input[aria-label="Conduct a search"]',
    ],

    // Note: option IDs contain a DOT — yxt-AutoComplete-option-SearchBar.autocomplete-0-N
    // CSS querySelector treats '.' as class separator — never use ID as CSS selector directly
    optionIdPrefix: 'SearchBar.autocomplete',

    resetUrl: () => `${config.homeUrl.replace(/\/$/, '')}${config.searchResultsBaseUrl || '/searchresults/personal/result?=&referrerPageUrl=&query='}`,

    // Chrome removes aria-expanded on collapse on this page (confirmed from test results)
    ariaExpandedCollapseAllowsNull: true,

    keystrokeDelay: 80,

    supportsAriaControls: true,
    supportsActivedescendant: true,
  },

  /**
   * Search Results Page — Page-Embedded Search Bar (nationwide.com/searchresults/…)
   * Yext widget instance: SearchBar (the in-page search box, NOT the global header bar)
   * Input ID: #yxt-SearchBar-input--SearchBar
   */
  srPageSearchBar: {
    platform:       'Desktop',
    pageLabel:      'Search Results Page',
    component:      'SR Page Search Bar',

    inputSelectors: [
      // Confirmed XPath: //*[@id="js-answersSearchBar"]/div/div  →  input inside
      // Container: #js-answersSearchBar — the in-page Yext bar, NOT the Global Header
      '#js-answersSearchBar input.js-yext-query',
      '#js-answersSearchBar input[aria-autocomplete="list"]',
      '#js-answersSearchBar input',
      // Broad fallbacks scoped outside #header
      'main input.js-yext-query',
      'main input[aria-autocomplete="list"]',
    ],

    optionIdPrefix: 'SearchBar.autocomplete',

    resetUrl: () => `${config.homeUrl.replace(/\/$/, '')}${config.searchResultsBaseUrl || '/searchresults/personal/result?=&referrerPageUrl=&query='}`,

    ariaExpandedCollapseAllowsNull: true,
    keystrokeDelay: 80,
    supportsAriaControls: true,
    supportsActivedescendant: true,
  },

  /**
   * Angular — Global Header Search (uat-ng.nationwide.com)
   * bolt-autocomplete web component — shadow DOM
   */
  angularGlobalHeader: {
    platform:       'Desktop',
    pageLabel:      'Homepage (Angular)',
    component:      'Global Header Search',

    inputSelectors: [
      '#search bolt-autocomplete >> input[data-test="input"]',
      'bolt-autocomplete >> input[data-test="input"]',
      'input[aria-label="Search"][role="combobox"]',
    ],

    optionIdPrefix: null,   // bolt-autocomplete uses dynamic IDs — not used for validation

    resetUrl: () => config.homeUrl,

    ariaExpandedCollapseAllowsNull: true,   // bolt removes attribute on close in some versions

    keystrokeDelay: 80,

    supportsAriaControls: true,
    supportsActivedescendant: false,        // bolt uses aria-selected, not aria-activedescendant
  },

  /**
   * Angular — Contact Page Search (uat-ng.nationwide.com/personal/contact)
   * bolt-autocomplete web component — shadow DOM
   */
  angularContactPage: {
    platform:       'Desktop',
    pageLabel:      'Contact Page (Angular)',
    component:      'Contact Page Search',

    inputSelectors: [
      'div.nw-help-center-search bolt-autocomplete >> input[data-test="input"]',
      'bolt-autocomplete >> input[data-test="input"]',
      'input[aria-label="Search"][role="combobox"]',
    ],

    optionIdPrefix: null,

    resetUrl: () => `${config.homeUrl.replace(/\/$/, '')}${config.contactPath}`,

    ariaExpandedCollapseAllowsNull: true,

    keystrokeDelay: 80,

    supportsAriaControls: true,
    supportsActivedescendant: false,
  },

};

/**
 * Dynamically select the correct context preset based on the current page URL.
 *
 * @param {string} url   — page.url()
 * @param {boolean} isAngular — result of isAngularEnv(url)
 * @returns {object}     — one of the SEARCH_CONTEXTS presets
 */
export function resolveSearchContext(url, isAngular = false) {
  if (isAngular) {
    if (url.includes('/contact')) return SEARCH_CONTEXTS.angularContactPage;
    return SEARCH_CONTEXTS.angularGlobalHeader;
  }
  if (url.includes('/searchresults') || url.includes('/result?')) return SEARCH_CONTEXTS.srPageGlobalHeader;
  if (url.includes('/contact'))                                    return SEARCH_CONTEXTS.contactPage;
  return SEARCH_CONTEXTS.globalHeader;
}
