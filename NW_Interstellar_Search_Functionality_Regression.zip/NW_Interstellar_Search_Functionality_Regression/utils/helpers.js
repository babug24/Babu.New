/**
 * utils/helpers.js
 * Page-readiness gate, search activation, cookie banner dismissal.
 */

import { config, trunc } from '../core/config.js';
import { SELECTORS, resolveSelectors, firstVisible, isAngularEnv } from './selectors.js';

// ── waitForPageReady ──────────────────────────────────────────────────────────
export async function waitForPageReady(page, {
  contentSelector  = 'main, [role="main"], #main-content, .main-content, body > *:not(script):not(style)',
  loadingSelectors = SELECTORS.loading,
  animationTimeout = 4000,
  mutationQuiet    = 500,
  mutationMaxWait  = 5000,
  networkTimeout   = 10000,
  finalBuffer      = 500,
  verbose          = false,
} = {}) {
  const t0       = Date.now();
  const log      = verbose ? (msg) => console.log(msg) : () => {};
  const warnings = [];

  if (verbose) console.log('   Waiting for page to be fully ready...');

  // 1. Network idle
  log('  -> Network idle...');
  try {
    await page.waitForLoadState('networkidle', { timeout: networkTimeout });
  } catch {
    warnings.push('network-idle-timeout');
  }

  // 2. Angular stability
  const isAngular = await page.evaluate(() => {
    try {
      return !!(window.getAllAngularRootElements?.()?.length ||
                window.ng?.probe ||
                document.querySelector('[ng-version]') ||
                document.querySelector('app-root'));
    } catch { return false; }
  }).catch(() => false);

  if (isAngular) {
    try {
      await page.evaluate(() => new Promise((resolve, reject) => {
        const tid = setTimeout(() => reject(new Error('Angular stability timeout')), 8000);
        function check() {
          try {
            const roots = window.getAllAngularRootElements?.() || [];
            if (!roots.length) { clearTimeout(tid); resolve(); return; }
            const ts = roots.map(el => window.getAngularTestability?.(el)).filter(Boolean);
            if (!ts.length) { clearTimeout(tid); resolve(); return; }
            if (ts.every(t => t.isStable?.() ?? true)) { clearTimeout(tid); resolve(); }
            else ts[0].whenStable?.(() => { clearTimeout(tid); resolve(); });
          } catch { clearTimeout(tid); resolve(); }
        }
        check();
      }));
    } catch { warnings.push('angular-timeout'); }
  }

  // 3. Main content visible
  const sels = contentSelector.split(',').map(s => s.trim());
  let found = false;
  for (const sel of sels) {
    try {
      await page.waitForSelector(sel, { state: 'visible', timeout: 5000 });
      found = true; break;
    } catch { /* try next */ }
  }
  if (!found) warnings.push('content-timeout');

  // 4. Loading indicators removed
  for (const sel of loadingSelectors) {
    try {
      if (await page.locator(sel).count() > 0)
        await page.waitForSelector(sel, { state: 'hidden', timeout: 8000 }).catch(() => {});
    } catch { /* not present */ }
  }

  // 5. DOM mutation quiet
  try {
    await page.evaluate(({ quiet, maxWait }) => new Promise(resolve => {
      const deadline = Date.now() + maxWait;
      let quietTimer;
      const obs = new MutationObserver(() => {
        clearTimeout(quietTimer);
        if (Date.now() > deadline) { obs.disconnect(); resolve(); return; }
        quietTimer = setTimeout(() => { obs.disconnect(); resolve(); }, quiet);
      });
      obs.observe(document.body, { childList: true, subtree: true, attributes: true });
      quietTimer = setTimeout(() => { obs.disconnect(); resolve(); }, quiet);
    }), { quiet: mutationQuiet, maxWait: mutationMaxWait });
  } catch { /* ignore */ }

  // 6. Animations / transitions
  try {
    await page.evaluate(timeout => new Promise(resolve => {
      const start = Date.now();
      function check() {
        const running = (document.getAnimations?.() || []).filter(a => a.playState === 'running');
        if (!running.length || Date.now() - start > timeout) { resolve(); return; }
        Promise.allSettled(running.map(a => a.finished)).then(() => resolve()).catch(() => resolve());
      }
      check();
    }), animationTimeout);
  } catch { /* ignore */ }

  // 7. Final buffer
  await new Promise(r => setTimeout(r, finalBuffer));

  const ms = Date.now() - t0;
  const warnStr = warnings.length ? ` [WARN] [${warnings.join(', ')}]` : '';
  console.log(`   Page ready (${ms}ms)${warnStr}`);
}

// ── findAndActivateSearch ─────────────────────────────────────────────────────
/**
 * Finds the visible search input. On mobile (isMobile=true) always clicks the
 * search icon first. On desktop tries the input directly, falling back to icon.
 * Returns a Playwright Locator for the input, or throws.
 */
export async function findAndActivateSearch(page, isMobile = false) {
  // Resolve selectors at runtime based on the live page URL (Prod vs Angular)
  const SEL     = resolveSelectors(page);
  const isAngular = isAngularEnv(page.url());
  let searchInput = null;

  // Angular desktop: input is directly visible — no icon click required.
  // Chrome DevTools recorder confirmed: click pierce/[data-test='input'] directly.
  // Prod desktop / mobile: may need icon click to reveal input.
  if (isMobile && !isAngular) {
    const icon = await firstVisible(page, SEL.searchIcon, 2000);
    if (icon) {
      await icon.click();
      console.log(`   Search icon clicked (mobile-first)`);
      await page.waitForTimeout(600);
    }
  }

  // Find visible input — give Angular extra time (6 s) since page is heavier
  const waitMs  = isAngular ? 6000 : 4000;
  const timeout = isAngular ? 800  : 400;
  const deadline = Date.now() + waitMs;
  while (Date.now() < deadline && !searchInput) {
    searchInput = await firstVisible(page, SEL.searchInput, timeout);
    if (!searchInput) await page.waitForTimeout(300);
  }

  // Prod desktop fallback: try icon then re-check
  if (!searchInput && !isMobile && !isAngular) {
    const icon = await firstVisible(page, SEL.searchIcon);
    if (icon) {
      await icon.click();
      await page.waitForTimeout(600);
      console.log(`   Search icon clicked (desktop fallback)`);
    }
    const deadline2 = Date.now() + 3000;
    while (Date.now() < deadline2 && !searchInput) {
      searchInput = await firstVisible(page, SEL.searchInput, 400);
      if (!searchInput) await page.waitForTimeout(300);
    }
  }

  // Last resort: pierce shadow DOM via evaluate for Angular bolt-autocomplete
  if (!searchInput) {
    const found = await page.evaluate(() => {
      // Try shadow DOM walk for bolt-autocomplete
      const hosts = document.querySelectorAll('bolt-autocomplete, bolt-textfield-wc, bolt-autocomplete-wc');
      for (const host of hosts) {
        const inp = host.shadowRoot?.querySelector('input[data-test="input"]') ||
                    host.shadowRoot?.querySelector('input[role="combobox"]') ||
                    host.shadowRoot?.querySelector('input');
        if (inp) { inp.focus(); return true; }
      }
      // Prod fallback
      const prod = document.querySelector('#yxt-SearchBar-input--search-bar-1');
      if (prod) { prod.style.visibility = 'visible'; prod.style.display = 'block'; prod.focus(); return true; }
      return false;
    }).catch(() => false);
    if (found) {
      await page.waitForTimeout(400);
      // Re-try firstVisible after shadow focus
      searchInput = await firstVisible(page, SEL.searchInput, 1000);
    }
  }

  if (!searchInput) throw new Error(`Search input not found on ${page.url()} after all activation strategies`);
  return searchInput;
}

// ── Cookie banner dismissal ───────────────────────────────────────────────────
export async function dismissCookieBanner(page, { silent = false } = {}) {
  const SEL = resolveSelectors(page);
  for (const sel of SEL.cookieBanner) {
    try {
      const el = page.locator(sel).first();
      if (await el.count() > 0 && await el.isVisible({ timeout: 1000 }).catch(() => false)) {
        await el.click({ timeout: 3000 });
        if (!silent) console.log(`   Cookie banner dismissed: ${sel}`);
        await page.waitForTimeout(500);
        return true;
      }
    } catch { /* try next */ }
  }
  return false;
}

/**
 * clearAndType — clear the input, validate it is empty, then type term char-by-char.
 *
 * Validation: captures the pre-clear value, calls fill('') to clear, reads back
 * the value and warns to the console if the field is not empty after clearing.
 * Returns { preClearValue, clearedOk } so callers can surface the check in reports.
 *
 * Why pressSequentially (not fill): Yext binds keydown/keypress/keyup listeners
 * for its debounce autocomplete — fill() emits a single bulk input event that
 * does not trigger autocomplete. pressSequentially fires per-key events.
 *
 * @param {import('playwright').Locator} input
 * @param {string} term
 * @param {{ delay?: number }} [opts]
 * @returns {Promise<{ preClearValue: string, clearedOk: boolean }>}
 */
export async function clearAndType(input, term, { delay = 80 } = {}) {
  const preClearValue = await input.inputValue().catch(() => '');
  await input.fill('');                                      // reliable cross-browser clear
  const afterClear = await input.inputValue().catch(() => '');
  const clearedOk  = afterClear === '';
  if (!clearedOk) {
    console.warn(`     [clearAndType] ⚠ field not empty after clear — residual="${afterClear}"`);
  } else if (preClearValue) {
    console.log(`     [clearAndType] pre-clear="${preClearValue}" → cleared ✓`);
  }
  await input.pressSequentially(term, { delay });
  return { preClearValue, clearedOk };
}

export function registerCookieAutoDismiss(page) {
  page.on('load', () => dismissCookieBanner(page, { silent: true }).catch(() => {}));
}
