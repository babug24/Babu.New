/**
 * run-e2e.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Single-execution Search Validation E2E runner.
 * Runs ALL suites from the modular test files and produces:
 *   • Console output with live progress
 *   • helpcenter_search_validation_<timestamp>.json  — machine-readable summary
 *   • helpcenter_search_validation_<timestamp>.html  — styled HTML report
 *   • helpcenter_search_validation_<timestamp>.log   — full console log
 *
 * Usage:
 *   node run-e2e.js
 *   node run-e2e.js --headless
 *   node run-e2e.js --skip-mobile
 *   node run-e2e.js --skip-perf
 *   node run-e2e.js --skip-a11y
 *   node run-e2e.js --skip-content
 *   node run-e2e.js --desktop-only       (desktop + contact suites only)
 *   node run-e2e.js --skip-edge-browser  (skip Edge browser suites 11 + 12)
 *   node run-e2e.js --skip-submit        (skip submit button suite 13)
 *   node run-e2e.js --skip-visual        (skip visual presence suites 15a/b)
 *   node run-e2e.js --skip-analytics     (skip analytics suite 14)
 *   node run-e2e.js --env=UAT-Angular    (pick URL from url.csv)
 *
 * Suites executed (in order):
 *   1.   Desktop Chrome — Global Header Search              (6 tests)
 *   1R.  Desktop Chrome — SR Page Global Header Search      (7 tests)
 *   1R2. Desktop Chrome — SR Page Search Bar                (7 tests)
 *   1R3. Desktop Chrome — SR Page Clear Button               (6 tests)
 *   2.   Desktop Chrome — Contact Page Search              (7 tests)
 *   3.  Advanced Autocomplete                   (3 tests)
 *   4.  Edge Cases — Desktop Chrome · Global Header Search · Homepage (8 tests)
 *   5.  No-Results State                        (3 terms)
 *   6a. ARIA Validation — Home Page             (15 checks)
 *   6b. ARIA Validation — Contact Page          (15 checks)
 *   7.  Search Results Content                  (3 terms)
 *   8.  Performance                             (timing)
 *   9.  Accessibility                           (a11y checks)
 *   10.  Mobile/Tablet Viewports                 (5 devices × Global Header + Contact)
 *   10R. Mobile/Tablet — Search Results Page      (5 devices)
 *   11.  Desktop Edge — Global Header Search          (6 tests)
 *   11R.  Desktop Edge — SR Page Global Header Search  (7 tests)
 *   11R2. Desktop Edge — SR Page Search Bar            (7 tests)
 *   11R3. Desktop Edge — SR Page Clear Button           (6 tests)
 *   12. Desktop Edge — Contact Page Search            (7 tests)
 *   12R. Desktop Edge — Search Results Page           (7 tests)
 *   13. Submit Button — Global Header + Contact (4 checks × 2 = 8)  [AC-30]
 *   14. Analytics / dataLayer Validation        (AC-66–69, 7 checks)
 *   15a. Visual Presence — Global Header Search (18 checks)
 *   15b. Visual Presence — Contact Page Search  (18 checks)
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { chromium }           from 'playwright';
import fs                     from 'fs';
import path                   from 'path';
import { fileURLToPath }      from 'url';
import { config }             from './core/config.js';
import { isAngularEnv, SELECTORS_PROD } from './utils/selectors.js';
import { SEARCH_CONTEXTS }              from './utils/search-context.js';
import { waitForPageReady, dismissCookieBanner, registerCookieAutoDismiss }
                              from './utils/helpers.js';

// ── Modular suites ────────────────────────────────────────────────────────────
import { testDesktopSearchOnDevice }          from './tests/desktop.js';
import {
  testContactPageAdvancedAutocomplete,
  testSearchResultsPageAdvancedAutocomplete,
  testAdvancedAutocompleteBehavior,
  testEdgeCases,
  testNoResultsState,
  testAriaStateValidation,
  testSrPageClearButton,
}                                             from './tests/advanced.js';
import { testMobileViewports, testContactPageOnDevice, testMobileSrPageViewports } from './tests/mobile.js';
import { testPerformance } from './tests/perf-a11y.js';
import { testSearchResultsContent }           from './tests/content.js';
import { testSubmitButton, testVisualPresence } from './tests/elements.js';
import { testAnalyticsTracking }              from './tests/analytics.js';

// ── CLI flags ─────────────────────────────────────────────────────────────────
const headless      = process.argv.includes('--headless');
const desktopOnly   = process.argv.includes('--desktop-only');
const srOnly        = process.argv.includes('--sr-only');
const skipMobile    = process.argv.includes('--skip-mobile')   || desktopOnly;
const skipPerf      = process.argv.includes('--skip-perf')     || desktopOnly;
const skipA11y      = true; // Accessibility suite permanently disabled — functional regression only
const skipContent   = process.argv.includes('--skip-content')  || desktopOnly;
const skipAdvanced  = process.argv.includes('--skip-advanced') || desktopOnly;
const skipEdge      = process.argv.includes('--skip-edge')     || desktopOnly;
const skipNoResults = process.argv.includes('--skip-noresults')|| desktopOnly;
const skipAria      = process.argv.includes('--skip-aria')      || desktopOnly;
const skipEdgeBrowser = process.argv.includes('--skip-edge-browser');
const skipSubmit      = process.argv.includes('--skip-submit');
const skipAnalytics   = process.argv.includes('--skip-analytics');
const skipVisual      = process.argv.includes('--skip-visual');
const focusedRerun    = process.argv.includes('--rerun-failed');
const excludeAnalytics= process.argv.includes('--exclude-analytics');

// ── Output paths ──────────────────────────────────────────────────────────────
const __dir       = path.dirname(fileURLToPath(import.meta.url));
const REPORTS_DIR = path.join(__dir, 'reports');
if (!fs.existsSync(REPORTS_DIR)) fs.mkdirSync(REPORTS_DIR, { recursive: true });
const _ts         = new Date().toISOString().replace(/[:.]/g, '-').replace('T', '_').slice(0, 19);
const REPORT_STEM = `helpcenter_search_validation_${_ts}`;
const LOG_FILE    = path.join(REPORTS_DIR, `${REPORT_STEM}.log`);
const JSON_FILE   = path.join(REPORTS_DIR, `${REPORT_STEM}.json`);
const HTML_FILE   = path.join(REPORTS_DIR, `${REPORT_STEM}.html`);

// ── Dual logger ───────────────────────────────────────────────────────────────
const logLines = [];
fs.writeFileSync(LOG_FILE, `=== run-e2e.js started ${new Date().toISOString()} ===\n`, 'utf8');
const log = (...args) => {
  const line = args.join(' ');
  process.stdout.write(line + '\n');
  logLines.push(line);
  try { fs.appendFileSync(LOG_FILE, line + '\n', 'utf8'); } catch (_) {}
};

// ── Badge helpers ─────────────────────────────────────────────────────────────
const badge = s =>
  s === 'PASSED'  ? '✓ PASSED'  :
  s === 'FAILED'  ? '✗ FAILED'  :
  s === 'WARN'    ? '⚠ WARN'    :
  s === 'SKIPPED' ? '~ SKIP'    :
  s === 'NOT_IN_SCOPE' ? '◌ N/SCOPE' :
  s === 'WARNING' ? '⚠ WARNING' : `~ ${s}`;

const isMinorVariation = (detail = '') =>
  /passed with minor variation/i.test(String(detail || ''));

const normalizeStatus = (status, detail = '') => {
  if (status === 'NOT_IN_SCOPE') return null;
  if (status === 'PASSED') return 'PASSED';
  if (status === 'WARN' || status === 'WARNING') {
    return isMinorVariation(detail) ? 'PASSED' : 'WARN';
  }
  if (status === 'SKIPPED') return 'FAILED';
  return 'FAILED';
};

function loadLatestRunJson(reportsDir) {
  try {
    const files = fs.readdirSync(reportsDir)
      .filter(f => /^helpcenter_search_validation_.*\.json$/i.test(f))
      .map(f => ({
        file: f,
        full: path.join(reportsDir, f),
        mtime: fs.statSync(path.join(reportsDir, f)).mtimeMs,
      }))
      .sort((a, b) => b.mtime - a.mtime);
    if (!files.length) return null;
    return JSON.parse(fs.readFileSync(files[0].full, 'utf8'));
  } catch {
    return null;
  }
}

function failedSuitesFromLastRun(lastJson) {
  const failed = new Set();
  for (const s of (lastJson?.suites || [])) {
    const hasFail = (s.results || []).some(r => normalizeStatus(r.status, r.detail || r.error || '') === 'FAILED');
    if (hasFail) failed.add(s.label);
  }
  return failed;
}

const businessDetail = (testName, finalStatus) => {
  if (finalStatus === 'WARN') {
    return 'Validation completed with warnings. Please review this scenario detail.';
  }
  const t = String(testName || '').toLowerCase();
  if (t.includes('option count')) {
    return finalStatus === 'PASSED'
      ? 'Expected suggestion count is displayed.'
      : 'Expected suggestion count was not shown. Please recheck autocomplete behavior for this viewport.';
  }
  if (t.includes('submit btn') || t.includes('submit button')) {
    return finalStatus === 'PASSED'
      ? 'Submit button behavior matched expectations.'
      : 'Submit button behavior did not match expectations. Please recheck search submit flow.';
  }
  if (t.includes('aria') || t.includes('a11y') || t.includes('accessibility')) {
    return finalStatus === 'PASSED'
      ? 'Accessibility behavior matched expected state.'
      : 'Accessibility behavior did not meet expectations. Please review this accessibility scenario.';
  }
  if (t.includes('visual presence') || t.includes('vp-')) {
    return finalStatus === 'PASSED'
      ? 'Required page elements are visible and usable.'
      : 'Required page elements were not in expected state. Please review page rendering for this scenario.';
  }
  if (t.includes('analytics') || t.includes('datalayer')) {
    return finalStatus === 'PASSED'
      ? 'Tracking behavior matched expectations.'
      : 'Tracking behavior did not match expectations. Please recheck analytics capture for this flow.';
  }
  if (t.includes('performance')) {
    return finalStatus === 'PASSED'
      ? 'Performance stayed within expected limits.'
      : 'Performance did not meet expected limits. Please review page and search response timing.';
  }
  return finalStatus === 'PASSED'
    ? 'Validation passed for this scenario.'
    : 'Validation failed for this scenario. Please review the related user flow.';
};

const highLevelFailureReason = (rawDetail = '') => {
  const text = String(rawDetail || '')
    .replace(/\s+/g, ' ')
    .replace(/[\r\n]+/g, ' ')
    .trim();
  if (!text) return '';

  const normalized = text
    .replace(/\b(error|exception)\s*:\s*/ig, '')
    .replace(/^failed\s*[:\-]?\s*/i, '')
    .trim();

  const firstSentence = normalized.match(/^[^.!?]+[.!?]?/)?.[0]?.trim() || normalized;
  const capped = firstSentence.length > 160 ? `${firstSentence.slice(0, 157).trim()}...` : firstSentence;

  if (!capped) return '';
  if (/^validation failed for this scenario/i.test(capped)) return '';
  return capped;
};

// ── Skipped-suite placeholder ─────────────────────────────────────────────────
function skippedSuite(label, flag) {
  return {
    label,
    skipped: true,
    results: [{ name: `Suite skipped (${flag})`, test: `Suite skipped (${flag})`, status: 'SKIPPED', detail: `Omitted via ${flag} CLI flag` }],
    passed:  0,
    total:   0,
  };
}

function notInScopeSuite(label, reason = 'Not in scope for focused rerun') {
  return {
    label,
    notInScope: true,
    results: [{ name: 'Not in scope', test: 'Not in scope', status: 'NOT_IN_SCOPE', detail: reason }],
    passed: 0,
    total: 0,
  };
}

// ── Per-suite error barrier — prevents one crashing suite from killing the run ─
// Usage: const suite = await runSuite(suites, 'Label', () => testFn(page, ...));
async function runSuite(suites, label, fn) {
  try {
    const raw   = await fn();
    const suite = normaliseSuite(label, raw);
    printSuite(suite);
    suites.push(suite);
    return suite;
  } catch (err) {
    const errMsg = (err.message || String(err)).substring(0, 300);
    log(`\n  [SUITE CRASH] ${label}\n  ${errMsg}`);
    const suite = {
      label,
      results: [{ name: 'Suite crashed', test: 'Suite crashed', status: 'FAILED', error: errMsg }],
      passed: 0,
      total:  1,
    };
    printSuite(suite);
    suites.push(suite);
    return suite;
  }
}

let focusedFailedSuites = new Set();
if (focusedRerun) {
  const last = loadLatestRunJson(REPORTS_DIR);
  focusedFailedSuites = failedSuitesFromLastRun(last);
  if (excludeAnalytics) {
    focusedFailedSuites.delete('Analytics / dataLayer Validation (AC-66–69)');
  }
}

const shouldRunFocused = (label) => {
  if (srOnly && !/(SR Page|Search Results Page)/i.test(label)) return false;
  return !focusedRerun || focusedFailedSuites.has(label);
};

// ── Normalise any suite return into {results[], passed, total, label} ─────────
function normaliseSuite(label, rawReturn) {
  if (!rawReturn) return { label, results: [], passed: 0, total: 0 };

  // {device, results[], passed, total}  ← analytics / elements / advanced return this
  if (rawReturn.results && Array.isArray(rawReturn.results)) {
    const arr = rawReturn.results;
    const p   = rawReturn.passed ?? arr.filter(r => r.status === 'PASSED').length;
    return { label, results: arr, passed: p, total: rawReturn.total ?? arr.length };
  }

  // plain array of {name/test, status}
  if (Array.isArray(rawReturn)) {
    const arr = rawReturn;
    const p   = arr.filter(r => r.status === 'PASSED').length;
    return { label, results: arr, passed: p, total: arr.length };
  }

  // perf metrics object
  if (rawReturn.performanceStatus !== undefined) {
    const results = [
      { name: 'Page Load',      status: rawReturn.pageLoadTime     < 4000 ? 'PASSED' : 'WARNING', detail: `${rawReturn.pageLoadTime}ms` },
      { name: 'Search Response',status: rawReturn.searchResponseTime < 4000 ? 'PASSED' : 'WARNING', detail: `${rawReturn.searchResponseTime}ms` },
    ];
    const p = results.filter(r => r.status === 'PASSED').length;
    return { label, results, passed: p, total: results.length };
  }

  return { label, results: [], passed: 0, total: 0 };
}

// ── Normalise mobile viewports (array of device suites) ───────────────────────
function normaliseMobile(allDeviceResults) {
  if (!Array.isArray(allDeviceResults)) return { label: 'Mobile Viewports', results: [], passed: 0, total: 0 };
  const results = [];
  for (const dr of allDeviceResults) {
    const deviceName = dr.device || dr.name || '?';
    const arr = Array.isArray(dr.results) ? dr.results : [];
    if (arr.length) {
      for (const r of arr) {
        results.push({ ...r, device: deviceName, name: r.test || r.name || '?' });
      }
      continue;
    }

    if (dr.status) {
      results.push({
        device: deviceName,
        status: dr.status,
        name: 'Mobile suite execution',
        test: 'Mobile suite execution',
        error: dr.error || dr.detail || 'Device execution failed before test rows were captured.'
      });
    }
  }
  const p = results.filter(r => r.status === 'PASSED').length;
  return { label: 'Mobile Viewports (5 devices)', results, passed: p, total: results.length };
}

// ── Print suite results to console ───────────────────────────────────────────
function printSuite(suite) {
  log(`\n${'─'.repeat(62)}`);
  log(` ${suite.label}`);
  log('─'.repeat(62));
  for (const r of suite.results) {
    const name   = r.test || r.name || '?';
    const device = r.device ? `[${r.device}] ` : '';
    const detail = r.detail || r.error || '';
    log(`  ${badge(r.status).padEnd(12)} ${device}${name}${detail ? `  — ${detail.toString().substring(0, 90)}` : ''}`);
  }
  const w = suite.results.filter(r => r.status === 'WARN' || r.status === 'WARNING').length;
  const f = suite.results.filter(r => r.status === 'FAILED').length;
  const s = suite.results.filter(r => r.status === 'SKIPPED').length;
  log(`\n  ${suite.passed} passed | ${f} failed | ${w} warn | ${s} skipped  (of ${suite.total})`);
}

// ── HTML report builder ───────────────────────────────────────────────────────
function buildHtml(suites, grandPassed, grandFailed, grandWarn, elapsed) {
  const e = s => String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

  const suiteStats = suite => {
    const statuses = suite.results.map(r => normalizeStatus(r.status, r.detail || r.error || '')).filter(Boolean);
    const passed = statuses.filter(s => s === 'PASSED').length;
    const failed = statuses.filter(s => s === 'FAILED').length;
    const warn   = statuses.filter(s => s === 'WARN').length;
    const total  = statuses.length;
    return { passed, failed, warn, total };
  };

  const normalizedTotals = suites.reduce((acc, s) => {
    const st = suiteStats(s);
    acc.passed += st.passed;
    acc.failed += st.failed;
    acc.warn   += st.warn;
    acc.total  += st.total;
    return acc;
  }, { passed: 0, failed: 0, warn: 0, total: 0 });

  const rowCls = s => {
    if (s === 'NOT_IN_SCOPE') return ' style="background:#f3f4f6"';
    const ns = normalizeStatus(s);
    if (ns === 'WARN') return ' style="background:#fff7e8"';
    return ns === 'FAILED' ? ' style="background:#ffe8e8"' : ' style="background:#edfaed"';
  };

  const badgeHtml = (s, detail = '') => {
    if (s === 'NOT_IN_SCOPE') return `<span class="badge skip">◌ NOT IN SCOPE</span>`;
    const ns = normalizeStatus(s, detail);
    if (ns === 'PASSED') return `<span class="badge pass">✓ PASSED</span>`;
    if (ns === 'WARN') return `<span class="badge warn">⚠ WARN</span>`;
    return `<span class="badge fail">✗ FAILED</span>`;
  };

  const suiteStatusBadge = (sf, sw, passed, total) =>
    sf > 0   ? `<span class="badge fail">✗ ${sf} FAILED</span>` :
    sw > 0   ? `<span class="badge warn">⚠ ${sw} WARN</span>` :
    total > 0 ? `<span class="badge pass">✓ ALL PASS</span>`     :
                `<span class="badge skip">◌ NOT IN SCOPE</span>`;

  const overallColor = normalizedTotals.failed > 0 ? '#c0001a' : normalizedTotals.warn > 0 ? '#b86800' : '#1a7a1a';
  const overallLabel = normalizedTotals.failed > 0 ? 'FAILURES FOUND' : normalizedTotals.warn > 0 ? 'WARNINGS FOUND' : 'ALL PASSED';

  const knownWarningsMap = new Map();
  for (const suite of suites) {
    for (const r of (suite.results || [])) {
      const rawDetail = (r.detail || r.error || '').toString();
      if (normalizeStatus(r.status, rawDetail) !== 'WARN') continue;
      const name = r.test || r.name || 'Unknown warning';
      const area = /aria|a11y|accessibility/i.test(suite.label)
        ? 'Accessibility observation'
        : /performance/i.test(suite.label)
          ? 'Performance observation'
          : 'Functional observation';
      const key = `${area}::${name}`;
      if (!knownWarningsMap.has(key)) {
        knownWarningsMap.set(key, { name, area, suites: new Set([suite.label]) });
      } else {
        knownWarningsMap.get(key).suites.add(suite.label);
      }
    }
  }
  const knownWarnings = [...knownWarningsMap.values()].map(w => ({
    ...w,
    suites: [...w.suites],
  }));

  const knownWarningsHtml = !knownWarnings.length
    ? ''
    : `
  <h2 style="margin-top:0;color:#b86800;border-bottom:2px solid #b86800;background:transparent;
             padding:0 0 5px;box-shadow:none">Known Warnings</h2>
  <div style="background:#fff8e6;border:1px solid #f3d48a;border-radius:8px;padding:12px 14px;margin:0 0 24px">
    <div style="font-size:12px;color:#7a5a00;margin-bottom:8px">Product-side observations captured during this run.</div>
    <ul style="margin:0;padding-left:18px;font-size:13px;line-height:1.5">
      ${knownWarnings.map(w => `<li><strong>${e(w.area)}:</strong> ${e(w.name)} <span style="color:#777">(${e(w.suites.join(' | '))})</span></li>`).join('')}
    </ul>
  </div>`;

  const modeCols = [
    desktopOnly ? 'Desktop Only' : 'Full E2E',
    headless    ? 'Headless' : 'Headed',
  ].join(' | ');

  // ── Suite IDs for anchor links ──────────────────────────────────────────────
  const slugs = suites.map((s, i) => `suite-${i}`);

  // ── Overview table ──────────────────────────────────────────────────────────
  const overviewRows = suites.map((suite, i) => {
    const st  = suiteStats(suite);
    const pct = st.total > 0 ? Math.round(st.passed / st.total * 100) : 0;
    const barColor = st.total === 0 ? '#bbb' : st.failed > 0 ? '#c0001a' : st.warn > 0 ? '#b86800' : '#1a7a1a';
    const statusBadge = suiteStatusBadge(st.failed, st.warn, st.passed, st.total);
    return `<tr${(suite.skipped || suite.notInScope) ? ' style="opacity:.7"' : ''}>
      <td style="padding:6px 10px">
        <a href="#${slugs[i]}" style="color:#003da5;text-decoration:none;font-weight:500">${e(suite.label)}</a>
      </td>
      <td style="padding:6px 10px;text-align:center">${statusBadge}</td>
      <td style="padding:6px 10px;text-align:center;font-size:12px">${st.passed} / ${st.total}</td>
      <td style="padding:6px 10px;min-width:120px">
        <div style="background:#ddd;border-radius:4px;height:10px;overflow:hidden">
          <div style="background:${barColor};width:${pct}%;height:100%"></div>
        </div>
        <div style="font-size:11px;color:#555;text-align:right">${pct}%</div>
      </td>
    </tr>`;
  }).join('');

  // ── Per-suite detail sections ───────────────────────────────────────────────
  let sections = '';
  for (let i = 0; i < suites.length; i++) {
    const suite = suites[i];
    const st = suiteStats(suite);
    const sf = st.failed;
    const sw = st.warn;
    const hdrColor = suite.skipped ? '#888' : sf > 0 ? '#c0001a' : '#003366';

    // Group ARIA checks visually by prefix (1a/1b → Group 1, 2a/2b → Group 2, 3a → Group 3)
    const isAria  = suite.label.toLowerCase().includes('aria');
    const hasDeviceCol = suite.results.some(r => !!r.device);
    let   rows    = '';
    let   lastGrp = '';
    let   lastDevice = '';
    const groupLabels = {
      '1': 'Group 1 — Open / Close States',
      '2': 'Group 2 — aria-activedescendant Updates',
      '3': 'Group 3 — aria-controls Listbox Reference',
      '4': 'Group 4 — Autocomplete Option Count + ARIA (Desktop / Mobile / Tablet + aria-setsize / aria-posinset)',
    };
    for (const r of suite.results) {
      const name = r.test || r.name || '?';
      if (isAria) {
        const grp = (name.match(/^(\d)/) || [])[1] || '';
        if (grp && grp !== lastGrp) {
          lastGrp = grp;
          const ariaColSpan = hasDeviceCol ? 4 : 3;
          rows += `<tr>
            <td colspan="${ariaColSpan}" style="padding:5px 10px;background:#eef2fa;font-weight:600;
                font-size:12px;color:#003366;border-top:2px solid #c5d0e8">
              ${e(groupLabels[grp] || `Group ${grp}`)}
            </td>
          </tr>`;
        }
      }
      const rawDetail = (r.detail || r.error || '').toString();
      const finalStatus = normalizeStatus(r.status, rawDetail);
      const displayDetail = finalStatus === 'FAILED'
        ? (highLevelFailureReason(rawDetail) || businessDetail(name, finalStatus))
        : businessDetail(name, finalStatus);
      const detailHtml = `<span style="color:#555;font-size:12px">${e(displayDetail)}</span>`;
      if (hasDeviceCol) {
        const currentDevice = r.device || '-';
        if (currentDevice !== lastDevice) {
          lastDevice = currentDevice;
          rows += `<tr>
        <td colspan="4" style="padding:6px 10px;background:#e8eef6;color:#003366;font-weight:700;border-top:2px solid #c5d0e8">📱 ${e(currentDevice)}</td>
      </tr>`;
        }
        rows += `<tr${rowCls(r.status)}>
        <td style="padding:5px 10px;white-space:nowrap">${e(r.device || '-')}</td>
        <td style="padding:5px 10px">${e(name)}</td>
        <td style="padding:5px 10px;text-align:center">${badgeHtml(r.status, rawDetail)}</td>
        <td style="padding:5px 10px">${detailHtml}</td>
      </tr>`;
      } else {
        rows += `<tr${rowCls(r.status)}>
        <td style="padding:5px 10px">${e(name)}</td>
        <td style="padding:5px 10px;text-align:center">${badgeHtml(r.status, rawDetail)}</td>
        <td style="padding:5px 10px">${detailHtml}</td>
      </tr>`;
      }
    }

    sections += `
    <h2 id="${slugs[i]}"
        style="margin-top:36px;color:${hdrColor};border-bottom:2px solid ${hdrColor};
               padding-bottom:5px;display:flex;align-items:center;gap:12px;
               ${suite.skipped ? 'opacity:.6;font-style:italic' : ''}">
      ${e(suite.label)}${suite.skipped ? ' <span style="font-size:11px;background:#eee;color:#888;padding:2px 8px;border-radius:4px;font-style:normal">SKIPPED</span>' : ''}
      <span style="font-size:13px;font-weight:400;color:#555">
        ${(suite.skipped || suite.notInScope) ? 'not in scope' : `${st.passed} passed &nbsp;·&nbsp; ${sf} failed &nbsp;·&nbsp; ${sw} warn &nbsp;·&nbsp; ${st.total} total`}
      </span>
      <a href="#top" style="margin-left:auto;font-size:11px;color:#888;text-decoration:none">▲ top</a>
    </h2>
    <table border="1" cellpadding="0" cellspacing="0"
           style="border-collapse:collapse;width:100%;font-size:13px;margin-bottom:4px">
      <thead>
        <tr style="background:#003366;color:#fff">
          ${hasDeviceCol
            ? '<th style="padding:7px 10px;text-align:left;width:18%">Device</th><th style="padding:7px 10px;text-align:left;width:32%">Test</th><th style="padding:7px 10px;width:110px">Status</th><th style="padding:7px 10px;text-align:left">Details</th>'
            : '<th style="padding:7px 10px;text-align:left;width:38%">Test</th><th style="padding:7px 10px;width:110px">Status</th><th style="padding:7px 10px;text-align:left">Details</th>'}
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
    <p style="text-align:right;margin:2px 0 0;font-size:11px;color:#999">
      <a href="#${slugs[i]}" style="color:#999">🔗 ${e(suite.label)}</a>
    </p>`;
  }

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Search Validation E2E Report</title>
  <style>
    * { box-sizing: border-box; }
    body  { font-family: Segoe UI, Arial, sans-serif; margin: 0; color: #1e2235;
            background: #f5f6fa; }
    #wrap { max-width: 1100px; margin: 0 auto; padding: 32px 24px 64px; }
    h1    { color: #003366; margin-bottom: 4px; font-size: 1.7rem; }
    .meta { color: #555; font-size: 13px; margin-bottom: 20px; }
    .kpi  { display: flex; gap: 14px; flex-wrap: wrap; margin: 18px 0 24px; }
    .kpi-box { padding: 14px 26px; border-radius: 10px; font-size: 20px;
               font-weight: bold; box-shadow: 0 1px 4px rgba(0,0,0,.12); }
    .badge { display:inline-block; padding:2px 9px; border-radius:4px;
             font-size:12px; font-weight:700; white-space:nowrap; }
    .badge.pass { background:#d4edda; color:#1a7a1a; }
    .badge.fail { background:#fad9d9; color:#c0001a; }
    .badge.warn { background:#fff0c2; color:#b86800; }
    .badge.skip { background:#eee;    color:#777; }
    table  { border: 1px solid #ccc; background:#fff; }
    th, td { border: 1px solid #dde; }
    .overview-table td { vertical-align:middle; }
    h2     { background:#fff; padding:10px 14px; border-radius:8px 8px 0 0;
             margin-bottom:0; font-size:1.05rem; box-shadow:0 1px 3px rgba(0,0,0,.08); }
    details summary { cursor:pointer; font-weight:bold; padding:10px;
                      background:#1e2235; color:#fff; border-radius:6px; }
    pre    { background:#111; color:#eee; padding:14px; border-radius:0 0 6px 6px;
             font-size:11px; overflow:auto; max-height:500px; margin-top:0; }
    a:focus-visible { outline:2px solid #003da5; }
  </style>
</head>
<body>
<div id="wrap">
  <div id="top"></div>
  <h1>🔍 Search Validation E2E — Full Report</h1>
  <p class="meta">
    <strong>URL:</strong> ${e(config.homeUrl)} &nbsp;|&nbsp;
    <strong>Mode:</strong> ${e(modeCols)} &nbsp;|&nbsp;
    <strong>Elapsed:</strong> ${elapsed}s &nbsp;|&nbsp;
    <strong>Run:</strong> ${new Date().toLocaleString()}
  </p>

  <div class="kpi">
    <div class="kpi-box" style="background:#d4edda;color:#1a7a1a">${normalizedTotals.passed} Passed</div>
    <div class="kpi-box" style="background:#fad9d9;color:#c0001a">${normalizedTotals.failed} Failed</div>
    <div class="kpi-box" style="background:#fff0c2;color:#b86800">${normalizedTotals.warn} Warn</div>
    <div class="kpi-box" style="background:${overallColor};color:#fff">${overallLabel}</div>
  </div>

  <h2 style="margin-top:0;color:#003366;border-bottom:2px solid #003366;background:transparent;
             padding:0 0 5px;box-shadow:none">Suite Overview</h2>
  <table class="overview-table" border="1" cellpadding="0" cellspacing="0"
         style="border-collapse:collapse;width:100%;font-size:13px;margin-bottom:32px">
    <thead>
      <tr style="background:#003366;color:#fff">
        <th style="padding:7px 10px;text-align:left">Suite</th>
        <th style="padding:7px 10px;width:130px">Result</th>
        <th style="padding:7px 10px;width:90px">Passed</th>
        <th style="padding:7px 10px;width:160px">Progress</th>
      </tr>
    </thead>
    <tbody>${overviewRows}</tbody>
  </table>

  ${knownWarningsHtml}

  ${sections}

  <details style="margin-top:40px">
    <summary>▶ Full Console Log</summary>
    <pre>${e(logLines.join('\n'))}</pre>
  </details>
</div>
</body>
</html>`;
}

// ── MAIN ──────────────────────────────────────────────────────────────────────
(async () => {
  const overallStart = Date.now();

  log(`\n${'═'.repeat(62)}`);
  log('  SEARCH VALIDATION — COMPLETE E2E');
  log(`  URL     : ${config.homeUrl}`);
  log(`  Headless: ${headless}`);
  log(`  Mode    : ${desktopOnly ? 'Desktop Only' : 'Full E2E'}`);
  log(`  Reports : ${HTML_FILE}`);
  log('═'.repeat(62));

  const suites = [];
  let browser, context, page;

  try {
    browser = await chromium.launch({ headless, slowMo: headless ? 0 : 50 });
    context = await browser.newContext({
      viewport: { width: 1280, height: 800 },
      extraHTTPHeaders: config.headers || {},
    });
    registerCookieAutoDismiss(context.pages()[0] || await context.newPage());
    page    = await context.newPage();
    registerCookieAutoDismiss(page);

    const gotoHome = async () => {
      await page.goto(config.homeUrl, { waitUntil: 'domcontentloaded', timeout: 40000 });
      await dismissCookieBanner(page).catch(() => {});
      await waitForPageReady(page, { networkTimeout: 5000 });
    };

    // ── 1. Desktop Autocomplete ───────────────────────────────────────────────
    const L1 = 'Desktop Chrome — Global Header Search (6 tests)';
    if (!shouldRunFocused(L1)) {
      suites.push(notInScopeSuite(L1));
    } else {
      log(`\n${'═'.repeat(62)}\n  SUITE 1/12 — DESKTOP CHROME — GLOBAL HEADER SEARCH\n${'═'.repeat(62)}`);
      await gotoHome();
      await runSuite(suites, L1, () =>
        testDesktopSearchOnDevice(page, { name: 'Desktop Chrome', width: 1280, height: 800, isMobile: false })
      );
    }

    // ── 1R. Global Header Search — on Search Results Page ──────────────────────
    const L1R = 'Desktop Chrome — Search Results Page (Global Header Search)';
    if (!shouldRunFocused(L1R)) {
      suites.push(notInScopeSuite(L1R));
    } else {
      log(`\n${'═'.repeat(62)}\n  SUITE 1R — DESKTOP CHROME — SR PAGE GLOBAL HEADER SEARCH\n${'═'.repeat(62)}`);
      const srHeaderUrl = `${config.homeUrl.replace(/\/$/,'')}${config.searchResultsBaseUrl || '/searchresults/personal/result?=&referrerPageUrl=&query='}`;
      await page.goto(srHeaderUrl, { waitUntil: 'domcontentloaded', timeout: 40000 });
      await waitForPageReady(page, { networkTimeout: 5000 });
      await runSuite(suites, L1R, () =>
        testSearchResultsPageAdvancedAutocomplete(page, {
          context:        SEARCH_CONTEXTS.srPageGlobalHeader,
          inputSelectors: SEARCH_CONTEXTS.srPageGlobalHeader.inputSelectors,
          label:          'SR Page Global Header Search',
          platform:       'Desktop Chrome',
        })
      );
    }

    // ── 1R2. SR Page Search Bar ─────────────────────────────────────────────
    const L1R2 = 'Desktop Chrome — SR Page Search Bar (7 tests)';
    if (!shouldRunFocused(L1R2)) {
      suites.push(notInScopeSuite(L1R2));
    } else {
      log(`\n${'═'.repeat(62)}\n  SUITE 1R2 — DESKTOP CHROME — SR PAGE SEARCH BAR\n${'═'.repeat(62)}`);
      const srOwnBarUrl = `${config.homeUrl.replace(/\/$/, '')}${config.searchResultsBaseUrl || '/searchresults/personal/result?=&referrerPageUrl=&query='}`;
      await page.goto(srOwnBarUrl, { waitUntil: 'domcontentloaded', timeout: 40000 });
      await waitForPageReady(page, { networkTimeout: 5000 });
      await runSuite(suites, L1R2, () =>
        testSearchResultsPageAdvancedAutocomplete(page, {
          context:        SEARCH_CONTEXTS.srPageSearchBar,
          inputSelectors: SEARCH_CONTEXTS.srPageSearchBar.inputSelectors,
          label:          'SR Page Search Bar',
          platform:       'Desktop Chrome',
          frameSelector:  '#answers-frame',
        })
      );
    }

    // ── 1R3. SR Page — Clear Button ──────────────────────────────────────────
    const L1R3 = 'Desktop Chrome — SR Page Clear Button (6 tests)';
    if (!shouldRunFocused(L1R3)) {
      suites.push(notInScopeSuite(L1R3));
    } else {
      log(`\n${'═'.repeat(62)}\n  SUITE 1R3 — DESKTOP CHROME — SR PAGE CLEAR BUTTON\n${'═'.repeat(62)}`);
      await runSuite(suites, L1R3, () =>
        testSrPageClearButton(page, {
          platform:  'Desktop Chrome',
          srBaseUrl: `${config.homeUrl.replace(/\/$/, '')}${config.searchResultsBaseUrl || '/searchresults/personal/result?=&referrerPageUrl=&query='}`,
        })
      );
    }

    // ── 2. Contact Page Autocomplete ─────────────────────────────────────────
    const L2 = 'Desktop Chrome — Contact Page Search (7 tests)';
    if (!shouldRunFocused(L2)) {
      suites.push(notInScopeSuite(L2));
    } else {
      log(`\n${'═'.repeat(62)}\n  SUITE 2/12 — DESKTOP CHROME — CONTACT PAGE SEARCH\n${'═'.repeat(62)}`);
      const contactUrl = `${config.homeUrl.replace(/\/$/,'')}${config.contactPath || '/personal/contact/'}`;
      await page.goto(contactUrl, { waitUntil: 'domcontentloaded', timeout: 40000 });
      await waitForPageReady(page, { networkTimeout: 5000 });
      await runSuite(suites, L2, () =>
        testContactPageAdvancedAutocomplete(page, {
          context:  SEARCH_CONTEXTS.contactPage,
          platform: 'Desktop Chrome',
        })
      );
    }

    // ── 2R. Search Results Page Autocomplete ──────────────────────────────────
    const L2R = 'Desktop Chrome — Search Results Page (7 tests)';
    if (!shouldRunFocused(L2R)) {
      suites.push(notInScopeSuite(L2R));
    } else {
      log(`\n${'═'.repeat(62)}\n  SUITE 2R — DESKTOP CHROME — SEARCH RESULTS PAGE\n${'═'.repeat(62)}`);
      const resultsUrl2R = `${config.homeUrl.replace(/\/$/,'')}${config.searchResultsBaseUrl || '/searchresults/personal/result?=&referrerPageUrl=&query='}`;
      await page.goto(resultsUrl2R, { waitUntil: 'domcontentloaded', timeout: 40000 });
      await waitForPageReady(page, { networkTimeout: 5000 });
      await runSuite(suites, L2R, () =>
        testSearchResultsPageAdvancedAutocomplete(page, {
          context:        SEARCH_CONTEXTS.srPageGlobalHeader,
          inputSelectors: SEARCH_CONTEXTS.srPageGlobalHeader.inputSelectors,
          platform:       'Desktop Chrome',
        })
      );
    }

    // ── 3. Advanced Autocomplete Behavior ────────────────────────────────────
    const L3 = 'Advanced Autocomplete Behavior (3 tests)';
    if (!shouldRunFocused(L3)) {
      suites.push(notInScopeSuite(L3));
    } else if (!skipAdvanced) {
      log(`\n${'═'.repeat(62)}\n  SUITE 3/9 — ADVANCED AUTOCOMPLETE BEHAVIOR\n${'═'.repeat(62)}`);
      await gotoHome();
      await runSuite(suites, L3, () =>
        testAdvancedAutocompleteBehavior(page, {
          context:  SEARCH_CONTEXTS.globalHeader,
          platform: 'Desktop Chrome',
        })
      );
    } else {
      suites.push(notInScopeSuite(L3, 'Not in scope (CLI exclusion)'));
    }

    // ── 4. Edge Cases ─────────────────────────────────────────────────────────
    const L4 = 'Edge Cases — Desktop Chrome · Global Header Search · Homepage (8 tests)';
    if (!shouldRunFocused(L4)) {
      suites.push(notInScopeSuite(L4));
    } else if (!skipEdge) {
      log(`\n${'═'.repeat(62)}\n  SUITE 4/9 — EDGE CASES (Desktop Chrome · Global Header Search · Homepage)\n${'═'.repeat(62)}`);
      await gotoHome();
      await runSuite(suites, L4, () =>
        testEdgeCases(page, {
          platform:  'Desktop Chrome',
          pageLabel: 'Homepage',
          component: 'Global Header Search',
        })
      );
    } else {
      suites.push(notInScopeSuite(L4, 'Not in scope (CLI exclusion)'));
    }

    // ── 5. No-Results State ───────────────────────────────────────────────────
    const L5 = 'No-Results State (3 terms)';
    if (!shouldRunFocused(L5)) {
      suites.push(notInScopeSuite(L5));
    } else if (!skipNoResults) {
      log(`\n${'═'.repeat(62)}\n  SUITE 5/10 — NO-RESULTS STATE\n${'═'.repeat(62)}`);
      await gotoHome();
      await runSuite(suites, L5, () =>
        testNoResultsState(page)
      );
    } else {
      suites.push(notInScopeSuite(L5, 'Not in scope (CLI exclusion)'));
    }

    // ── 6a. ARIA State Validation — Home Page ────────────────────────────────
    const L6A = 'ARIA State Validation — Home Page (15 checks)';
    if (!shouldRunFocused(L6A)) {
      suites.push(notInScopeSuite(L6A));
    } else if (!skipAria) {
      log(`\n${'═'.repeat(62)}\n  SUITE 6a/11 — ARIA STATE VALIDATION (Home Page)\n${'═'.repeat(62)}`);
      await gotoHome();
      const isAngular = isAngularEnv(config.homeUrl);
      const homeInputSelector = isAngular
        ? 'bolt-autocomplete >> input[data-test="input"]'
        : '#yxt-SearchBar-input--search-bar-1';
      await runSuite(suites, L6A, () =>
        testAriaStateValidation(page, { inputSelector: homeInputSelector, pageUrl: config.homeUrl, pageLabel: 'Home Page' })
      );
    } else {
      suites.push(notInScopeSuite(L6A, 'Not in scope (CLI exclusion)'));
    }

    // ── 6b. ARIA State Validation — Contact Page ─────────────────────────────
    const L6B = 'ARIA State Validation — Contact Page (15 checks)';
    if (!shouldRunFocused(L6B)) {
      suites.push(notInScopeSuite(L6B));
    } else if (!skipAria) {
      log(`\n${'═'.repeat(62)}\n  SUITE 6b/11 — ARIA STATE VALIDATION (Contact Page)\n${'═'.repeat(62)}`);
      const isAngular = isAngularEnv(config.homeUrl);
      const contactInputSelector = isAngular
        ? 'div.nw-help-center-search bolt-autocomplete >> input[data-test="input"]'
        : '#yxt-SearchBar-input--help-search-bar';
      await runSuite(suites, L6B, () =>
        testAriaStateValidation(page, {
          inputSelector: contactInputSelector,
          pageUrl: `${config.homeUrl.replace(/\/$/,'')}${config.contactPath || '/personal/contact'}`,
          pageLabel: 'Contact Page',
        })
      );
    } else {
      suites.push(notInScopeSuite(L6B, 'Not in scope (CLI exclusion)'));
    }

    // ── 6c. ARIA State Validation — Search Results Page (page-level bar) ───────
    const L6C = 'ARIA State Validation — Search Results Page (15 checks)';
    if (!shouldRunFocused(L6C)) {
      suites.push(notInScopeSuite(L6C));
    } else if (!skipAria) {
      log(`\n${'═'.repeat(62)}\n  SUITE 6c — ARIA STATE VALIDATION (Search Results Page)\n${'═'.repeat(62)}`);
      const resultsAriaUrl = `${config.homeUrl.replace(/\/$/,'')}${config.searchResultsBaseUrl}`;
      await page.goto(resultsAriaUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
      await page.waitForTimeout(3000);
      await runSuite(suites, L6C, () =>
        testAriaStateValidation(page, {
          inputSelector: '#yxt-SearchBar-input--search-bar-1',
          frameSelector: '#answers-frame',
          pageUrl: resultsAriaUrl,
          pageLabel: 'Search Results Page (In-page Bar)',
        })
      );
    } else {
      suites.push(notInScopeSuite(L6C, 'Not in scope (CLI exclusion)'));
    }

    // ── 6c-H. ARIA State Validation — SR Page Global Header bar ────────────────
    const L6CH = 'ARIA State Validation — Search Results Page Global Header (15 checks)';
    if (!shouldRunFocused(L6CH)) {
      suites.push(notInScopeSuite(L6CH));
    } else if (!skipAria) {
      log(`\n${'═'.repeat(62)}\n  SUITE 6c-H — ARIA STATE VALIDATION (SR Page Global Header)\n${'═'.repeat(62)}`);
      const srHeaderAriaUrl = `${config.homeUrl.replace(/\/$/,'')}${config.searchResultsBaseUrl}`;
      await page.goto(srHeaderAriaUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
      await page.waitForTimeout(3000);
      await runSuite(suites, L6CH, () =>
        testAriaStateValidation(page, {
          inputSelector: '#yxt-SearchBar-input--SearchBar',
          pageUrl: srHeaderAriaUrl,
          pageLabel: 'Search Results Page (Global Header)',
        })
      );
    } else {
      suites.push(notInScopeSuite(L6CH, 'Not in scope (CLI exclusion)'));
    }

    // ── 7. Search Results Content ─────────────────────────────────────────────
    const L7 = 'Search Results Content (3 terms)';
    if (!shouldRunFocused(L7)) {
      suites.push(notInScopeSuite(L7));
    } else if (!skipContent) {
      log(`\n${'═'.repeat(62)}\n  SUITE 7/11 — SEARCH RESULTS CONTENT\n${'═'.repeat(62)}`);
      await runSuite(suites, L7, () =>
        testSearchResultsContent(page)
      );
    } else {
      suites.push(notInScopeSuite(L7, 'Not in scope (CLI exclusion)'));
    }

    // ── 8. Performance ────────────────────────────────────────────────────────
    const L8 = 'Performance';
    if (!shouldRunFocused(L8)) {
      suites.push(notInScopeSuite(L8));
    } else if (!skipPerf) {
      log(`\n${'═'.repeat(62)}\n  SUITE 8/11 — PERFORMANCE\n${'═'.repeat(62)}`);
      await runSuite(suites, L8, () =>
        testPerformance(page)
      );
    } else {
      suites.push(notInScopeSuite(L8, 'Not in scope (CLI exclusion)'));
    }

    // SUITE 9 — ACCESSIBILITY removed; functional regression only

    // ── 10. Mobile/Tablet Viewports ───────────────────────────────────────────
    const L10 = 'Mobile Viewports (5 devices)';
    if (!shouldRunFocused(L10)) {
      suites.push(notInScopeSuite(L10));
    } else if (!skipMobile) {
      log(`\n${'═'.repeat(62)}\n  SUITE 10/12 — MOBILE/TABLET VIEWPORTS (5 devices, Global Header + Contact)\n${'═'.repeat(62)}`);
      try {
        const mobileRaw   = await testMobileViewports(context);
        const mobileSuite = normaliseMobile(mobileRaw);
        printSuite(mobileSuite);
        suites.push(mobileSuite);
      } catch (mErr) {
        log(`  [SUITE CRASH] Mobile Viewports: ${mErr.message}`);
        suites.push({ label: 'Mobile Viewports (5 devices)', results: [{ test: 'Mobile crashed', status: 'FAILED', error: mErr.message.substring(0,200) }], passed: 0, total: 1 });
      }
    } else {
      suites.push(notInScopeSuite(L10, 'Not in scope (CLI exclusion)'));
    }

    // ── 10R. Mobile/Tablet — Search Results Page ─────────────────────────────
    const L10R = 'Mobile Viewports — Search Results Page (5 devices)';
    if (!shouldRunFocused(L10R)) {
      suites.push(notInScopeSuite(L10R));
    } else if (!skipMobile) {
      log(`\n${'═'.repeat(62)}\n  SUITE 10R — MOBILE/TABLET SEARCH RESULTS PAGE (5 devices)\n${'═'.repeat(62)}`);
      try {
        const mobileRaw_sr   = await testMobileSrPageViewports(context);
        const mobileSuite_sr = normaliseMobile(mobileRaw_sr);
        mobileSuite_sr.label = L10R;
        printSuite(mobileSuite_sr);
        suites.push(mobileSuite_sr);
      } catch (mErrSr) {
        log(`  [SUITE CRASH] Mobile SR Page: ${mErrSr.message}`);
        suites.push({ label: L10R, results: [{ test: 'Mobile SR suite crashed', status: 'FAILED', error: mErrSr.message.substring(0,200) }], passed: 0, total: 1 });
      }
    } else {
      suites.push(notInScopeSuite(L10R, 'Not in scope (CLI exclusion)'));
    }

    // ── 11. Edge Browser — Global Header Search ───────────────────────────────
    const L11 = 'Desktop Edge — Global Header Search (6 tests)';
    if (!shouldRunFocused(L11)) {
      suites.push(notInScopeSuite(L11));
    } else if (!skipEdgeBrowser) {
      log(`\n${'═'.repeat(62)}\n  SUITE 11 — EDGE BROWSER — GLOBAL HEADER SEARCH\n${'═'.repeat(62)}`);
      let edgeBrowser, edgeContext, edgePage;
      try {
        edgeBrowser = await chromium.launch({
          headless,
          channel: 'msedge',
          slowMo: headless ? 0 : 50,
        });
        edgeContext = await edgeBrowser.newContext({
          viewport: { width: 1280, height: 800 },
          extraHTTPHeaders: config.headers || {},
        });
        edgePage = await edgeContext.newPage();
        registerCookieAutoDismiss(edgePage);
        await edgePage.goto(config.homeUrl, { waitUntil: 'domcontentloaded', timeout: 40000 });
        await dismissCookieBanner(edgePage).catch(() => {});
        await waitForPageReady(edgePage, { networkTimeout: 5000 });
        await runSuite(suites, L11, () =>
          testDesktopSearchOnDevice(edgePage, { name: 'Desktop Edge', width: 1280, height: 800, isMobile: false })
        );
      } catch (edgeErr) {
        log(`  Edge browser unavailable or failed: ${edgeErr.message}`);
        suites.push(notInScopeSuite(L11, `Not in scope: ${edgeErr.message}`));
      } finally {
        await edgePage?.close().catch(() => {});
        await edgeContext?.close().catch(() => {});
        await edgeBrowser?.close().catch(() => {});
      }
    }

    // ── 11R. Edge Browser — Search Results Page (Global Header Search) ────────
    const L11R = 'Desktop Edge — Search Results Page (Global Header Search)';
    if (!shouldRunFocused(L11R)) {
      suites.push(notInScopeSuite(L11R));
    } else if (!skipEdgeBrowser) {
      log(`\n${'═'.repeat(62)}\n  SUITE 11R — EDGE BROWSER — SR PAGE GLOBAL HEADER SEARCH\n${'═'.repeat(62)}`);
      let edgeBrowserR, edgeContextR, edgePageR;
      try {
        edgeBrowserR = await chromium.launch({
          headless,
          channel: 'msedge',
          slowMo: headless ? 0 : 50,
        });
        edgeContextR = await edgeBrowserR.newContext({
          viewport: { width: 1280, height: 800 },
          extraHTTPHeaders: config.headers || {},
        });
        edgePageR = await edgeContextR.newPage();
        registerCookieAutoDismiss(edgePageR);
        const edgeSrHeaderUrl = `${config.homeUrl.replace(/\/$/, '')}${config.searchResultsBaseUrl || '/searchresults/personal/result?=&referrerPageUrl=&query='}`;
        await edgePageR.goto(edgeSrHeaderUrl, { waitUntil: 'domcontentloaded', timeout: 40000 });
        await waitForPageReady(edgePageR, { networkTimeout: 5000 });
        await runSuite(suites, L11R, () =>
          testSearchResultsPageAdvancedAutocomplete(edgePageR, {
            context:        SEARCH_CONTEXTS.srPageGlobalHeader,
            inputSelectors: SEARCH_CONTEXTS.srPageGlobalHeader.inputSelectors,
            label:          'SR Page Global Header Search',
            platform:       'Desktop Edge',
          })
        );
      } catch (edgeErrR) {
        log(`  Edge SR page global header failed: ${edgeErrR.message}`);
        suites.push(notInScopeSuite(L11R, `Not in scope: ${edgeErrR.message}`));
      } finally {
        await edgePageR?.close().catch(() => {});
        await edgeContextR?.close().catch(() => {});
        await edgeBrowserR?.close().catch(() => {});
      }
    }

    // ── 11R2. Edge Browser — SR Page Search Bar ──────────────────────────────
    const L11R2 = 'Desktop Edge — SR Page Search Bar (7 tests)';
    if (!shouldRunFocused(L11R2)) {
      suites.push(notInScopeSuite(L11R2));
    } else if (!skipEdgeBrowser) {
      log(`\n${'═'.repeat(62)}\n  SUITE 11R2 — EDGE BROWSER — SR PAGE SEARCH BAR\n${'═'.repeat(62)}`);
      let edgeBrowserR2, edgeContextR2, edgePageR2;
      try {
        edgeBrowserR2 = await chromium.launch({
          headless,
          channel: 'msedge',
          slowMo: headless ? 0 : 50,
        });
        edgeContextR2 = await edgeBrowserR2.newContext({
          viewport: { width: 1280, height: 800 },
          extraHTTPHeaders: config.headers || {},
        });
        edgePageR2 = await edgeContextR2.newPage();
        registerCookieAutoDismiss(edgePageR2);
        const edgeSrOwnBarUrl = `${config.homeUrl.replace(/\/$/, '')}${config.searchResultsBaseUrl || '/searchresults/personal/result?=&referrerPageUrl=&query='}`;
        await edgePageR2.goto(edgeSrOwnBarUrl, { waitUntil: 'domcontentloaded', timeout: 40000 });
        await waitForPageReady(edgePageR2, { networkTimeout: 5000 });
        await runSuite(suites, L11R2, () =>
          testSearchResultsPageAdvancedAutocomplete(edgePageR2, {
            context:        SEARCH_CONTEXTS.srPageSearchBar,
            inputSelectors: SEARCH_CONTEXTS.srPageSearchBar.inputSelectors,
            label:          'SR Page Search Bar',
            platform:       'Desktop Edge',
            frameSelector:  '#answers-frame',
          })
        );
      } catch (edgeErrR2) {
        log(`  Edge SR page search bar failed: ${edgeErrR2.message}`);
        suites.push(notInScopeSuite(L11R2, `Not in scope: ${edgeErrR2.message}`));
      } finally {
        await edgePageR2?.close().catch(() => {});
        await edgeContextR2?.close().catch(() => {});
        await edgeBrowserR2?.close().catch(() => {});
      }
    }

    // ── 11R3. Edge Browser — SR Page Clear Button ──────────────────────────
    const L11R3 = 'Desktop Edge — SR Page Clear Button (6 tests)';
    if (!shouldRunFocused(L11R3)) {
      suites.push(notInScopeSuite(L11R3));
    } else if (!skipEdgeBrowser) {
      log(`\n${'═'.repeat(62)}\n  SUITE 11R3 — EDGE BROWSER — SR PAGE CLEAR BUTTON\n${'═'.repeat(62)}`);
      let edgeBrowserR3, edgeContextR3, edgePageR3;
      try {
        edgeBrowserR3 = await chromium.launch({ headless, channel: 'msedge', slowMo: headless ? 0 : 50 });
        edgeContextR3 = await edgeBrowserR3.newContext({
          viewport: { width: 1280, height: 800 },
          extraHTTPHeaders: config.headers || {},
        });
        edgePageR3 = await edgeContextR3.newPage();
        registerCookieAutoDismiss(edgePageR3);
        await runSuite(suites, L11R3, () =>
          testSrPageClearButton(edgePageR3, {
            platform:  'Desktop Edge',
            srBaseUrl: `${config.homeUrl.replace(/\/$/, '')}${config.searchResultsBaseUrl || '/searchresults/personal/result?=&referrerPageUrl=&query='}`,
          })
        );
      } catch (edgeErrR3) {
        log(`  Edge SR page clear button failed: ${edgeErrR3.message}`);
        suites.push(notInScopeSuite(L11R3, `Not in scope: ${edgeErrR3.message}`));
      } finally {
        await edgePageR3?.close().catch(() => {});
        await edgeContextR3?.close().catch(() => {});
        await edgeBrowserR3?.close().catch(() => {});
      }
    }

    // ── 12. Edge Browser — Contact Page Search ────────────────────────────────
    const L12 = 'Desktop Edge — Contact Page Search (7 tests)';
    if (!shouldRunFocused(L12)) {
      suites.push(notInScopeSuite(L12));
    } else if (!skipEdgeBrowser) {
      log(`\n${'═'.repeat(62)}\n  SUITE 12 — EDGE BROWSER — CONTACT PAGE SEARCH\n${'═'.repeat(62)}`);
      let edgeBrowser2, edgeContext2, edgePage2;
      try {
        edgeBrowser2 = await chromium.launch({
          headless,
          channel: 'msedge',
          slowMo: headless ? 0 : 50,
        });
        edgeContext2 = await edgeBrowser2.newContext({
          viewport: { width: 1280, height: 800 },
          extraHTTPHeaders: config.headers || {},
        });
        edgePage2 = await edgeContext2.newPage();
        registerCookieAutoDismiss(edgePage2);
        const edgeContactUrl = `${config.homeUrl.replace(/\/$/,'')}${config.contactPath || '/personal/contact/'}`;
        await edgePage2.goto(edgeContactUrl, { waitUntil: 'domcontentloaded', timeout: 40000 });
        await dismissCookieBanner(edgePage2).catch(() => {});
        await waitForPageReady(edgePage2, { networkTimeout: 5000 });
        await runSuite(suites, L12, () =>
          testContactPageAdvancedAutocomplete(edgePage2, {
            context:  SEARCH_CONTEXTS.contactPage,
            platform: 'Desktop Edge',
          })
        );
      } catch (edgeErr2) {
        log(`  Edge contact page failed: ${edgeErr2.message}`);
        suites.push(notInScopeSuite(L12, `Not in scope: ${edgeErr2.message}`));
      } finally {
        await edgePage2?.close().catch(() => {});
        await edgeContext2?.close().catch(() => {});
        await edgeBrowser2?.close().catch(() => {});
      }
    }

    // ── 12R. Edge Browser — Search Results Page ───────────────────────────────
    const L12R = 'Desktop Edge — Search Results Page (7 tests)';
    if (!shouldRunFocused(L12R)) {
      suites.push(notInScopeSuite(L12R));
    } else if (!skipEdgeBrowser) {
      log(`\n${'═'.repeat(62)}\n  SUITE 12R — EDGE BROWSER — SEARCH RESULTS PAGE\n${'═'.repeat(62)}`);
      let edgeBrowser2R, edgeContext2R, edgePage2R;
      try {
        edgeBrowser2R = await chromium.launch({
          headless,
          channel: 'msedge',
          slowMo: headless ? 0 : 50,
        });
        edgeContext2R = await edgeBrowser2R.newContext({
          viewport: { width: 1280, height: 800 },
          extraHTTPHeaders: config.headers || {},
        });
        edgePage2R = await edgeContext2R.newPage();
        registerCookieAutoDismiss(edgePage2R);
        const edgeResultsUrl = `${config.homeUrl.replace(/\/$/, '')}${config.searchResultsBaseUrl || '/searchresults/personal/result?=&referrerPageUrl=&query='}`;
        await edgePage2R.goto(edgeResultsUrl, { waitUntil: 'domcontentloaded', timeout: 40000 });
        await waitForPageReady(edgePage2R, { networkTimeout: 5000 });
        await runSuite(suites, L12R, () =>
          testSearchResultsPageAdvancedAutocomplete(edgePage2R, {
            context:        SEARCH_CONTEXTS.srPageGlobalHeader,
            inputSelectors: SEARCH_CONTEXTS.srPageGlobalHeader.inputSelectors,
            platform:       'Desktop Edge',
          })
        );
      } catch (edgeErr2R) {
        log(`  Edge SR page failed: ${edgeErr2R.message}`);
        suites.push(notInScopeSuite(L12R, `Not in scope: ${edgeErr2R.message}`));
      } finally {
        await edgePage2R?.close().catch(() => {});
        await edgeContext2R?.close().catch(() => {});
        await edgeBrowser2R?.close().catch(() => {});
      }
    }

    // ── Edge skipped placeholders ─────────────────────────────────────────────
    if (skipEdgeBrowser && !focusedRerun) {
      suites.push(notInScopeSuite('Desktop Edge — Global Header Search (6 tests)',         'Not in scope (CLI exclusion)'));
      suites.push(notInScopeSuite('Desktop Edge — Search Results Page (Global Header Search)', 'Not in scope (CLI exclusion)'));
      suites.push(notInScopeSuite('Desktop Edge — Contact Page Search (7 tests)',           'Not in scope (CLI exclusion)'));
      suites.push(notInScopeSuite('Desktop Edge — Search Results Page (7 tests)',           'Not in scope (CLI exclusion)'));
    }

    // ── 13c. Submit Button (AC-30) — Global Header + Contact Page + Search Results ─
    const L13G = 'Submit Button — Global Header Search (AC-30)';
    const L13C = 'Submit Button — Contact Page Search (AC-30)';
    const L13R = 'Submit Button — Search Results Page (AC-30)';
    if (shouldRunFocused(L13G) || shouldRunFocused(L13C) || shouldRunFocused(L13R)) {
      if (!skipSubmit) {
      log(`\n${'═'.repeat(62)}\n  SUITE 13c — SUBMIT BUTTON (AC-30) — GLOBAL HEADER\n${'═'.repeat(62)}`);
      await gotoHome();
      if (shouldRunFocused(L13G)) {
        await runSuite(suites, L13G, () =>
        testSubmitButton(page, { component: 'global' })
        );
      } else {
        suites.push(notInScopeSuite(L13G));
      }

      log(`\n${'═'.repeat(62)}\n  SUITE 13c — SUBMIT BUTTON (AC-30) — CONTACT PAGE\n${'═'.repeat(62)}`);
      const submitContactUrl  = `${config.homeUrl.replace(/\/$/,'')}${config.contactPath || '/personal/contact/'}`;
      if (shouldRunFocused(L13C)) {
        await runSuite(suites, L13C, () =>
          testSubmitButton(page, { component: 'contact', pageUrl: submitContactUrl })
        );
      } else {
        suites.push(notInScopeSuite(L13C));
      }

      log(`\n${'═'.repeat(62)}\n  SUITE 13c — SUBMIT BUTTON (AC-30) — SEARCH RESULTS PAGE\n${'═'.repeat(62)}`);
      const submitResultsUrl = `${config.homeUrl.replace(/\/$/,'')}${config.searchResultsBaseUrl || '/searchresults/personal/result?=&referrerPageUrl=&query='}`;
      if (shouldRunFocused(L13R)) {
        await runSuite(suites, L13R, () =>
          testSubmitButton(page, { component: 'results', pageUrl: submitResultsUrl })
        );
      } else {
        suites.push(notInScopeSuite(L13R));
      }

      log(`\n${'═'.repeat(62)}\n  SUITE 13c-H — SUBMIT BUTTON (AC-30) — SR PAGE GLOBAL HEADER\n${'═'.repeat(62)}`);
      const L13RH = 'Submit Button — Search Results Page Global Header (AC-30)';
      await runSuite(suites, L13RH, () =>
        testSubmitButton(page, { component: 'results-header', pageUrl: submitResultsUrl })
      );
      } else {
        suites.push(notInScopeSuite(L13G, 'Not in scope (CLI exclusion)'));
        suites.push(notInScopeSuite(L13C, 'Not in scope (CLI exclusion)'));
        suites.push(notInScopeSuite(L13R, 'Not in scope (CLI exclusion)'));
        suites.push(notInScopeSuite('Submit Button — Search Results Page Global Header (AC-30)', 'Not in scope (CLI exclusion)'));
      }
    } else {
      suites.push(notInScopeSuite(L13G));
      suites.push(notInScopeSuite(L13C));
      suites.push(notInScopeSuite(L13R));
      suites.push(notInScopeSuite('Submit Button — Search Results Page Global Header (AC-30)'));
    }

    // ── 15. Visual Presence Validation ────────────────────────────────────────
    const L15A = 'Visual Presence — Global Header Search (VP-01–05)';
    const L15B = 'Visual Presence — Contact Page Search (VP-01–05)';
    const L15C = 'Visual Presence — Search Results Page (VP-01–05 + SR-01)';
    if (shouldRunFocused(L15A) || shouldRunFocused(L15B) || shouldRunFocused(L15C)) {
      if (!skipVisual) {
      log(`\n${'═'.repeat(62)}\n  SUITE 15a — VISUAL PRESENCE — GLOBAL HEADER SEARCH\n${'═'.repeat(62)}`);
      await gotoHome();
      if (shouldRunFocused(L15A)) {
        await runSuite(suites, L15A, () =>
          testVisualPresence(page, { component: 'global' })
        );
      } else {
        suites.push(notInScopeSuite(L15A));
      }

      log(`\n${'═'.repeat(62)}\n  SUITE 15b — VISUAL PRESENCE — CONTACT PAGE SEARCH\n${'═'.repeat(62)}`);
      const vpContactUrl  = `${config.homeUrl.replace(/\/$/,'')}${config.contactPath || '/personal/contact/'}`;
      if (shouldRunFocused(L15B)) {
        await runSuite(suites, L15B, () =>
          testVisualPresence(page, { component: 'contact', pageUrl: vpContactUrl })
        );
      } else {
        suites.push(notInScopeSuite(L15B));
      }

      log(`\n${'═'.repeat(62)}\n  SUITE 15c — VISUAL PRESENCE — SEARCH RESULTS PAGE\n${'═'.repeat(62)}`);
      const vpResultsUrl = `${config.homeUrl.replace(/\/$/,'')}${config.searchResultsBaseUrl || '/searchresults/personal/result?=&referrerPageUrl=&query='}`;
      if (shouldRunFocused(L15C)) {
        await runSuite(suites, L15C, () =>
          testVisualPresence(page, { component: 'results', pageUrl: vpResultsUrl })
        );
      } else {
        suites.push(notInScopeSuite(L15C));
      }

      log(`\n${'═'.repeat(62)}\n  SUITE 15d — VISUAL PRESENCE — SR PAGE GLOBAL HEADER\n${'═'.repeat(62)}`);
      const L15RH = 'Visual Presence — Search Results Page Global Header (VP-01–05)';
      await runSuite(suites, L15RH, () =>
        testVisualPresence(page, { component: 'results-header', pageUrl: vpResultsUrl })
      );
      } else {
        suites.push(notInScopeSuite(L15A, 'Not in scope (CLI exclusion)'));
        suites.push(notInScopeSuite(L15B, 'Not in scope (CLI exclusion)'));
        suites.push(notInScopeSuite(L15C, 'Not in scope (CLI exclusion)'));
        suites.push(notInScopeSuite('Visual Presence — Search Results Page Global Header (VP-01–05)', 'Not in scope (CLI exclusion)'));
      }
    } else {
      suites.push(notInScopeSuite(L15A));
      suites.push(notInScopeSuite(L15B));
      suites.push(notInScopeSuite(L15C));
      suites.push(notInScopeSuite('Visual Presence — Search Results Page Global Header (VP-01–05)'));
    }

    // ── 14. Analytics / dataLayer Validation ──────────────────────────────────
    const L14 = 'Analytics / dataLayer Validation (AC-66–69)';
    if (!shouldRunFocused(L14)) {
      suites.push(notInScopeSuite(L14));
    } else if (!skipAnalytics) {
      log(`\n${'═'.repeat(62)}\n  SUITE 14/14 — ANALYTICS / DATALAYER VALIDATION (AC-66–69)\n${'═'.repeat(62)}`);
      await runSuite(suites, L14, () =>
        testAnalyticsTracking(browser, { headless })
      );
    } else {
      suites.push(notInScopeSuite(L14, 'Not in scope (CLI exclusion)'));
    }

  } catch (err) {
    log(`\n  FATAL: ${err.message}\n${err.stack}`);
  } finally {
    const elapsed = ((Date.now() - overallStart) / 1000).toFixed(1);

    // ── Grand totals ──────────────────────────────────────────────────────────
    let grandPassed = 0, grandFailed = 0, grandWarn = 0, grandSkipped = 0, grandNotInScope = 0;
    let finalPassed = 0, finalFailed = 0, finalWarn = 0;
    for (const s of suites) {
      grandPassed  += s.results.filter(r => r.status === 'PASSED').length;
      grandFailed  += s.results.filter(r => r.status === 'FAILED').length;
      grandWarn    += s.results.filter(r => r.status === 'WARN' || r.status === 'WARNING').length;
      grandSkipped += s.results.filter(r => r.status === 'SKIPPED').length;
      grandNotInScope += s.results.filter(r => r.status === 'NOT_IN_SCOPE').length;
      finalPassed  += s.results.filter(r => normalizeStatus(r.status, r.detail || r.error || '') === 'PASSED').length;
      finalFailed  += s.results.filter(r => normalizeStatus(r.status, r.detail || r.error || '') === 'FAILED').length;
      finalWarn    += s.results.filter(r => normalizeStatus(r.status, r.detail || r.error || '') === 'WARN').length;
    }

    log(`\n${'═'.repeat(62)}`);
    log('  OVERALL SUMMARY');
    log('═'.repeat(62));
    for (const s of suites) {
      const p = s.results.filter(r => normalizeStatus(r.status, r.detail || r.error || '') === 'PASSED').length;
      const f = s.results.filter(r => normalizeStatus(r.status, r.detail || r.error || '') === 'FAILED').length;
      const w = s.results.filter(r => normalizeStatus(r.status, r.detail || r.error || '') === 'WARN').length;
      log(`  ${s.label.padEnd(42)}: ${p} passed | ${f} failed | ${w} warn`);
    }
    log('─'.repeat(62));
    log(`  TOTAL : ${finalPassed} passed | ${finalFailed} failed | ${finalWarn} warn${grandNotInScope ? ` | ${grandNotInScope} not-in-scope` : ''}`);
    log(`  Time  : ${elapsed}s`);
    log('═'.repeat(62));

    // ── Write outputs ─────────────────────────────────────────────────────────
    const jsonOut = {
      suites: suites.map(s => ({ label: s.label, passed: s.passed, total: s.total, results: s.results })),
      grandPassed, grandFailed, grandWarn, grandSkipped,
      grandNotInScope,
      finalPassed, finalFailed, finalWarn,
      elapsed, ts: new Date().toISOString(),
    };
    fs.writeFileSync(LOG_FILE,  logLines.join('\n'), 'utf8');
    fs.writeFileSync(JSON_FILE, JSON.stringify(jsonOut, null, 2), 'utf8');
    fs.writeFileSync(HTML_FILE, buildHtml(suites, grandPassed, grandFailed, grandWarn, elapsed), 'utf8');

    log(`\n  Log  : ${LOG_FILE}`);
    log(`  JSON : ${JSON_FILE}`);
    log(`  HTML : ${HTML_FILE}`);

    await browser?.close();
    process.exit(finalFailed > 0 ? 1 : 0);
  }
})();
