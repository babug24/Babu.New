import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { chromium } from 'playwright';
import { config } from './core/config.js';
import { testMobileViewports } from './tests/mobile.js';

const headless = process.argv.includes('--headless');

const __dir = path.dirname(fileURLToPath(import.meta.url));
const reportsDir = path.join(__dir, 'reports');
if (!fs.existsSync(reportsDir)) fs.mkdirSync(reportsDir, { recursive: true });

const ts = new Date().toISOString().replace(/[:.]/g, '-').replace('T', '_').slice(0, 19);
const stem = `mobile_viewports_only_${ts}`;
const jsonPath = path.join(reportsDir, `${stem}.json`);

(async () => {
  console.log('\n' + '='.repeat(60));
  console.log(' MOBILE VIEWPORTS ONLY (5 DEVICES)');
  console.log('='.repeat(60));
  console.log(` URL: ${config.homeUrl}`);
  console.log(` Headless: ${headless}`);

  const browser = await chromium.launch({ headless, slowMo: headless ? 0 : 60 });
  const context = await browser.newContext({
    viewport: { width: 1280, height: 800 },
    extraHTTPHeaders: config.headers,
  });

  try {
    const mobileResults = await testMobileViewports(context);
    const rows = mobileResults.flatMap(device =>
      (device.results || []).map(result => ({
        device: device.device,
        test: result.test || result.name || 'Unknown',
        status: result.status,
        detail: result.detail || result.error || '',
      }))
    );

    const summary = {
      passed: rows.filter(r => r.status === 'PASSED').length,
      failed: rows.filter(r => r.status === 'FAILED').length,
      warn: rows.filter(r => r.status === 'WARN').length,
      skipped: rows.filter(r => r.status === 'SKIPPED').length,
      total: rows.length,
    };

    console.log('\n' + '-'.repeat(60));
    console.log(' MOBILE-ONLY SUMMARY');
    console.log('-'.repeat(60));
    console.log(` Passed: ${summary.passed} | Failed: ${summary.failed} | Warn: ${summary.warn} | Skipped: ${summary.skipped} | Total: ${summary.total}`);

    for (const device of mobileResults) {
      const arr = device.results || [];
      const p = arr.filter(r => r.status === 'PASSED').length;
      const f = arr.filter(r => r.status === 'FAILED').length;
      const w = arr.filter(r => r.status === 'WARN').length;
      console.log(`  - ${device.device}: ${p} passed, ${f} failed, ${w} warn`);
    }

    fs.writeFileSync(jsonPath, JSON.stringify({
      timestamp: new Date().toISOString(),
      url: config.homeUrl,
      headless,
      summary,
      results: mobileResults,
    }, null, 2));

    console.log(`\n JSON: ${jsonPath}`);
    process.exit(summary.failed > 0 ? 1 : 0);
  } finally {
    await context.close().catch(() => {});
    await browser.close().catch(() => {});
  }
})().catch(err => {
  console.error(`\n FATAL: ${err.message}`);
  process.exit(1);
});
